#!/bin/bash
# Flight Reservation System - one-command run (Servlet + JSP on Tomcat 11)
# Usage: ./run.sh   (Mac/Linux)
set -e
cd "$(dirname "$0")"

echo "==> Checking prerequisites..."
command -v java >/dev/null || { echo "ERROR: java nahi mila. JDK 17+ install karo."; exit 1; }
command -v mvn >/dev/null || { echo "ERROR: maven nahi mila."; exit 1; }

if ! (echo > /dev/tcp/127.0.0.1/3306) 2>/dev/null; then
  echo "WARNING: MySQL localhost:3306 par nahi dikh raha - pehle MySQL start kar lena."
fi

echo "==> Building WAR..."
mvn -q package -DskipTests

TOMCAT_VER="11.0.26"
TOMCAT_DIR="$HOME/Downloads/apache-tomcat-$TOMCAT_VER"
if [ ! -d "$TOMCAT_DIR" ]; then
  echo "==> Tomcat $TOMCAT_VER download ho raha hai (pehli baar)..."
  mkdir -p "$HOME/Downloads" && cd "$HOME/Downloads"
  curl -sL -o tomcat11.zip "https://dlcdn.apache.org/tomcat/tomcat-11/v${TOMCAT_VER}/bin/apache-tomcat-${TOMCAT_VER}.zip"
  unzip -q -o tomcat11.zip
  chmod +x "$TOMCAT_DIR/bin/"*.sh
  cd "$(dirname "$0")"
fi

echo "==> Deploying..."
rm -rf "$TOMCAT_DIR/webapps/ROOT"
cp target/flight-reservation-system.war "$TOMCAT_DIR/webapps/ROOT.war"

echo "==> Starting Tomcat..."
"$TOMCAT_DIR/bin/startup.sh"
echo ""
echo "Ho gaya! Khol: http://localhost:8080  (pehli baar 20-25 sec wait karna)"
echo "Band karne ke liye: $TOMCAT_DIR/bin/shutdown.sh"
