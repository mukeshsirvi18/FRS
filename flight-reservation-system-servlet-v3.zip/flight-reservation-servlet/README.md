# Flight Reservation System — Plain Servlet + JSP (MVC)

A flight search & booking web app built with **plain Jakarta Servlets, JSP/JSTL and JDBC**
following the MVC pattern. No Spring framework.

- **Controllers** → Servlets (`com.frs.servlet`, `@WebServlet`)
- **Views** → JSP + JSTL (`src/main/webapp/WEB-INF/views/`)
- **Model / business logic** → `com.frs.service` (plain Java)
- **Data access** → `com.frs.dao` (plain JDBC via `com.frs.util.DBUtil`)
- **Auth** → `com.frs.filter.AuthFilter` (login wall + admin-only `/admin/*`)
- **Password hashing** → BCrypt (`org.mindrot:jbcrypt`)
- **Database** → MySQL 8 (`flightdb`; schema + seed data auto-created on startup
  by `com.frs.listener.AppInitListener` from `schema.sql` / `data.sql`)

## Run

Requirements: JDK 17+, Maven 3.8+, MySQL 8 running locally
(username `root`, password `root` — change in `src/main/resources/db.properties`
if yours differ).

### Easiest (Mac/Linux)

```bash
./run.sh
```

### Easiest (Windows)

Double-click `run.bat`, or run it from cmd:

```bat
run.bat
```

Both scripts build the WAR, download Tomcat 11 on the first run, deploy the
app as ROOT and start the server. Then open: `http://localhost:8080`
(first start takes ~20-25 seconds while the database initializes).

Stop the server with: `~/Downloads/apache-tomcat-11.0.26/bin/shutdown.sh`

### Manual steps (any OS, including Windows)

```bash
mvn package
```

This builds `target/flight-reservation-system.war`. Then:

1. Download Tomcat 11 (Core zip) from <https://tomcat.apache.org/download-11.cgi>
   and extract it.
2. Delete the default `<tomcat>/webapps/ROOT` folder.
3. Copy the WAR as `<tomcat>/webapps/ROOT.war`.
4. Run `<tomcat>/bin/startup.sh` (Mac/Linux) or `<tomcat>\bin\startup.bat` (Windows).
5. Open `http://localhost:8080` (wait ~20-25s on the first start).

## Default logins

- Admin: `admin@frs.com` / `admin123`
- Users: sign up from the home page, or use seeded users (see `data.sql`)

## Features

Search flights by source/destination/date → book 1–10 passengers (sequential
passenger entry) → one ticket per passenger → My Bookings → view/print tickets →
cancel whole booking or single ticket (seats released). Admin: add flights
(unique flight number), view flights with upcoming/completed journey stats.
