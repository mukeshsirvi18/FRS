@echo off
REM Flight Reservation System - one-command run (Servlet + JSP on Tomcat 11)
REM Usage: run.bat  (double-click ya cmd me chalayein)
setlocal
cd /d %~dp0

echo --- Checking prerequisites...
where java >nul 2>nul
if errorlevel 1 (echo ERROR: java nahi mila. JDK 17+ install karo. & exit /b 1)
where mvn >nul 2>nul
if errorlevel 1 (echo ERROR: maven nahi mila. & exit /b 1)

powershell -noprofile -command "try { $c = New-Object Net.Sockets.TcpClient; $c.Connect('127.0.0.1', 3306); $c.Close() } catch { Write-Host 'WARNING: MySQL localhost:3306 par nahi dikh raha - pehle MySQL start kar lena.' }"

echo --- Building WAR...
call mvn -q package -DskipTests
if errorlevel 1 (echo ERROR: build fail ho gaya. & exit /b 1)

set TOMCAT_VER=11.0.26
set TOMCAT_DIR=%USERPROFILE%\Downloads\apache-tomcat-%TOMCAT_VER%

if not exist "%TOMCAT_DIR%" (
  echo --- Tomcat %TOMCAT_VER% download ho raha hai (pehli baar)...
  if not exist "%USERPROFILE%\Downloads" mkdir "%USERPROFILE%\Downloads"
  curl -sL -o "%USERPROFILE%\Downloads\tomcat11.zip" "https://dlcdn.apache.org/tomcat/tomcat-11/v%TOMCAT_VER%/bin/apache-tomcat-%TOMCAT_VER%.zip"
  if errorlevel 1 (echo ERROR: Tomcat download fail ho gaya. & exit /b 1)
  tar -xf "%USERPROFILE%\Downloads\tomcat11.zip" -C "%USERPROFILE%\Downloads"
  if errorlevel 1 (echo ERROR: Tomcat extract fail ho gaya. & exit /b 1)
)

echo --- Deploying...
if exist "%TOMCAT_DIR%\webapps\ROOT" rmdir /s /q "%TOMCAT_DIR%\webapps\ROOT"
copy /y "target\flight-reservation-system.war" "%TOMCAT_DIR%\webapps\ROOT.war" >nul
if errorlevel 1 (echo ERROR: WAR copy fail ho gaya. & exit /b 1)

echo --- Starting Tomcat...
call "%TOMCAT_DIR%\bin\startup.bat"

echo.
echo Ho gaya! Khol: http://localhost:8080  (pehli baar 20-25 sec wait karna)
echo Band karne ke liye: %TOMCAT_DIR%\bin\shutdown.bat
endlocal
