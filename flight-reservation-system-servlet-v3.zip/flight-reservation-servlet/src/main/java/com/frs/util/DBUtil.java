package com.frs.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * JDBC connection factory for the Flight Reservation System.
 * Reads connection settings from {@code db.properties} on the classpath;
 * falls back to local MySQL defaults when the file is missing.
 */
public final class DBUtil {

    private static final Logger LOG = Logger.getLogger(DBUtil.class.getName());

    private static final String DEFAULT_URL =
            "jdbc:mysql://localhost:3306/flightdb?createDatabaseIfNotExist=true&useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String DEFAULT_USERNAME = "root";
    private static final String DEFAULT_PASSWORD = "root";

    private static final String URL;
    private static final String USERNAME;
    private static final String PASSWORD;

    static {
        String url = DEFAULT_URL;
        String username = DEFAULT_USERNAME;
        String password = DEFAULT_PASSWORD;
        try (InputStream in = DBUtil.class.getClassLoader().getResourceAsStream("db.properties")) {
            if (in != null) {
                Properties props = new Properties();
                props.load(in);
                url = props.getProperty("db.url", url);
                username = props.getProperty("db.username", username);
                password = props.getProperty("db.password", password);
            } else {
                LOG.info("db.properties not found on classpath; using default DB settings.");
            }
        } catch (IOException e) {
            LOG.log(Level.WARNING, "Could not read db.properties; using default DB settings.", e);
        }
        URL = url;
        USERNAME = username;
        PASSWORD = password;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("MySQL JDBC driver not found on classpath: " + e.getMessage());
        }
    }

    private DBUtil() {
    }

    /**
     * Opens a new JDBC connection. Callers must close it (try-with-resources).
     */
    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }
}
