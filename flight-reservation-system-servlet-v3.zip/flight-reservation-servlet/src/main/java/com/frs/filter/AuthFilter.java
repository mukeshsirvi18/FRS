package com.frs.filter;

import com.frs.model.User;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.logging.Logger;

/**
 * Replaces LoginInterceptor + AdminInterceptor (see the old WebConfig for the
 * exact protected path patterns):
 * <ul>
 *   <li>Unauthenticated access to a protected user page saves the target URL
 *       in the session as {@code postLoginRedirect} and redirects to /login,
 *       so the user lands exactly where they wanted to go after logging in.</li>
 *   <li>{@code /admin/*} additionally requires the Admin role; a logged-in
 *       non-admin gets a 403 rendered through error.jsp.</li>
 *   <li>Static resources and public pages pass through untouched.</li>
 * </ul>
 */
@WebFilter("/*")
public class AuthFilter implements Filter {

    private static final Logger log = Logger.getLogger(AuthFilter.class.getName());

    /** Session attribute holding the URL to resume after login. */
    public static final String POST_LOGIN_REDIRECT = "postLoginRedirect";

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;

        String path = req.getRequestURI().substring(req.getContextPath().length());
        if (path.isEmpty()) {
            path = "/";
        }

        // Public: landing page, auth pages, the (controller-guarded) search
        // form post, and static assets.
        if (isPublicPage(path) || isStaticResource(path)) {
            chain.doFilter(request, response);
            return;
        }

        HttpSession session = req.getSession(false);
        User user = session == null ? null : (User) session.getAttribute("user");

        // Admin area: login required + Admin role required.
        if (isAdminPath(path)) {
            if (user == null) {
                resp.sendRedirect(req.getContextPath() + "/login");
                return;
            }
            if (!user.isAdmin()) {
                log.warning("Forbidden admin access attempt by user " + user.getEmail());
                resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
                req.setAttribute("errorTitle", "403 - 403 FORBIDDEN");
                req.setAttribute("errorMessage", "Admin access only.");
                req.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(request, response);
                return;
            }
            chain.doFilter(request, response);
            return;
        }

        // Protected user pages (old LoginInterceptor patterns).
        if (isProtectedUserPath(path) && user == null) {
            String target = req.getRequestURI();
            String query = req.getQueryString();
            if (query != null && !query.isBlank()) {
                target += "?" + query;
            }
            req.getSession(true).setAttribute(POST_LOGIN_REDIRECT, target);
            log.fine("Unauthenticated request to " + target + "; saved for post-login resume");
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        chain.doFilter(request, response);
    }

    private boolean isPublicPage(String path) {
        return "/".equals(path)
                || "/login".equals(path)
                || "/signup".equals(path)
                || "/search".equals(path)
                || "/error".equals(path);
    }

    private boolean isStaticResource(String path) {
        return path.startsWith("/css/")
                || path.startsWith("/js/")
                || path.startsWith("/images/")
                || path.startsWith("/img/")
                || path.startsWith("/fonts/")
                || path.startsWith("/assets/")
                || path.startsWith("/static/")
                || path.startsWith("/webjars/")
                || "/favicon.ico".equals(path);
    }

    private boolean isAdminPath(String path) {
        return "/admin".equals(path) || path.startsWith("/admin/");
    }

    /**
     * Old WebConfig LoginInterceptor patterns:
     * /flights, /book/**, /dashboard, /my-bookings, /bookings/**, /tickets/**
     */
    private boolean isProtectedUserPath(String path) {
        return "/flights".equals(path)
                || "/dashboard".equals(path)
                || "/my-bookings".equals(path)
                || isUnder(path, "/book")
                || isUnder(path, "/bookings")
                || isUnder(path, "/tickets");
    }

    private boolean isUnder(String path, String prefix) {
        return path.equals(prefix) || path.startsWith(prefix + "/");
    }
}
