package com.frs.dao;

import com.frs.model.User;
import com.frs.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Plain-JDBC replacement for the Spring JdbcTemplate-based UserDao.
 * Public method names, parameters and return types are identical to the original.
 * Each single-argument method opens and closes its own connection; the
 * two-argument overloads accept a caller-managed connection so service code can
 * run several writes inside one manual transaction (they never close it).
 */
public class UserDao {

    private static final Logger log = Logger.getLogger(UserDao.class.getName());

    public Optional<User> findByEmail(String email) {
        try (Connection conn = DBUtil.getConnection()) {
            return findByEmail(email, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Optional<User> findByEmail(String email, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT user_id, email, password, role FROM `user` WHERE email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public Optional<User> findById(Long userId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findById(userId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Optional<User> findById(Long userId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT user_id, email, password, role FROM `user` WHERE user_id = ?")) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public boolean existsByEmail(String email) {
        try (Connection conn = DBUtil.getConnection()) {
            return existsByEmail(email, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public boolean existsByEmail(String email, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM `user` WHERE email = ?")) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public Long save(User user) {
        try (Connection conn = DBUtil.getConnection()) {
            return save(user, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Long save(User user, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO `user` (email, password, role) VALUES (?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, user.getEmail());
            ps.setString(2, user.getPassword());
            ps.setString(3, user.getRole());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : null;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    private User mapRow(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getLong("user_id"));
        user.setEmail(rs.getString("email"));
        user.setPassword(rs.getString("password"));
        user.setRole(rs.getString("role"));
        return user;
    }

    private RuntimeException dataAccessError(SQLException e) {
        log.log(Level.SEVERE, "Database access error", e);
        return new RuntimeException("Database error: " + e.getMessage(), e);
    }
}
