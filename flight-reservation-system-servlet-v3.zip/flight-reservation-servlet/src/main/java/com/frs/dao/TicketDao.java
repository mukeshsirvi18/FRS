package com.frs.dao;

import com.frs.model.Ticket;
import com.frs.util.DBUtil;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Plain-JDBC replacement for the Spring JdbcTemplate-based TicketDao.
 * Public method names, parameters and return types are identical to the original.
 * Each single-argument method opens and closes its own connection; the
 * two-argument overloads accept a caller-managed connection so service code can
 * run several writes inside one manual transaction (they never close it).
 */
public class TicketDao {

    private static final Logger log = Logger.getLogger(TicketDao.class.getName());

    public Long save(Ticket ticket) {
        try (Connection conn = DBUtil.getConnection()) {
            return save(ticket, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Long save(Ticket ticket, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO ticket (passenger_name, gender, age, journey_date, seat_no, booking_id, status) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, ticket.getPassengerName());
            ps.setString(2, ticket.getGender());
            if (ticket.getAge() != null) {
                ps.setInt(3, ticket.getAge());
            } else {
                ps.setNull(3, Types.INTEGER);
            }
            ps.setDate(4, Date.valueOf(ticket.getJourneyDate()));
            ps.setString(5, ticket.getSeatNo());
            ps.setLong(6, ticket.getBookingId());
            ps.setString(7, ticket.getStatus());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : null;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public Optional<Ticket> findById(Long ticketId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findById(ticketId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Optional<Ticket> findById(Long ticketId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT ticket_id, passenger_name, gender, age, journey_date, seat_no, booking_id, status " +
                "FROM ticket WHERE ticket_id = ?")) {
            ps.setLong(1, ticketId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public List<Ticket> findByBookingId(Long bookingId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findByBookingId(bookingId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public List<Ticket> findByBookingId(Long bookingId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT ticket_id, passenger_name, gender, age, journey_date, seat_no, booking_id, status " +
                "FROM ticket WHERE booking_id = ? ORDER BY ticket_id")) {
            ps.setLong(1, bookingId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Ticket> tickets = new ArrayList<>();
                while (rs.next()) {
                    tickets.add(mapRow(rs));
                }
                return tickets;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Number of active (BOOKED) tickets on a flight - drives seat availability. */
    public int countActiveByFlightId(Long flightId) {
        try (Connection conn = DBUtil.getConnection()) {
            return countActiveByFlightId(flightId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public int countActiveByFlightId(Long flightId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM ticket t JOIN booking b ON t.booking_id = b.booking_id " +
                "WHERE b.flight_id = ? AND t.status = 'BOOKED'")) {
            ps.setLong(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Seat numbers currently occupied (BOOKED) on a flight. */
    public List<String> findActiveSeatNosByFlightId(Long flightId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findActiveSeatNosByFlightId(flightId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public List<String> findActiveSeatNosByFlightId(Long flightId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT t.seat_no FROM ticket t JOIN booking b ON t.booking_id = b.booking_id " +
                "WHERE b.flight_id = ? AND t.status = 'BOOKED'")) {
            ps.setLong(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                List<String> seatNos = new ArrayList<>();
                while (rs.next()) {
                    seatNos.add(rs.getString(1));
                }
                return seatNos;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public int countActiveByBookingId(Long bookingId) {
        try (Connection conn = DBUtil.getConnection()) {
            return countActiveByBookingId(bookingId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public int countActiveByBookingId(Long bookingId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM ticket WHERE booking_id = ? AND status = 'BOOKED'")) {
            ps.setLong(1, bookingId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public int updateStatus(Long ticketId, String status) {
        try (Connection conn = DBUtil.getConnection()) {
            return updateStatus(ticketId, status, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public int updateStatus(Long ticketId, String status, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE ticket SET status = ? WHERE ticket_id = ?")) {
            ps.setString(1, status);
            ps.setLong(2, ticketId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public int updateStatusByBookingId(Long bookingId, String status) {
        try (Connection conn = DBUtil.getConnection()) {
            return updateStatusByBookingId(bookingId, status, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public int updateStatusByBookingId(Long bookingId, String status, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE ticket SET status = ? WHERE booking_id = ? AND status = 'BOOKED'")) {
            ps.setString(1, status);
            ps.setLong(2, bookingId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    private Ticket mapRow(ResultSet rs) throws SQLException {
        Ticket ticket = new Ticket();
        ticket.setTicketId(rs.getLong("ticket_id"));
        ticket.setPassengerName(rs.getString("passenger_name"));
        ticket.setGender(rs.getString("gender"));
        int age = rs.getInt("age");
        ticket.setAge(rs.wasNull() ? null : age);
        Date journeyDate = rs.getDate("journey_date");
        ticket.setJourneyDate(journeyDate != null ? journeyDate.toLocalDate() : null);
        ticket.setSeatNo(rs.getString("seat_no"));
        ticket.setBookingId(rs.getLong("booking_id"));
        ticket.setStatus(rs.getString("status"));
        return ticket;
    }

    private RuntimeException dataAccessError(SQLException e) {
        log.log(Level.SEVERE, "Database access error", e);
        return new RuntimeException("Database error: " + e.getMessage(), e);
    }
}
