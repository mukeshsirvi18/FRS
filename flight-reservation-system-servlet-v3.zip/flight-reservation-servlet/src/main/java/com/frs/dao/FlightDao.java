package com.frs.dao;

import com.frs.model.Flight;
import com.frs.util.DBUtil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Plain-JDBC replacement for the Spring JdbcTemplate-based FlightDao.
 * Public method names, parameters and return types are identical to the original.
 * Each single-argument method opens and closes its own connection; the
 * two-argument overloads accept a caller-managed connection so service code can
 * run several writes inside one manual transaction (they never close it).
 */
public class FlightDao {

    private static final Logger log = Logger.getLogger(FlightDao.class.getName());

    public List<Flight> findAll() {
        try (Connection conn = DBUtil.getConnection()) {
            return findAll(conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public List<Flight> findAll(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT flight_id, flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat " +
                "FROM flight ORDER BY flight_number");
             ResultSet rs = ps.executeQuery()) {
            List<Flight> flights = new ArrayList<>();
            while (rs.next()) {
                flights.add(mapRow(rs));
            }
            return flights;
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public Optional<Flight> findById(Long flightId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findById(flightId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Optional<Flight> findById(Long flightId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT flight_id, flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat " +
                "FROM flight WHERE flight_id = ?")) {
            ps.setLong(1, flightId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public List<Flight> search(String source, String destination) {
        try (Connection conn = DBUtil.getConnection()) {
            return search(source, destination, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public List<Flight> search(String source, String destination, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT flight_id, flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat " +
                "FROM flight WHERE source = ? AND destination = ? ORDER BY departure_time")) {
            ps.setString(1, source);
            ps.setString(2, destination);
            try (ResultSet rs = ps.executeQuery()) {
                List<Flight> flights = new ArrayList<>();
                while (rs.next()) {
                    flights.add(mapRow(rs));
                }
                return flights;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public Long save(Flight flight) {
        try (Connection conn = DBUtil.getConnection()) {
            return save(flight, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Long save(Flight flight, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, flight.getFlightNumber());
            ps.setString(2, flight.getSource());
            ps.setString(3, flight.getDestination());
            ps.setString(4, flight.getDepartureTime());
            ps.setString(5, flight.getArrivalTime());
            ps.setInt(6, flight.getCapacity());
            ps.setDouble(7, flight.getPricePerSeat());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : null;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Used by the service to enforce the unique-flight-number rule. */
    public boolean existsByFlightNumber(String flightNumber) {
        try (Connection conn = DBUtil.getConnection()) {
            return existsByFlightNumber(flightNumber, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public boolean existsByFlightNumber(String flightNumber, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT COUNT(*) FROM flight WHERE flight_number = ?")) {
            ps.setString(1, flightNumber);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    private Flight mapRow(ResultSet rs) throws SQLException {
        Flight flight = new Flight();
        flight.setFlightId(rs.getLong("flight_id"));
        flight.setFlightNumber(rs.getString("flight_number"));
        flight.setSource(rs.getString("source"));
        flight.setDestination(rs.getString("destination"));
        flight.setDepartureTime(rs.getString("departure_time"));
        flight.setArrivalTime(rs.getString("arrival_time"));
        flight.setCapacity(rs.getInt("capacity"));
        flight.setPricePerSeat(rs.getDouble("price_per_seat"));
        return flight;
    }

    private RuntimeException dataAccessError(SQLException e) {
        log.log(Level.SEVERE, "Database access error", e);
        return new RuntimeException("Database error: " + e.getMessage(), e);
    }
}
