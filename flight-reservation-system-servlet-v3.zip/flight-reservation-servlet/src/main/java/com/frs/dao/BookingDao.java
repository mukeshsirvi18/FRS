package com.frs.dao;

import com.frs.model.Booking;
import com.frs.model.dto.FlightJourneyStats;
import com.frs.util.DBUtil;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Plain-JDBC replacement for the Spring JdbcTemplate-based BookingDao.
 * Public method names, parameters and return types are identical to the original.
 * Each single-argument method opens and closes its own connection; the
 * two-argument overloads accept a caller-managed connection so service code can
 * run several writes inside one manual transaction (they never close it).
 */
public class BookingDao {

    private static final Logger log = Logger.getLogger(BookingDao.class.getName());

    public Long save(Booking booking) {
        try (Connection conn = DBUtil.getConnection()) {
            return save(booking, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Long save(Booking booking, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "INSERT INTO booking (booking_date, travel_date, seats, total_price, status, flight_id, user_id) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setDate(1, Date.valueOf(booking.getBookingDate()));
            ps.setDate(2, Date.valueOf(booking.getTravelDate()));
            ps.setInt(3, booking.getSeats());
            ps.setDouble(4, booking.getTotalPrice());
            ps.setString(5, booking.getStatus());
            ps.setLong(6, booking.getFlightId());
            ps.setLong(7, booking.getUserId());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                return keys.next() ? keys.getLong(1) : null;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public Optional<Booking> findById(Long bookingId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findById(bookingId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public Optional<Booking> findById(Long bookingId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT booking_id, booking_date, travel_date, seats, total_price, status, flight_id, user_id " +
                "FROM booking WHERE booking_id = ?")) {
            ps.setLong(1, bookingId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(mapRow(rs)) : Optional.empty();
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public List<Booking> findByUserId(Long userId) {
        try (Connection conn = DBUtil.getConnection()) {
            return findByUserId(userId, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public List<Booking> findByUserId(Long userId, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT booking_id, booking_date, travel_date, seats, total_price, status, flight_id, user_id " +
                "FROM booking WHERE user_id = ? ORDER BY booking_id DESC")) {
            ps.setLong(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                List<Booking> bookings = new ArrayList<>();
                while (rs.next()) {
                    bookings.add(mapRow(rs));
                }
                return bookings;
            }
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    public int updateStatus(Long bookingId, String status) {
        try (Connection conn = DBUtil.getConnection()) {
            return updateStatus(bookingId, status, conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public int updateStatus(Long bookingId, String status, Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "UPDATE booking SET status = ? WHERE booking_id = ?")) {
            ps.setString(1, status);
            ps.setLong(2, bookingId);
            return ps.executeUpdate();
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /**
     * Per-flight, per-journey-date aggregates for the admin "View Flights" page.
     * Only flights that have at least one active (BOOKED) booking are returned.
     */
    public List<FlightJourneyStats> findJourneyStats() {
        try (Connection conn = DBUtil.getConnection()) {
            return findJourneyStats(conn);
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    /** Shared-connection variant; does NOT close the connection. */
    public List<FlightJourneyStats> findJourneyStats(Connection conn) {
        try (PreparedStatement ps = conn.prepareStatement(
                "SELECT f.flight_id, f.flight_number, f.source, f.destination, b.travel_date AS journey_date, " +
                "COUNT(DISTINCT b.booking_id) AS total_bookings, " +
                "COUNT(t.ticket_id) AS total_passengers, " +
                "COALESCE(SUM(b.total_price), 0) AS total_revenue " +
                "FROM booking b JOIN flight f ON b.flight_id = f.flight_id " +
                "LEFT JOIN ticket t ON t.booking_id = b.booking_id AND t.status = 'BOOKED' " +
                "WHERE b.status = 'BOOKED' " +
                "GROUP BY f.flight_id, f.flight_number, f.source, f.destination, b.travel_date " +
                "ORDER BY b.travel_date");
             ResultSet rs = ps.executeQuery()) {
            List<FlightJourneyStats> stats = new ArrayList<>();
            while (rs.next()) {
                FlightJourneyStats s = new FlightJourneyStats();
                s.setFlightId(rs.getLong("flight_id"));
                s.setFlightNumber(rs.getString("flight_number"));
                s.setSource(rs.getString("source"));
                s.setDestination(rs.getString("destination"));
                Date journeyDate = rs.getDate("journey_date");
                s.setJourneyDate(journeyDate != null ? journeyDate.toLocalDate() : null);
                s.setTotalBookings(rs.getInt("total_bookings"));
                s.setTotalPassengers(rs.getInt("total_passengers"));
                s.setTotalRevenue(rs.getDouble("total_revenue"));
                stats.add(s);
            }
            return stats;
        } catch (SQLException e) {
            throw dataAccessError(e);
        }
    }

    private Booking mapRow(ResultSet rs) throws SQLException {
        Booking booking = new Booking();
        booking.setBookingId(rs.getLong("booking_id"));
        Date bookingDate = rs.getDate("booking_date");
        booking.setBookingDate(bookingDate != null ? bookingDate.toLocalDate() : null);
        Date travelDate = rs.getDate("travel_date");
        booking.setTravelDate(travelDate != null ? travelDate.toLocalDate() : null);
        booking.setSeats(rs.getInt("seats"));
        booking.setTotalPrice(rs.getDouble("total_price"));
        booking.setStatus(rs.getString("status"));
        booking.setFlightId(rs.getLong("flight_id"));
        booking.setUserId(rs.getLong("user_id"));
        return booking;
    }

    private RuntimeException dataAccessError(SQLException e) {
        log.log(Level.SEVERE, "Database access error", e);
        return new RuntimeException("Database error: " + e.getMessage(), e);
    }
}
