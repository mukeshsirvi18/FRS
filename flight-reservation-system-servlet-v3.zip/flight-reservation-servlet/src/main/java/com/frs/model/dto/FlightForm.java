package com.frs.model.dto;

/**
 * Backing form for the admin "Add Flight" page.
 * All fields are required; flight number must be unique (checked in service).
 */
public class FlightForm {

    private String flightNumber;

    private String source;

    private String destination;

    /** Time of day as "HH:mm" (from an HTML time input). */
    private String departureTime;

    /** Time of day as "HH:mm" (from an HTML time input). */
    private String arrivalTime;

    private Integer capacity = 20; // default: all flights run with 20 seats

    private Double pricePerSeat;

    public FlightForm() {
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Double getPricePerSeat() {
        return pricePerSeat;
    }

    public void setPricePerSeat(Double pricePerSeat) {
        this.pricePerSeat = pricePerSeat;
    }
}
