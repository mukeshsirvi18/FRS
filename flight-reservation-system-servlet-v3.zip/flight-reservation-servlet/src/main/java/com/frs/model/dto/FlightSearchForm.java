package com.frs.model.dto;

import java.time.LocalDate;

/**
 * Backing form for the "Search Flights" form on the home page.
 * Validation is performed manually in the servlets.
 */
public class FlightSearchForm {

    private String source;

    private String destination;

    private LocalDate travelDate;

    public FlightSearchForm() {
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public LocalDate getTravelDate() {
        return travelDate;
    }

    public void setTravelDate(LocalDate travelDate) {
        this.travelDate = travelDate;
    }
}
