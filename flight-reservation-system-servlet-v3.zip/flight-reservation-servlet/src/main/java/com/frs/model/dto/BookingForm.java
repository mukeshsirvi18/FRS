package com.frs.model.dto;

import java.time.LocalDate;

/**
 * Backing form for the Booking Form page.
 * Validation is performed manually in the servlets.
 */
public class BookingForm {

    /** Carried as a hidden field; also present in the URL. */
    private Long flightId;

    private LocalDate journeyDate;

    private Integer passengers;

    public BookingForm() {
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public LocalDate getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(LocalDate journeyDate) {
        this.journeyDate = journeyDate;
    }

    public Integer getPassengers() {
        return passengers;
    }

    public void setPassengers(Integer passengers) {
        this.passengers = passengers;
    }
}
