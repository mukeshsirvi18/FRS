package com.frs.model.dto;

/** One passenger entry on the "Add Passengers" page. */
public class PassengerForm {

    private String passengerName;

    private String gender;

    private Integer age;

    public PassengerForm() {
    }

    public String getPassengerName() {
        return passengerName;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public Integer getAge() {
        return age;
    }

    public void setAge(Integer age) {
        this.age = age;
    }
}
