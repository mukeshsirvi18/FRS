package com.frs.service;

import com.frs.dao.BookingDao;
import com.frs.dao.FlightDao;
import com.frs.dao.TicketDao;
import com.frs.model.Flight;
import com.frs.model.dto.FlightForm;
import com.frs.model.dto.FlightJourneyStats;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Plain-Java replacement for the Spring-based FlightService.
 * Public method names and signatures are identical to the original
 * (minus Spring annotations). Bean-validation rules from FlightForm
 * are enforced manually with the same message texts.
 */
public class FlightService {

    private static final Logger log = Logger.getLogger(FlightService.class.getName());

    private final FlightDao flightDao = new FlightDao();
    private final TicketDao ticketDao = new TicketDao();
    private final BookingDao bookingDao = new BookingDao();

    /** All flights with live availability and trip status attached. */
    public List<Flight> getAllFlights() {
        List<Flight> flights = flightDao.findAll();
        flights.forEach(this::enrich);
        return flights;
    }

    /** Flights matching source/destination with live availability attached. */
    public List<Flight> searchFlights(String source, String destination) {
        if (source == null || source.isBlank()) {
            throw new IllegalArgumentException("Source is required");
        }
        if (destination == null || destination.isBlank()) {
            throw new IllegalArgumentException("Destination is required");
        }
        List<Flight> flights = flightDao.search(source.trim(), destination.trim());
        flights.forEach(this::enrich);
        log.info("Flight search " + source + " -> " + destination + " returned " + flights.size() + " result(s)");
        return flights;
    }

    public Flight getFlight(Long flightId) {
        Flight flight = flightDao.findById(flightId)
                .orElseThrow(() -> new IllegalArgumentException("Flight not found."));
        enrich(flight);
        return flight;
    }

    /**
     * Adds a new flight. Flight numbers must be unique; a duplicate is
     * rejected with a validation error.
     */
    public Flight addFlight(FlightForm form) {
        validateFlightForm(form);
        String flightNumber = form.getFlightNumber().trim();
        if (flightDao.existsByFlightNumber(flightNumber)) {
            log.warning("Duplicate flight number rejected: " + flightNumber);
            throw new IllegalArgumentException(
                    "Flight number " + flightNumber + " already exists. Please use a unique flight number.");
        }
        Flight flight = new Flight();
        flight.setFlightNumber(flightNumber);
        flight.setSource(form.getSource().trim());
        flight.setDestination(form.getDestination().trim());
        flight.setDepartureTime(normalizeTime(form.getDepartureTime()));
        flight.setArrivalTime(normalizeTime(form.getArrivalTime()));
        flight.setCapacity(form.getCapacity());
        flight.setPricePerSeat(form.getPricePerSeat());
        Long id = flightDao.save(flight);
        flight.setFlightId(id);
        log.info("Added new flight " + flightNumber + " (" + flight.getSource() + " -> " + flight.getDestination() + ")");
        enrich(flight);
        return flight;
    }

    /** Available seats = capacity - active (BOOKED) tickets. */
    public int getAvailableSeats(Long flightId) {
        Flight flight = flightDao.findById(flightId)
                .orElseThrow(() -> new IllegalArgumentException("Flight not found."));
        return Math.max(0, flight.getCapacity() - ticketDao.countActiveByFlightId(flightId));
    }

    /**
     * Per-flight, per-journey-date aggregates (only flights that have
     * bookings), split into upcoming and completed journeys for the
     * admin "View Flights" tabs.
     */
    public List<FlightJourneyStats> getUpcomingJourneys() {
        LocalDate today = LocalDate.now();
        return loadJourneyStats().stream()
                .filter(s -> !s.getJourneyDate().isBefore(today))
                .collect(Collectors.toList());
    }

    public List<FlightJourneyStats> getCompletedJourneys() {
        LocalDate today = LocalDate.now();
        return loadJourneyStats().stream()
                .filter(s -> s.getJourneyDate().isBefore(today))
                .collect(Collectors.toList());
    }

    /** Manual replica of the bean-validation constraints on FlightForm. */
    private void validateFlightForm(FlightForm form) {
        if (form == null) {
            throw new IllegalArgumentException("Flight data is required");
        }
        String flightNumber = form.getFlightNumber();
        if (flightNumber == null || flightNumber.isBlank()) {
            throw new IllegalArgumentException("Flight number is required");
        }
        if (flightNumber.length() > 30) {
            throw new IllegalArgumentException("Flight number must be at most 30 characters");
        }
        String source = form.getSource();
        if (source == null || source.isBlank()) {
            throw new IllegalArgumentException("Source is required");
        }
        if (source.length() > 50) {
            throw new IllegalArgumentException("Source must be at most 50 characters");
        }
        String destination = form.getDestination();
        if (destination == null || destination.isBlank()) {
            throw new IllegalArgumentException("Destination is required");
        }
        if (destination.length() > 50) {
            throw new IllegalArgumentException("Destination must be at most 50 characters");
        }
        if (form.getDepartureTime() == null || form.getDepartureTime().isBlank()) {
            throw new IllegalArgumentException("Departure time is required");
        }
        if (form.getArrivalTime() == null || form.getArrivalTime().isBlank()) {
            throw new IllegalArgumentException("Arrival time is required");
        }
        if (form.getCapacity() == null) {
            throw new IllegalArgumentException("Capacity is required");
        }
        if (form.getCapacity() < 1) {
            throw new IllegalArgumentException("Capacity must be at least 1");
        }
        if (form.getPricePerSeat() == null) {
            throw new IllegalArgumentException("Price per seat is required");
        }
        if (form.getPricePerSeat() <= 0) {
            throw new IllegalArgumentException("Price must be positive");
        }
    }

    private List<FlightJourneyStats> loadJourneyStats() {
        LocalDate today = LocalDate.now();
        List<FlightJourneyStats> stats = bookingDao.findJourneyStats();
        stats.forEach(s -> s.setDaysUntilJourney(ChronoUnit.DAYS.between(today, s.getJourneyDate())));
        return stats;
    }

    private void enrich(Flight flight) {
        int booked = ticketDao.countActiveByFlightId(flight.getFlightId());
        flight.setAvailableSeats(Math.max(0, flight.getCapacity() - booked));
        flight.setTripStatus(deriveTripStatus(flight.getDepartureTime()));
    }

    /**
     * All flights run daily, so a flight is "Completed" once today's
     * departure time has passed, otherwise "Upcoming".
     */
    private String deriveTripStatus(String departureTime) {
        if (departureTime == null || departureTime.isBlank()) {
            return "Upcoming";
        }
        try {
            LocalTime dep = LocalTime.parse(departureTime.trim());
            return dep.isBefore(LocalTime.now()) ? "Completed" : "Upcoming";
        } catch (Exception e) {
            return "Upcoming";
        }
    }

    private String normalizeTime(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return LocalTime.parse(value.trim()).toString();
        } catch (Exception e) {
            return value.trim();
        }
    }
}
