package com.frs.service;

import com.frs.dao.BookingDao;
import com.frs.dao.FlightDao;
import com.frs.dao.TicketDao;
import com.frs.model.Booking;
import com.frs.model.Flight;
import com.frs.model.Ticket;
import com.frs.model.dto.PassengerForm;
import com.frs.util.DBUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Plain-Java replacement for the Spring-based BookingService.
 * Public method names and signatures are identical to the original
 * (minus Spring annotations). The @Transactional methods are reproduced
 * with manual JDBC transaction control: all writes run on one connection
 * with auto-commit off, committed on success and rolled back on any failure.
 * Bean-validation rules from PassengerForm (and the BookingForm fields that
 * feed this service) are enforced manually with the same message texts.
 */
public class BookingService {

    private static final Logger log = Logger.getLogger(BookingService.class.getName());

    private final BookingDao bookingDao = new BookingDao();
    private final TicketDao ticketDao = new TicketDao();
    private final FlightDao flightDao = new FlightDao();

    /**
     * Creates a booking plus one ticket per passenger in a single
     * transaction. Re-checks seat availability inside the transaction
     * so two concurrent bookings cannot overbook.
     */
    public Booking createBooking(Long userId, Long flightId, LocalDate travelDate,
                                 List<PassengerForm> passengers) {
        validateCreateBooking(travelDate, passengers);

        Long bookingId;
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            Flight flight = flightDao.findById(flightId, conn)
                    .orElseThrow(() -> new IllegalArgumentException("Flight not found."));

            int available = flight.getCapacity() - ticketDao.countActiveByFlightId(flightId, conn);
            if (passengers.size() > available) {
                throw new IllegalStateException(
                        "Only " + available + " seat(s) available on flight " + flight.getFlightNumber() + ".");
            }

            Booking booking = new Booking();
            booking.setBookingDate(LocalDate.now());
            booking.setTravelDate(travelDate);
            booking.setSeats(passengers.size());
            booking.setTotalPrice(passengers.size() * flight.getPricePerSeat());
            booking.setStatus(Booking.STATUS_BOOKED);
            booking.setFlightId(flightId);
            booking.setUserId(userId);
            bookingId = bookingDao.save(booking, conn);
            booking.setBookingId(bookingId);

            Set<Integer> occupied = parseSeatNumbers(ticketDao.findActiveSeatNosByFlightId(flightId, conn));
            int nextSeat = 1;
            for (PassengerForm p : passengers) {
                while (occupied.contains(nextSeat)) {
                    nextSeat++;
                }
                Ticket ticket = new Ticket();
                ticket.setPassengerName(p.getPassengerName().trim());
                ticket.setGender(p.getGender());
                ticket.setAge(p.getAge());
                ticket.setJourneyDate(travelDate);
                ticket.setSeatNo(String.valueOf(nextSeat));
                ticket.setBookingId(bookingId);
                ticket.setStatus(Ticket.STATUS_BOOKED);
                ticketDao.save(ticket, conn);
                occupied.add(nextSeat);
                nextSeat++;
            }

            conn.commit();
            log.info("Booking " + bookingId + " created: user " + userId + ", flight "
                    + flight.getFlightNumber() + ", " + passengers.size() + " passenger(s), date " + travelDate);
        } catch (SQLException e) {
            rollbackQuietly(conn);
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        } catch (RuntimeException e) {
            rollbackQuietly(conn);
            throw e;
        } finally {
            closeQuietly(conn);
        }
        return getBookingDetails(bookingId, userId);
    }

    /** Cancels a whole booking and all its active tickets (owner only). */
    public void cancelBooking(Long bookingId, Long userId) {
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            Booking booking = getOwnedBooking(bookingId, userId, conn);
            if (Booking.STATUS_CANCELLED.equals(booking.getStatus())) {
                throw new IllegalStateException("Booking is already cancelled.");
            }
            ticketDao.updateStatusByBookingId(bookingId, Ticket.STATUS_CANCELLED, conn);
            bookingDao.updateStatus(bookingId, Booking.STATUS_CANCELLED, conn);

            conn.commit();
            log.info("Booking " + bookingId + " cancelled by user " + userId);
        } catch (SQLException e) {
            rollbackQuietly(conn);
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        } catch (RuntimeException e) {
            rollbackQuietly(conn);
            throw e;
        } finally {
            closeQuietly(conn);
        }
    }

    /**
     * Cancels one ticket (owner only). When the last active ticket of a
     * booking is cancelled, the booking itself becomes CANCELLED.
     */
    public void cancelTicket(Long ticketId, Long userId) {
        Connection conn = null;
        try {
            conn = DBUtil.getConnection();
            conn.setAutoCommit(false);

            Ticket ticket = ticketDao.findById(ticketId, conn)
                    .orElseThrow(() -> new IllegalArgumentException("Ticket not found."));
            Booking booking = getOwnedBooking(ticket.getBookingId(), userId, conn);
            if (Ticket.STATUS_CANCELLED.equals(ticket.getStatus())) {
                throw new IllegalStateException("Ticket is already cancelled.");
            }
            ticketDao.updateStatus(ticketId, Ticket.STATUS_CANCELLED, conn);
            if (ticketDao.countActiveByBookingId(booking.getBookingId(), conn) == 0) {
                bookingDao.updateStatus(booking.getBookingId(), Booking.STATUS_CANCELLED, conn);
            }

            conn.commit();
            log.info("Ticket " + ticketId + " (booking " + booking.getBookingId() + ") cancelled by user " + userId);
        } catch (SQLException e) {
            rollbackQuietly(conn);
            throw new RuntimeException("Database error: " + e.getMessage(), e);
        } catch (RuntimeException e) {
            rollbackQuietly(conn);
            throw e;
        } finally {
            closeQuietly(conn);
        }
    }

    /** All bookings of a user, each with its flight and tickets. */
    public List<Booking> getMyBookings(Long userId) {
        List<Booking> bookings = bookingDao.findByUserId(userId);
        for (Booking b : bookings) {
            flightDao.findById(b.getFlightId()).ifPresent(b::setFlight);
            b.setTickets(ticketDao.findByBookingId(b.getBookingId()));
        }
        return bookings;
    }

    /** Booking + flight + tickets, verifying the booking belongs to the user. */
    public Booking getBookingDetails(Long bookingId, Long userId) {
        Booking booking = getOwnedBooking(bookingId, userId);
        flightDao.findById(booking.getFlightId()).ifPresent(booking::setFlight);
        booking.setTickets(ticketDao.findByBookingId(bookingId));
        return booking;
    }

    /** Ticket details, verifying the ticket belongs to the user. */
    public Ticket getTicketDetails(Long ticketId, Long userId) {
        Ticket ticket = ticketDao.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found."));
        getOwnedBooking(ticket.getBookingId(), userId); // ownership check
        return ticket;
    }

    private Booking getOwnedBooking(Long bookingId, Long userId) {
        Booking booking = bookingDao.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        if (!booking.getUserId().equals(userId)) {
            throw new SecurityException("You are not allowed to access this booking.");
        }
        return booking;
    }

    /** Transactional variant: runs on the caller's connection. */
    private Booking getOwnedBooking(Long bookingId, Long userId, Connection conn) {
        Booking booking = bookingDao.findById(bookingId, conn)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        if (!booking.getUserId().equals(userId)) {
            throw new SecurityException("You are not allowed to access this booking.");
        }
        return booking;
    }

    private Set<Integer> parseSeatNumbers(List<String> seatNos) {
        Set<Integer> result = new HashSet<>();
        for (String s : seatNos) {
            try {
                result.add(Integer.parseInt(s.trim()));
            } catch (Exception ignored) {
                // ignore non-numeric seat labels
            }
        }
        return result;
    }

    /**
     * Manual replica of the BookingForm rules that feed this service
     * (journey date, passenger count) plus every PassengerForm constraint.
     */
    private void validateCreateBooking(LocalDate travelDate, List<PassengerForm> passengers) {
        if (travelDate == null) {
            throw new IllegalArgumentException("Journey date is required");
        }
        if (travelDate.isBefore(LocalDate.now())) {
            throw new IllegalArgumentException("Journey date cannot be in the past");
        }
        if (passengers == null || passengers.isEmpty()) {
            throw new IllegalArgumentException("At least one passenger is required.");
        }
        if (passengers.size() > 10) {
            throw new IllegalArgumentException("Maximum 10 passengers allowed");
        }
        for (PassengerForm p : passengers) {
            validatePassenger(p);
        }
    }

    /** Manual replica of the bean-validation constraints on PassengerForm. */
    private void validatePassenger(PassengerForm p) {
        if (p == null) {
            throw new IllegalArgumentException("Passenger name is required");
        }
        String name = p.getPassengerName();
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("Passenger name is required");
        }
        if (name.length() > 50) {
            throw new IllegalArgumentException("Name must be at most 50 characters");
        }
        String gender = p.getGender();
        if (gender == null || gender.isBlank()) {
            throw new IllegalArgumentException("Gender is required");
        }
        if (!gender.matches("Male|Female|Other")) {
            throw new IllegalArgumentException("Select a valid gender");
        }
        Integer age = p.getAge();
        if (age == null) {
            throw new IllegalArgumentException("Age is required");
        }
        if (age < 1) {
            throw new IllegalArgumentException("Age must be at least 1");
        }
        if (age > 120) {
            throw new IllegalArgumentException("Age must be at most 120");
        }
    }

    private void rollbackQuietly(Connection conn) {
        if (conn != null) {
            try {
                conn.rollback();
            } catch (SQLException ignored) {
                // nothing more we can do; the original exception is already propagating
            }
        }
    }

    private void closeQuietly(Connection conn) {
        if (conn != null) {
            try {
                conn.close();
            } catch (SQLException ignored) {
                // connection cleanup is best-effort here
            }
        }
    }
}
