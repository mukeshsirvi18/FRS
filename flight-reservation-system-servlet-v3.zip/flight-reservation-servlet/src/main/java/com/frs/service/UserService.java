package com.frs.service;

import com.frs.dao.UserDao;
import com.frs.model.User;
import com.frs.model.dto.SignupForm;
import org.mindrot.jbcrypt.BCrypt;

import java.util.logging.Logger;

/**
 * Plain-Java replacement for the Spring-based UserService.
 * Public method names and signatures are identical to the original
 * (minus Spring annotations). BCrypt hashing uses jBCrypt directly.
 * Bean-validation rules from SignupForm/LoginForm are enforced manually
 * with the same message texts.
 */
public class UserService {

    private static final Logger log = Logger.getLogger(UserService.class.getName());

    /** Simple equivalent of the jakarta @Email check. */
    private static final String EMAIL_REGEX = "^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$";

    private final UserDao userDao = new UserDao();

    /**
     * Registers a new user. Throws IllegalArgumentException when the
     * email is already taken or the form violates its validation rules.
     */
    public User register(SignupForm form) {
        validateSignup(form);
        String email = form.getEmail().trim().toLowerCase();
        if (userDao.existsByEmail(email)) {
            log.warning("Signup rejected: email " + email + " already registered");
            throw new IllegalArgumentException("Email is already registered. Please login.");
        }
        User user = new User();
        user.setEmail(email);
        user.setPassword(BCrypt.hashpw(form.getPassword(), BCrypt.gensalt()));
        user.setRole(form.getRole());
        Long id = userDao.save(user);
        user.setUserId(id);
        log.info("New user registered: " + email + " (role " + user.getRole() + ")");
        return user;
    }

    /**
     * Authenticates a user. Throws IllegalArgumentException on
     * unknown email or wrong password.
     */
    public User authenticate(String email, String rawPassword) {
        validateLogin(email, rawPassword);
        String normalized = email.trim().toLowerCase();
        User user = userDao.findByEmail(normalized)
                .orElseThrow(() -> {
                    log.warning("Login failed: unknown email " + normalized);
                    return new IllegalArgumentException("Invalid email or password.");
                });
        if (!BCrypt.checkpw(rawPassword, user.getPassword())) {
            log.warning("Login failed: wrong password for " + normalized);
            throw new IllegalArgumentException("Invalid email or password.");
        }
        log.info("User logged in: " + normalized);
        return user;
    }

    /** Manual replica of the bean-validation constraints on SignupForm. */
    private void validateSignup(SignupForm form) {
        if (form == null) {
            throw new IllegalArgumentException("Signup data is required");
        }
        String email = form.getEmail();
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (!email.matches(EMAIL_REGEX)) {
            throw new IllegalArgumentException("Enter a valid email address");
        }
        if (email.length() > 100) {
            throw new IllegalArgumentException("Email must be at most 100 characters");
        }
        String password = form.getPassword();
        if (password == null || password.isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
        if (password.length() < 6 || password.length() > 100) {
            throw new IllegalArgumentException("Password must be at least 6 characters");
        }
        String role = form.getRole();
        if (role == null || role.isBlank()) {
            throw new IllegalArgumentException("Role is required");
        }
        if (!role.matches("User|Admin")) {
            throw new IllegalArgumentException("Role must be User or Admin");
        }
    }

    /** Manual replica of the bean-validation constraints on LoginForm. */
    private void validateLogin(String email, String rawPassword) {
        if (email == null || email.isBlank()) {
            throw new IllegalArgumentException("Email is required");
        }
        if (!email.matches(EMAIL_REGEX)) {
            throw new IllegalArgumentException("Enter a valid email address");
        }
        if (rawPassword == null || rawPassword.isBlank()) {
            throw new IllegalArgumentException("Password is required");
        }
    }
}
