package com.frs.servlet;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.util.HashMap;
import java.util.Map;

/**
 * Minimal flash scope: attributes that survive exactly one redirect.
 * Replaces Spring's RedirectAttributes.addFlashAttribute().
 *
 * Usage: Flash.put(session, "infoMessage", "...") before a redirect;
 * BaseServlet.forward() calls Flash.expose(request) so the JSP sees the
 * attribute as a plain request attribute, exactly like the old flash model.
 */
public final class Flash {

    private static final String FLASH_KEY = "flash.messages";

    private Flash() {
    }

    public static void put(HttpSession session, String name, String value) {
        @SuppressWarnings("unchecked")
        Map<String, String> messages = (Map<String, String>) session.getAttribute(FLASH_KEY);
        if (messages == null) {
            messages = new HashMap<>();
            session.setAttribute(FLASH_KEY, messages);
        }
        messages.put(name, value);
    }

    /** Copy pending flash attributes onto the request and clear them. */
    public static void expose(HttpServletRequest req) {
        HttpSession session = req.getSession(false);
        if (session == null) {
            return;
        }
        @SuppressWarnings("unchecked")
        Map<String, String> messages = (Map<String, String>) session.getAttribute(FLASH_KEY);
        if (messages == null || messages.isEmpty()) {
            return;
        }
        messages.forEach(req::setAttribute);
        session.removeAttribute(FLASH_KEY);
    }
}
