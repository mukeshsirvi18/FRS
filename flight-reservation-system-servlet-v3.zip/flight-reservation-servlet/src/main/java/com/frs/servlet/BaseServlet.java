package com.frs.servlet;

import com.frs.model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Common behaviour for all FRS servlets (plain-Servlet MVC).
 *
 * Replaces the Spring plumbing the controllers used:
 * <ul>
 *   <li>{@link #forward} exposes flash attributes, then forwards to a JSP view
 *       (replaces returning a view name + Spring's Model).</li>
 *   <li>{@link #redirect} builds a context-relative redirect
 *       (replaces Spring's "redirect:/path").</li>
 *   <li>{@link #handleError} renders /WEB-INF/views/error.jsp with the same
 *       {@code errorTitle}/{@code errorMessage} attributes the old
 *       GlobalExceptionHandler set.</li>
 * </ul>
 */
public abstract class BaseServlet extends HttpServlet {

    protected final Logger log = Logger.getLogger(getClass().getName());

    /** Forward to a JSP view, exposing any pending flash attributes first. */
    protected void forward(HttpServletRequest req, HttpServletResponse resp, String jspPath)
            throws ServletException, IOException {
        Flash.expose(req);
        req.getRequestDispatcher(jspPath).forward(req, resp);
    }

    /** Context-relative redirect (replaces Spring's "redirect:/path"). */
    protected void redirect(HttpServletRequest req, HttpServletResponse resp, String path)
            throws IOException {
        resp.sendRedirect(req.getContextPath() + path);
    }

    /** The logged-in user, or null when there is no session / no login. */
    protected User currentUser(HttpSession session) {
        return session == null ? null : (User) session.getAttribute("user");
    }

    /** URL-encode a query-string value (UTF-8). */
    protected String url(String value) {
        return value == null ? "" : URLEncoder.encode(value, StandardCharsets.UTF_8);
    }

    /** Parse a path-segment id like "/5" into a Long; null when malformed. */
    protected Long pathId(String pathInfo) {
        if (pathInfo == null || pathInfo.isBlank()) {
            return null;
        }
        String[] parts = pathInfo.split("/");
        // "/5" -> ["", "5"]; "/5/cancel" -> ["", "5", "cancel"]
        if (parts.length < 2 || parts[1].isBlank()) {
            return null;
        }
        try {
            return Long.valueOf(parts[1]);
        } catch (NumberFormatException nfe) {
            return null;
        }
    }

    /**
     * Centralized error rendering. Mirrors GlobalExceptionHandler:
     * application exceptions -> "Something went wrong", anything else ->
     * "Unexpected error".
     */
    protected void handleError(HttpServletRequest req, HttpServletResponse resp, Exception e) {
        try {
            if (e instanceof IllegalArgumentException
                    || e instanceof IllegalStateException
                    || e instanceof SecurityException) {
                log.log(Level.WARNING, "Application error: {0}", e.getMessage());
                req.setAttribute("errorTitle", "Something went wrong");
                req.setAttribute("errorMessage", e.getMessage());
            } else {
                log.log(Level.SEVERE, "Unexpected error while handling " + req.getRequestURI(), e);
                req.setAttribute("errorTitle", "Unexpected error");
                req.setAttribute("errorMessage",
                        "An unexpected error occurred while processing your request. Please try again.");
            }
            req.getRequestDispatcher("/WEB-INF/views/error.jsp").forward(req, resp);
        } catch (Exception forwardFailure) {
            log.log(Level.SEVERE, "Failed to render error page", forwardFailure);
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
}
