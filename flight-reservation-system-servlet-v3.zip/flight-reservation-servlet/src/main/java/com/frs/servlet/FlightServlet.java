package com.frs.servlet;

import com.frs.model.Flight;
import com.frs.service.FlightService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;

/**
 * Replaces FlightController:
 * GET /flights?source=..&destination=..&travelDate=.. lists the matching
 * flights (login required - enforced by AuthFilter). Sets the same request
 * attributes the old controller set: {@code flights}, {@code source},
 * {@code destination}, {@code travelDate}.
 */
@WebServlet("/flights")
public class FlightServlet extends BaseServlet {

    private FlightService flightService;

    @Override
    public void init() {
        flightService = ServiceFactory.flightService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            String source = req.getParameter("source");
            String destination = req.getParameter("destination");
            LocalDate travelDate = ValidationUtil.parseDate(req.getParameter("travelDate"));
            List<Flight> flights = flightService.searchFlights(source, destination);
            req.setAttribute("flights", flights);
            req.setAttribute("source", source);
            req.setAttribute("destination", destination);
            req.setAttribute("travelDate", travelDate);
            log.fine("Rendered " + flights.size() + " flight(s) for "
                    + source + " -> " + destination + " on " + travelDate);
            forward(req, resp, "/WEB-INF/views/list-flights.jsp");
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }
}
