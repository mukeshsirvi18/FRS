package com.frs.servlet;

import com.frs.model.Booking;
import com.frs.model.Flight;
import com.frs.model.Ticket;
import com.frs.model.User;
import com.frs.model.dto.BookingContext;
import com.frs.model.dto.BookingForm;
import com.frs.model.dto.PassengerForm;
import com.frs.service.BookingService;
import com.frs.service.FlightService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Replaces BookingController. All routes require login (AuthFilter).
 *
 * <pre>
 * GET  /dashboard                  -> dashboard.jsp
 * GET  /book/{flightId}            -> booking-form.jsp (step 1)
 * POST /book/{flightId}            -> validate + seat check, start booking
 * GET  /book/passengers            -> add-passenger.jsp (step 2, one screen per passenger)
 * POST /book/passengers            -> save one passenger; last one creates the booking
 * GET  /book/confirmation?bookingId=.. -> booking-confirmation.jsp (step 3)
 * GET  /my-bookings                -> my-bookings.jsp
 * POST /bookings/{bookingId}/cancel
 * GET  /bookings/{bookingId}/tickets -> view-tickets.jsp
 * POST /tickets/{ticketId}/cancel
 * </pre>
 *
 * The in-progress booking lives in the session under {@code bookingContext}.
 */
@WebServlet(urlPatterns = {"/dashboard", "/book/*", "/my-bookings", "/bookings/*", "/tickets/*"})
public class BookingServlet extends BaseServlet {

    /** Session attribute holding the in-progress booking. */
    private static final String BOOKING_CONTEXT = "bookingContext";

    private FlightService flightService;
    private BookingService bookingService;

    @Override
    public void init() {
        flightService = ServiceFactory.flightService();
        bookingService = ServiceFactory.bookingService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            switch (req.getServletPath()) {
                case "/dashboard":
                    forward(req, resp, "/WEB-INF/views/dashboard.jsp");
                    break;
                case "/book":
                    routeBookGet(req, resp);
                    break;
                case "/my-bookings":
                    myBookings(req, resp);
                    break;
                case "/bookings":
                    routeBookingsGet(req, resp);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            switch (req.getServletPath()) {
                case "/book":
                    routeBookPost(req, resp);
                    break;
                case "/bookings":
                    routeBookingsPost(req, resp);
                    break;
                case "/tickets":
                    routeTicketsPost(req, resp);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            }
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    // ---------------------------------------------------------- /book/*

    private void routeBookGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/passengers".equals(pathInfo)) {
            addPassengerPage(req, resp);
            return;
        }
        if ("/confirmation".equals(pathInfo)) {
            confirmation(req, resp);
            return;
        }
        Long flightId = pathId(pathInfo);
        if (flightId == null) {
            throw new IllegalArgumentException("Invalid flight id.");
        }
        bookingFormPage(req, resp, flightId);
    }

    private void routeBookPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo();
        if ("/passengers".equals(pathInfo)) {
            addPassenger(req, resp);
            return;
        }
        Long flightId = pathId(pathInfo);
        if (flightId == null) {
            throw new IllegalArgumentException("Invalid flight id.");
        }
        startBooking(req, resp, flightId);
    }

    /** Step 1: shows the Booking Form for a flight. */
    private void bookingFormPage(HttpServletRequest req, HttpServletResponse resp, Long flightId)
            throws ServletException, IOException {
        Flight flight = flightService.getFlight(flightId);
        BookingForm form = new BookingForm();
        form.setFlightId(flightId);
        req.setAttribute("flight", flight);
        req.setAttribute("bookingForm", form);
        req.setAttribute("availableSeats", flight.getAvailableSeats());
        forward(req, resp, "/WEB-INF/views/booking-form.jsp");
    }

    /**
     * Step 1 submit: validates the form and checks seat availability. If
     * fewer seats are available than requested, an error is shown on the
     * same screen and the flow does NOT proceed.
     */
    private void startBooking(HttpServletRequest req, HttpServletResponse resp, Long flightId)
            throws ServletException, IOException {
        Flight flight = flightService.getFlight(flightId);
        req.setAttribute("flight", flight);
        BookingForm form = ValidationUtil.bindBooking(req);
        form.setFlightId(flightId);
        Map<String, String> errors = ValidationUtil.validateBooking(form);
        if (errors.isEmpty()) {
            int available = flightService.getAvailableSeats(flightId);
            req.setAttribute("availableSeats", available);
            if (form.getPassengers() > available) {
                errors.put("passengers", "Only " + available + " seat(s) available on flight "
                        + flight.getFlightNumber() + ".");
            }
        }
        if (!errors.isEmpty()) {
            req.setAttribute("bookingForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/booking-form.jsp");
            return;
        }
        HttpSession session = req.getSession();
        session.setAttribute(BOOKING_CONTEXT,
                new BookingContext(flightId, form.getJourneyDate(), form.getPassengers()));
        log.info("Booking started for flight " + flight.getFlightNumber() + ": "
                + form.getPassengers() + " passenger(s) on " + form.getJourneyDate());
        redirect(req, resp, "/book/passengers");
    }

    /** Shows "Add Passenger N" with the remaining-passenger count. */
    private void addPassengerPage(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        BookingContext ctx = bookingContext(session);
        if (ctx == null) {
            redirect(req, resp, "/");
            return;
        }
        req.setAttribute("passengerNumber", ctx.getCurrentIndex() + 1);
        req.setAttribute("remaining", ctx.getRemaining());
        req.setAttribute("flight", flightService.getFlight(ctx.getFlightId()));
        req.setAttribute("travelDate", ctx.getTravelDate());
        req.setAttribute("passengerForm", new PassengerForm());
        forward(req, resp, "/WEB-INF/views/add-passenger.jsp");
    }

    /**
     * Saves one passenger and either shows the next passenger screen or,
     * after the last passenger, creates the booking and goes to the
     * confirmation page.
     */
    private void addPassenger(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        HttpSession session = req.getSession(false);
        BookingContext ctx = bookingContext(session);
        if (ctx == null) {
            redirect(req, resp, "/");
            return;
        }
        PassengerForm form = ValidationUtil.bindPassenger(req);
        Map<String, String> errors = ValidationUtil.validatePassenger(form);
        if (!errors.isEmpty()) {
            req.setAttribute("passengerNumber", ctx.getCurrentIndex() + 1);
            req.setAttribute("remaining", ctx.getRemaining());
            req.setAttribute("flight", flightService.getFlight(ctx.getFlightId()));
            req.setAttribute("travelDate", ctx.getTravelDate());
            req.setAttribute("passengerForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/add-passenger.jsp");
            return;
        }
        ctx.getPassengers().add(form);
        log.fine("Collected passenger " + ctx.getPassengers().size()
                + "/" + ctx.getTotalPassengers() + " for in-progress booking");
        if (!ctx.isComplete()) {
            redirect(req, resp, "/book/passengers");
            return;
        }
        // Last passenger done -> create the booking.
        User user = currentUser(session);
        Booking booking;
        try {
            booking = bookingService.createBooking(
                    user.getUserId(), ctx.getFlightId(), ctx.getTravelDate(), ctx.getPassengers());
        } catch (IllegalStateException e) {
            // Seats ran out while entering passengers.
            session.removeAttribute(BOOKING_CONTEXT);
            Flash.put(session, "bookingError", e.getMessage());
            redirect(req, resp, "/my-bookings");
            return;
        }
        session.removeAttribute(BOOKING_CONTEXT);
        redirect(req, resp, "/book/confirmation?bookingId=" + booking.getBookingId());
    }

    /** Step 3: booking confirmation page. */
    private void confirmation(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        Long bookingId = ValidationUtil.parseLong(req.getParameter("bookingId"));
        if (bookingId == null) {
            throw new IllegalArgumentException("Invalid booking id.");
        }
        User user = currentUser(req.getSession(false));
        Booking booking = bookingService.getBookingDetails(bookingId, user.getUserId());
        req.setAttribute("booking", booking);
        forward(req, resp, "/WEB-INF/views/booking-confirmation.jsp");
    }

    // ------------------------------------------------------- my bookings

    /** Only the logged-in user's bookings. */
    private void myBookings(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        User user = currentUser(req.getSession(false));
        List<Booking> bookings = bookingService.getMyBookings(user.getUserId());
        req.setAttribute("bookings", bookings);
        forward(req, resp, "/WEB-INF/views/my-bookings.jsp");
    }

    // ---------------------------------------------------------- /bookings/*

    private void routeBookingsGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo(); // "/{bookingId}/tickets"
        Long bookingId = pathId(pathInfo);
        if (bookingId == null || pathInfo == null || !pathInfo.endsWith("/tickets")) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        viewTickets(req, resp, bookingId);
    }

    private void routeBookingsPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String pathInfo = req.getPathInfo(); // "/{bookingId}/cancel"
        Long bookingId = pathId(pathInfo);
        if (bookingId == null || pathInfo == null || !pathInfo.endsWith("/cancel")) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        cancelBooking(req, resp, bookingId);
    }

    /** Cancels a whole booking (all its tickets); seats are released. */
    private void cancelBooking(HttpServletRequest req, HttpServletResponse resp, Long bookingId)
            throws IOException {
        HttpSession session = req.getSession();
        User user = currentUser(session);
        try {
            bookingService.cancelBooking(bookingId, user.getUserId());
            Flash.put(session, "infoMessage",
                    "Booking " + bookingId + " cancelled. The seats are now available again.");
        } catch (RuntimeException e) {
            Flash.put(session, "bookingError", e.getMessage());
        }
        redirect(req, resp, "/my-bookings");
    }

    /** View Tickets: one card per passenger in the booking. */
    private void viewTickets(HttpServletRequest req, HttpServletResponse resp, Long bookingId)
            throws ServletException, IOException {
        User user = currentUser(req.getSession(false));
        Booking booking = bookingService.getBookingDetails(bookingId, user.getUserId());
        req.setAttribute("booking", booking);
        forward(req, resp, "/WEB-INF/views/view-tickets.jsp");
    }

    // ----------------------------------------------------------- /tickets/*

    private void routeTicketsPost(HttpServletRequest req, HttpServletResponse resp)
            throws IOException {
        String pathInfo = req.getPathInfo(); // "/{ticketId}/cancel"
        Long ticketId = pathId(pathInfo);
        if (ticketId == null || pathInfo == null || !pathInfo.endsWith("/cancel")) {
            resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            return;
        }
        cancelTicket(req, resp, ticketId);
    }

    /** Cancels a single ticket (owner only). */
    private void cancelTicket(HttpServletRequest req, HttpServletResponse resp, Long ticketId)
            throws IOException {
        HttpSession session = req.getSession();
        User user = currentUser(session);
        try {
            bookingService.cancelTicket(ticketId, user.getUserId());
            Flash.put(session, "infoMessage", "Ticket cancelled.");
        } catch (RuntimeException e) {
            Flash.put(session, "bookingError", e.getMessage());
        }
        Ticket ticket = bookingService.getTicketDetails(ticketId, user.getUserId());
        redirect(req, resp, "/bookings/" + ticket.getBookingId() + "/tickets");
    }

    // ------------------------------------------------------------ helpers

    private BookingContext bookingContext(HttpSession session) {
        return session == null ? null : (BookingContext) session.getAttribute(BOOKING_CONTEXT);
    }
}
