package com.frs.servlet;

import com.frs.model.Flight;
import com.frs.model.dto.FlightForm;
import com.frs.model.dto.FlightJourneyStats;
import com.frs.service.FlightService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Replaces AdminController. All routes require login + the Admin role
 * (AuthFilter).
 *
 * <pre>
 * GET  /admin/dashboard   -> admin/dashboard.jsp
 * GET  /admin/flights     -> admin/view-flights.jsp (upcoming/completed tabs)
 * GET  /admin/flights/new -> admin/add-flight.jsp
 * POST /admin/flights     -> validate + add the flight
 * </pre>
 */
@WebServlet("/admin/*")
public class AdminServlet extends BaseServlet {

    private FlightService flightService;

    @Override
    public void init() {
        flightService = ServiceFactory.flightService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            String pathInfo = req.getPathInfo() == null ? "" : req.getPathInfo();
            switch (pathInfo) {
                case "/dashboard":
                    forward(req, resp, "/WEB-INF/views/admin/dashboard.jsp");
                    break;
                case "/flights":
                    viewFlights(req, resp);
                    break;
                case "/flights/new":
                    req.setAttribute("flightForm", new FlightForm()); // capacity defaults to 20
                    forward(req, resp, "/WEB-INF/views/admin/add-flight.jsp");
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            if ("/flights".equals(req.getPathInfo())) {
                addFlight(req, resp);
            } else {
                resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            }
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    /**
     * View Flights page with two tabs: "Upcoming Journeys" and
     * "Completed Journey". Only flights that have bookings are shown.
     */
    private void viewFlights(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<FlightJourneyStats> upcoming = flightService.getUpcomingJourneys();
        List<FlightJourneyStats> completed = flightService.getCompletedJourneys();
        req.setAttribute("upcoming", upcoming);
        req.setAttribute("completed", completed);
        log.fine("Admin viewed flights: " + upcoming.size()
                + " upcoming, " + completed.size() + " completed journey rows");
        forward(req, resp, "/WEB-INF/views/admin/view-flights.jsp");
    }

    /**
     * Adds a flight. All fields are validated; a duplicate flight number
     * is rejected with a validation error on the same screen.
     */
    private void addFlight(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        FlightForm form = ValidationUtil.bindFlight(req);
        Map<String, String> errors = ValidationUtil.validateFlight(form);
        if (!errors.isEmpty()) {
            req.setAttribute("flightForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/admin/add-flight.jsp");
            return;
        }
        try {
            Flight saved = flightService.addFlight(form);
            log.info("Admin added flight " + saved.getFlightNumber()
                    + " (id " + saved.getFlightId() + ")");
        } catch (IllegalArgumentException e) {
            errors.put("flightNumber", e.getMessage());
            req.setAttribute("flightForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/admin/add-flight.jsp");
            return;
        }
        redirect(req, resp, "/admin/flights");
    }
}
