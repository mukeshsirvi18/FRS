package com.frs.servlet;

import com.frs.model.dto.BookingForm;
import com.frs.model.dto.FlightForm;
import com.frs.model.dto.FlightSearchForm;
import com.frs.model.dto.LoginForm;
import com.frs.model.dto.PassengerForm;
import com.frs.model.dto.SignupForm;
import jakarta.servlet.http.HttpServletRequest;

import java.time.LocalDate;
import java.time.format.DateTimeParseException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Manual form binding + validation for the servlet layer.
 *
 * Replaces Spring's {@code @Valid} + {@code BindingResult}: each
 * {@code validate*} method returns a field-&gt;message map which the
 * servlets expose to the JSP as the {@code errors} request attribute
 * (rendered next to the offending input, same messages as the old
 * {@code jakarta.validation} annotations on the DTOs).
 */
public final class ValidationUtil {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[^@\\s]+@[^@\\s]+\\.[^@\\s]+$");

    private ValidationUtil() {
    }

    // ------------------------------------------------------------ binding

    public static FlightSearchForm bindSearch(HttpServletRequest req) {
        FlightSearchForm form = new FlightSearchForm();
        form.setSource(req.getParameter("source"));
        form.setDestination(req.getParameter("destination"));
        form.setTravelDate(parseDate(req.getParameter("travelDate")));
        return form;
    }

    public static LoginForm bindLogin(HttpServletRequest req) {
        LoginForm form = new LoginForm();
        form.setEmail(req.getParameter("email"));
        form.setPassword(req.getParameter("password"));
        return form;
    }

    public static SignupForm bindSignup(HttpServletRequest req) {
        SignupForm form = new SignupForm();
        form.setEmail(req.getParameter("email"));
        form.setPassword(req.getParameter("password"));
        String role = req.getParameter("role");
        if (role != null) {
            form.setRole(role); // otherwise the DTO default ("User") stays
        }
        return form;
    }

    public static BookingForm bindBooking(HttpServletRequest req) {
        BookingForm form = new BookingForm();
        form.setFlightId(parseLong(req.getParameter("flightId")));
        form.setJourneyDate(parseDate(req.getParameter("journeyDate")));
        form.setPassengers(parseInt(req.getParameter("passengers")));
        return form;
    }

    public static PassengerForm bindPassenger(HttpServletRequest req) {
        PassengerForm form = new PassengerForm();
        form.setPassengerName(req.getParameter("passengerName"));
        form.setGender(req.getParameter("gender"));
        form.setAge(parseInt(req.getParameter("age")));
        return form;
    }

    public static FlightForm bindFlight(HttpServletRequest req) {
        FlightForm form = new FlightForm();
        form.setFlightNumber(req.getParameter("flightNumber"));
        form.setSource(req.getParameter("source"));
        form.setDestination(req.getParameter("destination"));
        form.setDepartureTime(req.getParameter("departureTime"));
        form.setArrivalTime(req.getParameter("arrivalTime"));
        Integer capacity = parseInt(req.getParameter("capacity"));
        if (capacity != null) {
            form.setCapacity(capacity); // otherwise the DTO default (20) stays
        } else if (req.getParameter("capacity") != null) {
            form.setCapacity(null); // present but malformed -> "required" error
        }
        form.setPricePerSeat(parseDouble(req.getParameter("pricePerSeat")));
        return form;
    }

    // --------------------------------------------------------- validation

    /** Mirrors the constraints on FlightSearchForm. */
    public static Map<String, String> validateSearch(FlightSearchForm form) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (isBlank(form.getSource())) {
            errors.put("source", "Source is required");
        }
        if (isBlank(form.getDestination())) {
            errors.put("destination", "Destination is required");
        }
        if (form.getTravelDate() == null) {
            errors.put("travelDate", "Travel date is required");
        } else if (form.getTravelDate().isBefore(LocalDate.now())) {
            errors.put("travelDate", "Travel date cannot be in the past");
        }
        return errors;
    }

    /** Mirrors the constraints on LoginForm. */
    public static Map<String, String> validateLogin(LoginForm form) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (isBlank(form.getEmail())) {
            errors.put("email", "Email is required");
        } else if (!EMAIL_PATTERN.matcher(form.getEmail().trim()).matches()) {
            errors.put("email", "Enter a valid email address");
        }
        if (isBlank(form.getPassword())) {
            errors.put("password", "Password is required");
        }
        return errors;
    }

    /** Mirrors the constraints on SignupForm. */
    public static Map<String, String> validateSignup(SignupForm form) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (isBlank(form.getEmail())) {
            errors.put("email", "Email is required");
        } else if (!EMAIL_PATTERN.matcher(form.getEmail().trim()).matches()) {
            errors.put("email", "Enter a valid email address");
        } else if (form.getEmail().trim().length() > 100) {
            errors.put("email", "Email must be at most 100 characters");
        }
        if (isBlank(form.getPassword())) {
            errors.put("password", "Password is required");
        } else if (form.getPassword().length() < 6) {
            errors.put("password", "Password must be at least 6 characters");
        } else if (form.getPassword().length() > 100) {
            errors.put("password", "Password must be at most 100 characters");
        }
        if (isBlank(form.getRole())) {
            errors.put("role", "Role is required");
        } else if (!("User".equals(form.getRole()) || "Admin".equals(form.getRole()))) {
            errors.put("role", "Role must be User or Admin");
        }
        return errors;
    }

    /** Mirrors the constraints on BookingForm. */
    public static Map<String, String> validateBooking(BookingForm form) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (form.getJourneyDate() == null) {
            errors.put("journeyDate", "Journey date is required");
        } else if (form.getJourneyDate().isBefore(LocalDate.now())) {
            errors.put("journeyDate", "Journey date cannot be in the past");
        }
        if (form.getPassengers() == null) {
            errors.put("passengers", "Number of passengers is required");
        } else if (form.getPassengers() < 1) {
            errors.put("passengers", "At least 1 passenger is required");
        } else if (form.getPassengers() > 10) {
            errors.put("passengers", "Maximum 10 passengers allowed");
        }
        return errors;
    }

    /** Mirrors the constraints on PassengerForm. */
    public static Map<String, String> validatePassenger(PassengerForm form) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (isBlank(form.getPassengerName())) {
            errors.put("passengerName", "Passenger name is required");
        } else if (form.getPassengerName().trim().length() > 50) {
            errors.put("passengerName", "Name must be at most 50 characters");
        }
        if (isBlank(form.getGender())) {
            errors.put("gender", "Gender is required");
        } else if (!("Male".equals(form.getGender())
                || "Female".equals(form.getGender())
                || "Other".equals(form.getGender()))) {
            errors.put("gender", "Select a valid gender");
        }
        if (form.getAge() == null) {
            errors.put("age", "Age is required");
        } else if (form.getAge() < 1) {
            errors.put("age", "Age must be at least 1");
        } else if (form.getAge() > 120) {
            errors.put("age", "Age must be at most 120");
        }
        return errors;
    }

    /** Mirrors the constraints on FlightForm. */
    public static Map<String, String> validateFlight(FlightForm form) {
        Map<String, String> errors = new LinkedHashMap<>();
        if (isBlank(form.getFlightNumber())) {
            errors.put("flightNumber", "Flight number is required");
        } else if (form.getFlightNumber().trim().length() > 30) {
            errors.put("flightNumber", "Flight number must be at most 30 characters");
        }
        if (isBlank(form.getSource())) {
            errors.put("source", "Source is required");
        } else if (form.getSource().trim().length() > 50) {
            errors.put("source", "Source must be at most 50 characters");
        }
        if (isBlank(form.getDestination())) {
            errors.put("destination", "Destination is required");
        } else if (form.getDestination().trim().length() > 50) {
            errors.put("destination", "Destination must be at most 50 characters");
        }
        if (isBlank(form.getDepartureTime())) {
            errors.put("departureTime", "Departure time is required");
        }
        if (isBlank(form.getArrivalTime())) {
            errors.put("arrivalTime", "Arrival time is required");
        }
        if (form.getCapacity() == null) {
            errors.put("capacity", "Capacity is required");
        } else if (form.getCapacity() < 1) {
            errors.put("capacity", "Capacity must be at least 1");
        }
        if (form.getPricePerSeat() == null) {
            errors.put("pricePerSeat", "Price per seat is required");
        } else if (form.getPricePerSeat() <= 0) {
            errors.put("pricePerSeat", "Price must be positive");
        }
        return errors;
    }

    // ------------------------------------------------------------ helpers

    public static boolean isBlank(String value) {
        return value == null || value.isBlank();
    }

    /** Parses an ISO date (yyyy-MM-dd, as sent by HTML date inputs). */
    public static LocalDate parseDate(String value) {
        if (isBlank(value)) {
            return null;
        }
        try {
            return LocalDate.parse(value.trim());
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    public static Integer parseInt(String value) {
        if (isBlank(value)) {
            return null;
        }
        try {
            return Integer.valueOf(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Long parseLong(String value) {
        if (isBlank(value)) {
            return null;
        }
        try {
            return Long.valueOf(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public static Double parseDouble(String value) {
        if (isBlank(value)) {
            return null;
        }
        try {
            return Double.valueOf(value.trim());
        } catch (NumberFormatException e) {
            return null;
        }
    }
}
