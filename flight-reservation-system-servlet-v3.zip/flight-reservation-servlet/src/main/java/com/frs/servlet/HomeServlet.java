package com.frs.servlet;

import com.frs.model.dto.FlightSearchForm;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Map;

/**
 * Replaces HomeController:
 * <ul>
 *   <li>GET "" (context root) -> home.jsp with a fresh search form.</li>
 *   <li>POST /search -> validates the form; on failure the home page is
 *       re-rendered with an {@code errors} map. Logged-out users are parked
 *       behind the login wall (their search is stored as
 *       {@code pendingSearch} and resumed right after login); logged-in
 *       users are redirected to /flights with the search as query params.</li>
 * </ul>
 */
@WebServlet(urlPatterns = {"", "/search"})
public class HomeServlet extends BaseServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            if ("/search".equals(req.getServletPath())) {
                resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
                return;
            }
            req.setAttribute("searchForm", new FlightSearchForm());
            forward(req, resp, "/WEB-INF/views/home.jsp");
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        if (!"/search".equals(req.getServletPath())) {
            resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            return;
        }
        try {
            FlightSearchForm form = ValidationUtil.bindSearch(req);
            Map<String, String> errors = ValidationUtil.validateSearch(form);
            if (!errors.isEmpty()) {
                req.setAttribute("searchForm", form);
                req.setAttribute("errors", errors);
                forward(req, resp, "/WEB-INF/views/home.jsp");
                return;
            }
            HttpSession session = req.getSession();
            if (currentUser(session) == null) {
                session.setAttribute("pendingSearch", form);
                Flash.put(session, "infoMessage", "Please login to search flights.");
                log.fine("Search held behind login wall for "
                        + form.getSource() + " -> " + form.getDestination());
                redirect(req, resp, "/login");
                return;
            }
            redirect(req, resp, "/flights"
                    + "?source=" + url(form.getSource().trim())
                    + "&destination=" + url(form.getDestination().trim())
                    + "&travelDate=" + url(form.getTravelDate().toString()));
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }
}
