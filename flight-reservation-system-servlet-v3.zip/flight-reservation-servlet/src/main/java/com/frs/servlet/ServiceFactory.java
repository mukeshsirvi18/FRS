package com.frs.servlet;

import com.frs.service.BookingService;
import com.frs.service.FlightService;
import com.frs.service.UserService;

/**
 * Manual wiring of the service layer (replaces Spring's DI container).
 * Services are stateless, so single shared instances are used.
 *
 * <p><b>INTEGRATION CONTRACT</b> (matches the service-layer agent's output):
 * {@code com.frs.service.UserService()}, {@code FlightService()} and
 * {@code BookingService()} all expose public no-arg constructors and wire
 * their own DAOs internally (DAOs likewise have no-arg constructors and
 * obtain JDBC connections via {@code com.frs.util.DBUtil}). If the
 * skeleton agents ever change constructor shapes, update ONLY this class -
 * no servlet touches a constructor directly.
 */
public final class ServiceFactory {

    private static volatile UserService userService;
    private static volatile FlightService flightService;
    private static volatile BookingService bookingService;

    private ServiceFactory() {
    }

    public static UserService userService() {
        UserService service = userService;
        if (service == null) {
            synchronized (ServiceFactory.class) {
                service = userService;
                if (service == null) {
                    service = new UserService();
                    userService = service;
                }
            }
        }
        return service;
    }

    public static FlightService flightService() {
        FlightService service = flightService;
        if (service == null) {
            synchronized (ServiceFactory.class) {
                service = flightService;
                if (service == null) {
                    service = new FlightService();
                    flightService = service;
                }
            }
        }
        return service;
    }

    public static BookingService bookingService() {
        BookingService service = bookingService;
        if (service == null) {
            synchronized (ServiceFactory.class) {
                service = bookingService;
                if (service == null) {
                    service = new BookingService();
                    bookingService = service;
                }
            }
        }
        return service;
    }
}
