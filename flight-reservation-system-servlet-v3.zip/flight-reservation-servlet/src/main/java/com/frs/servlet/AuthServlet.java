package com.frs.servlet;

import com.frs.filter.AuthFilter;
import com.frs.model.User;
import com.frs.model.dto.FlightSearchForm;
import com.frs.model.dto.LoginForm;
import com.frs.model.dto.SignupForm;
import com.frs.service.UserService;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Map;

/**
 * Replaces AuthController:
 * <ul>
 *   <li>GET /login -> login form; POST /login -> authenticate.</li>
 *   <li>GET /signup -> signup form; POST /signup -> register.</li>
 *   <li>GET /logout -> invalidate session, back to home.</li>
 * </ul>
 * After a successful login the servlet resumes, in order: (1) a flight
 * search parked behind the login wall ({@code pendingSearch}), (2) the page
 * saved by the auth filter ({@code postLoginRedirect}), (3) the role-based
 * default landing page.
 */
@WebServlet(urlPatterns = {"/login", "/signup", "/logout"})
public class AuthServlet extends BaseServlet {

    private UserService userService;

    @Override
    public void init() {
        userService = ServiceFactory.userService();
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            switch (req.getServletPath()) {
                case "/login":
                    req.setAttribute("loginForm", new LoginForm());
                    forward(req, resp, "/WEB-INF/views/login.jsp");
                    break;
                case "/signup":
                    req.setAttribute("signupForm", new SignupForm()); // role defaults to "User"
                    forward(req, resp, "/WEB-INF/views/signup.jsp");
                    break;
                case "/logout":
                    logout(req, resp);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_NOT_FOUND);
            }
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        try {
            switch (req.getServletPath()) {
                case "/login":
                    doLogin(req, resp);
                    break;
                case "/signup":
                    doSignup(req, resp);
                    break;
                default:
                    resp.sendError(HttpServletResponse.SC_METHOD_NOT_ALLOWED);
            }
        } catch (Exception e) {
            handleError(req, resp, e);
        }
    }

    private void doLogin(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        LoginForm form = ValidationUtil.bindLogin(req);
        Map<String, String> errors = ValidationUtil.validateLogin(form);
        if (!errors.isEmpty()) {
            req.setAttribute("loginForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/login.jsp");
            return;
        }
        final User user;
        try {
            user = userService.authenticate(form.getEmail(), form.getPassword());
        } catch (IllegalArgumentException e) {
            req.setAttribute("loginForm", form);
            req.setAttribute("loginError", e.getMessage());
            forward(req, resp, "/WEB-INF/views/login.jsp");
            return;
        }
        HttpSession session = req.getSession();
        session.setAttribute("user", user);

        // 1. Resume a flight search that was interrupted by the login wall.
        FlightSearchForm pending = (FlightSearchForm) session.getAttribute("pendingSearch");
        if (pending != null) {
            session.removeAttribute("pendingSearch");
            log.info("User " + user.getEmail() + " resumed interrupted search after login");
            redirect(req, resp, "/flights"
                    + "?source=" + url(pending.getSource().trim())
                    + "&destination=" + url(pending.getDestination().trim())
                    + "&travelDate=" + url(pending.getTravelDate().toString()));
            return;
        }

        // 2. Resume the page the user was heading to when the login wall
        //    stopped them. The saved value must be a local path; it already
        //    contains the context path (it was captured from getRequestURI).
        String resume = (String) session.getAttribute(AuthFilter.POST_LOGIN_REDIRECT);
        if (resume != null) {
            session.removeAttribute(AuthFilter.POST_LOGIN_REDIRECT);
            if (resume.startsWith("/") && !resume.startsWith("//")) {
                log.info("User " + user.getEmail() + " resumed " + resume + " after login");
                resp.sendRedirect(resume);
                return;
            }
            log.warning("Ignored unsafe post-login redirect target: " + resume);
        }

        // 3. Default landing pages by role.
        redirect(req, resp, user.isAdmin() ? "/admin/dashboard" : "/dashboard");
    }

    private void doSignup(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        SignupForm form = ValidationUtil.bindSignup(req);
        Map<String, String> errors = ValidationUtil.validateSignup(form);
        if (!errors.isEmpty()) {
            req.setAttribute("signupForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/signup.jsp");
            return;
        }
        try {
            userService.register(form);
        } catch (IllegalArgumentException e) {
            errors.put("email", e.getMessage());
            req.setAttribute("signupForm", form);
            req.setAttribute("errors", errors);
            forward(req, resp, "/WEB-INF/views/signup.jsp");
            return;
        }
        Flash.put(req.getSession(),
                "infoMessage", "Registration successful. Please login with your new account.");
        redirect(req, resp, "/login");
    }

    private void logout(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        HttpSession session = req.getSession(false);
        User user = currentUser(session);
        if (user != null) {
            log.info("User logged out: " + user.getEmail());
        }
        if (session != null) {
            session.invalidate();
        }
        redirect(req, resp, "/");
    }
}
