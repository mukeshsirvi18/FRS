package com.frs.listener;

import com.frs.util.DBUtil;
import jakarta.servlet.ServletContextEvent;
import jakarta.servlet.ServletContextListener;
import jakarta.servlet.annotation.WebListener;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.sql.Connection;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Runs the database schema and seed data on application startup.
 * Both scripts are idempotent, so this is safe to run on every deploy.
 * A failure here is logged but never kills startup.
 */
@WebListener
public class AppInitListener implements ServletContextListener {

    private static final Logger LOG = Logger.getLogger(AppInitListener.class.getName());

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        LOG.info("Flight Reservation System starting: initializing database...");
        try {
            runScript("schema.sql");
            runScript("data.sql");
            LOG.info("Database initialization complete.");
        } catch (Exception e) {
            LOG.log(Level.SEVERE, "Database initialization failed; the app may not work correctly.", e);
        }
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        LOG.info("Flight Reservation System shutting down.");
    }

    private void runScript(String resource) throws Exception {
        String sql = readResource(resource);
        int executed = 0;
        try (Connection conn = DBUtil.getConnection();
             Statement stmt = conn.createStatement()) {
            // Split on semicolons; skip comments and blank statements.
            for (String raw : sql.split(";")) {
                String statement = stripComments(raw).trim();
                if (statement.isEmpty()) {
                    continue;
                }
                stmt.execute(statement);
                executed++;
            }
        }
        LOG.info("Executed " + executed + " statements from " + resource + ".");
    }

    private String readResource(String name) throws Exception {
        try (InputStream in = getClass().getClassLoader().getResourceAsStream(name)) {
            if (in == null) {
                throw new IllegalStateException("Classpath resource not found: " + name);
            }
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                return reader.lines().collect(Collectors.joining("\n"));
            }
        }
    }

    /**
     * Removes whole-line SQL comments (-- ...) so comment text containing
     * semicolons does not split a statement.
     */
    private String stripComments(String block) {
        StringBuilder out = new StringBuilder();
        for (String line : block.split("\n")) {
            String trimmed = line.trim();
            if (trimmed.startsWith("--")) {
                continue;
            }
            out.append(line).append('\n');
        }
        return out.toString();
    }
}
