<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Form - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#9992;</span><div class="inner">
    <span class="crumb">&#127915; Booking</span>
    <h2>Booking <span class="hl">Form</span></h2>
    <p>${flight.flightNumber} &middot; ${flight.source} &rarr; ${flight.destination}</p>
</div></div>

<div class="wrap">
    <c:set var="step" value="1"/>
    <%@ include file="booking-steps.jspf" %>

    <div class="book-layout">
        <div class="card">
            <div class="flight-info">
                <div class="fn"><span class="code">${flight.flightNumber}</span>${flight.source} &rarr; ${flight.destination}</div>
                <div class="meta">
                    Departure: <b>${flight.departureTime}</b>
                    &nbsp;|&nbsp; Arrival: <b>${flight.arrivalTime}</b>
                    &nbsp;|&nbsp; Price per seat: <b>&#8377;<fmt:formatNumber value="${flight.pricePerSeat}" type="number" maxFractionDigits="2"/></b>
                </div>
                <div style="margin-top:10px">
                    Available seats:
                    <c:choose>
                        <c:when test="${availableSeats > 0}">
                            <span class="seats-ok">${availableSeats}</span>
                        </c:when>
                        <c:otherwise>
                            <span class="seats-full">Full</span>
                        </c:otherwise>
                    </c:choose>
                </div>
            </div>
            <form method="post" action="${pageContext.request.contextPath}/book/${flight.flightId}">
                <input type="hidden" id="flightId" name="flightId" value="${bookingForm.flightId}"/>
                <div class="field">
                    <label for="journeyDate">Journey Date</label>
                    <input type="date" id="journeyDate" name="journeyDate" value="${bookingForm.journeyDate}" class=""/>
                    <c:if test="${not empty errors.journeyDate}"><span class="err">${errors.journeyDate}</span></c:if>
                </div>
                <div class="field">
                    <label for="passengers">Number of Passengers</label>
                    <input type="number" id="passengers" name="passengers" value="${bookingForm.passengers}" min="1" max="10" class=""/>
                    <div class="hint">Maximum 10 passengers allowed.</div>
                    <c:if test="${not empty errors.passengers}"><span class="err">${errors.passengers}</span></c:if>
                </div>
                <div class="stack">
                    <button type="submit" class="btn btn-primary">Book Now &rarr;</button>
                    <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-ghost">Back to Dashboard</a>
                </div>
            </form>
        </div>
        <div class="summary-card">
            <h4>Fare estimate</h4>
            <div class="sum-row"><span>Passengers</span><span id="sum-pax">&ndash;</span></div>
            <div class="sum-row"><span>Price / seat</span><span>&#8377;<fmt:formatNumber value="${flight.pricePerSeat}" type="number" maxFractionDigits="2"/></span></div>
            <div class="sum-row total"><span>Total</span><b id="sum-total">&ndash;</b></div>
            <p class="note">Actual total is calculated at booking time (price &times; seats).</p>
        </div>
    </div>
</div>

<script>
(function(){
  var pax=document.getElementById('passengers');
  var rate=parseFloat('${flight.pricePerSeat}')||0;
  function inr(n){return '\u20B9'+n.toLocaleString('en-IN',{maximumFractionDigits:2});}
  function upd(){
    var n=Math.min(Math.max(parseInt(pax.value||'1',10),1),10);
    document.getElementById('sum-pax').textContent=n;
    document.getElementById('sum-total').textContent=inr(n*rate);
  }
  if(pax){pax.addEventListener('input',upd);upd();}
})();
</script>

<%@ include file="footer.jspf" %>
