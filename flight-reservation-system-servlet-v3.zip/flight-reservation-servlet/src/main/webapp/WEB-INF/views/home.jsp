<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Flight Reservation System - Home</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#9992;</span><div class="inner">
    <span class="crumb">&#9992; Flight Reservation System</span>
    <h2>Find your <span class="hl">flight</span></h2>
    <p>Search by route and travel date</p>
</div></div>

<div class="wrap">
    <c:if test="${not empty infoMessage}">
        <div class="alert alert-info">${infoMessage}</div>
    </c:if>

    <div class="home-grid">
        <!-- Search Flights -->
        <div class="card">
            <h3>&#128269; Search Flights</h3>
            <p class="sub">Enter source, destination and travel date</p>
            <form method="post" action="${pageContext.request.contextPath}/search">
                <div class="field">
                    <label for="source">Source</label>
                    <input type="text" id="source" name="source" value="${searchForm.source}" class="" placeholder="e.g. DEL"/>
                    <c:if test="${not empty errors.source}"><span class="err">${errors.source}</span></c:if>
                </div>
                <div class="field">
                    <label for="destination">Destination</label>
                    <input type="text" id="destination" name="destination" value="${searchForm.destination}" class="" placeholder="e.g. BOM"/>
                    <c:if test="${not empty errors.destination}"><span class="err">${errors.destination}</span></c:if>
                </div>
                <div class="field">
                    <label for="travelDate">Travel Date</label>
                    <input type="date" id="travelDate" name="travelDate" value="${searchForm.travelDate}" class=""/>
                    <c:if test="${not empty errors.travelDate}"><span class="err">${errors.travelDate}</span></c:if>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Search Flights &rarr;</button>
            </form>
        </div>

        <!-- User Actions -->
        <div class="card">
            <h3>&#128100; User Actions</h3>
            <c:choose>
                <c:when test="${not empty sessionScope.user}">
                    <p class="sub">Welcome, <strong>${sessionScope.user.email}</strong>!</p>
                    <c:choose>
                        <c:when test="${sessionScope.user.admin}">
                            <a href="${pageContext.request.contextPath}/admin/dashboard"
                               class="btn btn-accent btn-block">Admin Dashboard &rarr;</a>
                        </c:when>
                        <c:otherwise>
                            <a href="${pageContext.request.contextPath}/dashboard"
                               class="btn btn-primary btn-block">My Dashboard &rarr;</a>
                        </c:otherwise>
                    </c:choose>
                </c:when>
                <c:otherwise>
                    <p class="sub">Please login to book flights and access your account.</p>
                    <a href="${pageContext.request.contextPath}/login"
                       class="btn btn-primary btn-block" style="margin-bottom:10px">Login</a>
                    <a href="${pageContext.request.contextPath}/signup"
                       class="btn btn-ghost btn-block">Sign Up</a>
                    <div class="tip">&#128161; <span>Bina login ke <b>Book</b> dabao to login page khul kar wapas booking par le aayega.</span></div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
