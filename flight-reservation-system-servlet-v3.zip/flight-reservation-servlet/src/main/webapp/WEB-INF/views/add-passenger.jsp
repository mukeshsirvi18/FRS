<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Passenger ${passengerNumber} - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#9992;</span><div class="inner">
    <span class="crumb">&#127915; Booking</span>
    <h2>Add <span class="hl">Passengers</span></h2>
    <p>${flight.flightNumber} (${flight.source} &rarr; ${flight.destination}) &nbsp;|&nbsp; Journey date: ${travelDate}</p>
</div></div>

<div class="wrap">
    <c:set var="step" value="2"/>
    <%@ include file="booking-steps.jspf" %>

    <div class="card" style="max-width:640px">
        <h3>Add Passenger ${passengerNumber} of ${passengerNumber + remaining - 1}</h3>
        <p class="sub">
            Flight: <strong>${flight.flightNumber} (${flight.source} &rarr; ${flight.destination})</strong>
            &nbsp;|&nbsp; Journey date: ${travelDate}
        </p>
        <div class="rem-badge">&#9203; Remaining passengers: ${remaining}</div>
        <form method="post" action="${pageContext.request.contextPath}/book/passengers">
            <div class="field">
                <label for="passengerName">Passenger Name</label>
                <input type="text" id="passengerName" name="passengerName" value="${passengerForm.passengerName}" class="" placeholder="e.g. Mukesh"/>
                <c:if test="${not empty errors.passengerName}"><span class="err">${errors.passengerName}</span></c:if>
            </div>
            <div class="frow">
                <div class="field">
                    <label for="age">Age</label>
                    <input type="number" id="age" name="age" value="${passengerForm.age}" min="1" class="" placeholder="e.g. 28"/>
                    <c:if test="${not empty errors.age}"><span class="err">${errors.age}</span></c:if>
                </div>
                <div class="field">
                    <label for="gender">Gender</label>
                    <select id="gender" name="gender" class="">
                        <option value=""<c:if test="${empty passengerForm.gender}"> selected</c:if>>-- Select --</option>
                        <option value="Male"<c:if test="${passengerForm.gender == 'Male'}"> selected</c:if>>Male</option>
                        <option value="Female"<c:if test="${passengerForm.gender == 'Female'}"> selected</c:if>>Female</option>
                        <option value="Other"<c:if test="${passengerForm.gender == 'Other'}"> selected</c:if>>Other</option>
                    </select>
                    <c:if test="${not empty errors.gender}"><span class="err">${errors.gender}</span></c:if>
                </div>
            </div>
            <div class="stack" style="margin-top:8px">
                <button type="submit" class="btn btn-primary">
                    <c:choose>
                        <c:when test="${remaining == 1}">Finish Booking &#10003;</c:when>
                        <c:otherwise>Add Passenger ${passengerNumber + 1} &rarr;</c:otherwise>
                    </c:choose>
                </button>
                <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-ghost">Cancel</a>
            </div>
        </form>
    </div>
</div>

<%@ include file="footer.jspf" %>
