<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="center-page">
    <div class="card auth-card">
        <div class="auth-side">
            <h2>Create your<br>account &#9992;</h2>
            <p>Ek account banao aur flight booking shuru karo — sirf email, password aur role chahiye.</p>
            <div class="pts">
                <div><span>&#128269;</span> Search flights by route &amp; date</div>
                <div><span>&#127915;</span> Book up to 10 passengers at once</div>
                <div><span>&#128203;</span> View &amp; cancel tickets anytime</div>
            </div>
        </div>
        <div class="auth-form">
            <h3>Sign Up</h3>
            <p class="sub">Create a new account</p>
            <form method="post" action="${pageContext.request.contextPath}/signup">
                <div class="field">
                    <label for="email">Email</label>
                    <input type="email" id="email" name="email" value="${signupForm.email}" class="" placeholder="you@example.com"/>
                    <c:if test="${not empty errors.email}"><span class="err">${errors.email}</span></c:if>
                </div>
                <div class="field">
                    <label for="password">Password</label>
                    <input type="password" id="password" name="password" class="" placeholder="Choose a strong password"/>
                    <c:if test="${not empty errors.password}"><span class="err">${errors.password}</span></c:if>
                </div>
                <div class="field">
                    <label for="role">Role</label>
                    <select id="role" name="role" class="">
                        <option value="User"<c:if test="${signupForm.role == 'User'}"> selected</c:if>>User</option>
                        <option value="Admin"<c:if test="${signupForm.role == 'Admin'}"> selected</c:if>>Admin</option>
                    </select>
                    <c:if test="${not empty errors.role}"><span class="err">${errors.role}</span></c:if>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Sign Up &rarr;</button>
            </form>
            <p class="alt-link">
                Already registered?
                <a href="${pageContext.request.contextPath}/login">Login here</a>
            </p>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
