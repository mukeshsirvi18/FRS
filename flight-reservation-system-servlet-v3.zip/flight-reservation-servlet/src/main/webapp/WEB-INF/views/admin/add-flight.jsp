<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="../taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Flight - Flight Reservation System</title>
    <%@ include file="../styles.jspf" %>
</head>
<body>
<%@ include file="../header.jspf" %>

<div class="page-head"><span class="float-plane">&#10133;</span><div class="inner">
    <span class="crumb">&#128737; Admin panel</span>
    <h2>Add New <span class="hl">Flight</span></h2>
    <p>All flights run daily. Seat capacity defaults to 20.</p>
</div></div>

<div class="wrap">
    <div class="card" style="max-width:660px">
        <h3>&#10133; Add New Flight</h3>
        <p class="sub">Flight number unique hona chahiye</p>
        <form method="post" action="${pageContext.request.contextPath}/admin/flights">
            <div class="frow">
                <div class="field">
                    <label for="flightNumber">Flight Number</label>
                    <input type="text" id="flightNumber" name="flightNumber" value="${flightForm.flightNumber}" class="" placeholder="e.g. AI-105"/>
                    <c:if test="${not empty errors.flightNumber}"><span class="err">${errors.flightNumber}</span></c:if>
                </div>
                <div class="field">
                    <label for="pricePerSeat">Price per Seat (&#8377;)</label>
                    <input type="number" id="pricePerSeat" name="pricePerSeat" value="${flightForm.pricePerSeat}" step="0.01" min="0" class=""/>
                    <c:if test="${not empty errors.pricePerSeat}"><span class="err">${errors.pricePerSeat}</span></c:if>
                </div>
            </div>
            <div class="frow">
                <div class="field">
                    <label for="source">Source</label>
                    <input type="text" id="source" name="source" value="${flightForm.source}" class="" placeholder="e.g. DEL"/>
                    <c:if test="${not empty errors.source}"><span class="err">${errors.source}</span></c:if>
                </div>
                <div class="field">
                    <label for="destination">Destination</label>
                    <input type="text" id="destination" name="destination" value="${flightForm.destination}" class="" placeholder="e.g. BOM"/>
                    <c:if test="${not empty errors.destination}"><span class="err">${errors.destination}</span></c:if>
                </div>
            </div>
            <div class="frow">
                <div class="field">
                    <label for="departureTime">Departure Time</label>
                    <input type="time" id="departureTime" name="departureTime" value="${flightForm.departureTime}" class=""/>
                    <c:if test="${not empty errors.departureTime}"><span class="err">${errors.departureTime}</span></c:if>
                </div>
                <div class="field">
                    <label for="arrivalTime">Arrival Time</label>
                    <input type="time" id="arrivalTime" name="arrivalTime" value="${flightForm.arrivalTime}" class=""/>
                    <c:if test="${not empty errors.arrivalTime}"><span class="err">${errors.arrivalTime}</span></c:if>
                </div>
            </div>
            <div class="field">
                <label for="capacity">Seat Capacity</label>
                <input type="number" id="capacity" name="capacity" value="${flightForm.capacity}" min="1" class=""/>
                <c:if test="${not empty errors.capacity}"><span class="err">${errors.capacity}</span></c:if>
            </div>
            <div class="stack">
                <button type="submit" class="btn btn-primary">Add Flight &#10003;</button>
                <a href="${pageContext.request.contextPath}/admin/flights" class="btn btn-ghost">Cancel</a>
            </div>
        </form>
    </div>
</div>

<%@ include file="../footer.jspf" %>
