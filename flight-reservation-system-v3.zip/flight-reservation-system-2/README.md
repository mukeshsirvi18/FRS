# Flight Reservation System

A Spring-based Flight Reservation System web application. Users can browse, book,
and cancel flight tickets, while administrators can add and manage flights and bookings.

## Tech Stack

| Layer | Technology |
|---|---|
| Language | Java 17 |
| Framework | Spring Boot 3.2.5, Spring MVC |
| View | JSP + JSTL + Spring Form tags (WAR packaging) |
| Data access | Spring JDBC (`JdbcTemplate`, no JPA) |
| Database | MySQL 8 |
| Security | `spring-security-crypto` (BCrypt password hashing) |
| Validation | Jakarta Bean Validation (`@Valid` + `BindingResult`) |
| Logging | SLF4J (controllers, services, interceptors, exception handler) |
| Build | Maven |
| Tests | JUnit 5 + Mockito |
| Styling | Bootstrap 5 (CDN) |

## Architecture

Follows the 3-layer structure from the design document:

```
Browser (JSP views, reusable header/footer fragments)
   -> Controllers (com.frs.controller)      : HomeController, AuthController,
                                              FlightController, BookingController,
                                              AdminController
   -> Services (com.frs.service)            : UserService, FlightService,
                                              BookingService (@Transactional booking)
   -> DAOs (com.frs.dao)                    : UserDao, FlightDao, BookingDao,
                                              TicketDao (JdbcTemplate + RowMappers)
   -> MySQL (user, flight, booking, ticket)
```

Cross-cutting concerns:

- `LoginInterceptor` — user pages (`/flights`, `/book/**`, `/dashboard`,
  `/my-bookings`, …) require login; logged-out users are redirected to
  `/login`, and after a successful login they are taken to the page they
  originally wanted (e.g. clicking "Book" on a flight lands them on the
  Booking Form for that flight). A search started from the home page is
  likewise resumed automatically after login.
- `AdminInterceptor` — `/admin/**` requires the `Admin` role.
- `GlobalExceptionHandler` (`@ControllerAdvice`) — renders a friendly `error.jsp`.

Key business rules:

- Available seats are computed dynamically: `capacity − active (BOOKED) tickets`.
  Cancelling a booking or a ticket immediately frees the seats again.
- Booking creation is `@Transactional`: the booking row and one ticket row per
  passenger are created atomically, and seat availability is re-checked inside
  the transaction. Seat numbers assigned are the lowest free numbers.
- Cancelling the last active ticket of a booking marks the booking CANCELLED too.
- A maximum of 10 passengers is allowed per booking.
- All flights run daily with a default seat capacity of 20 (prefilled on the
  admin "Add Flight" form). Flight numbers must be unique.

## Prerequisites

- JDK 17+
- Maven 3.8+
- MySQL 8 running on `localhost:3306`

## Database Setup

The application creates everything itself on startup:

1. Creates the `flightdb` database if it does not exist
   (`createDatabaseIfNotExist=true` in the JDBC URL).
2. Runs `src/main/resources/schema.sql` (tables `user`, `flight`, `booking`, `ticket`).
3. Runs `src/main/resources/data.sql` (6 sample flights + the default admin user).
   Both scripts are idempotent, so restarting the app is safe.

If your MySQL credentials differ from `root` / `root`, edit them in
`src/main/resources/application.properties`:

```properties
spring.datasource.username=root
spring.datasource.password=root
```

## How to Run

```bash
cd flight-reservation-system
mvn spring-boot:run
```

Then open **http://localhost:8080** in your browser.

To run the unit tests:

```bash
mvn test
```

## Default Login

| Role  | Email          | Password |
|-------|----------------|----------|
| Admin | admin@frs.com  | admin123 |

(Password is stored as a BCrypt hash in `data.sql`.)

You can also sign up as a new `User` (or `Admin`) from the Sign Up page —
emails must be unique, passwords are BCrypt-hashed before storing.

## Booking Flow

1. **Booking Form** (`/book/{flightId}`) — shows the flight number, asks for
   the journey date and the number of passengers (1–10, "Maximum 10 passengers
   allowed"). On "Book Now", seat availability is checked: if fewer seats are
   free than requested, an error is shown on the same screen and the flow does
   not proceed.
2. **Add Passenger** (`/book/passengers`) — one screen per passenger
   ("Add Passenger 1", "Add Passenger 2", …) with "Remaining passengers: N".
   Each screen is validated with Spring Forms (name, age, gender required).
3. **Booking Confirmation** — shows the booking ID and a summary, a
   "Next Steps" list, and two buttons: "Go to Dashboard" and
   "Print Confirmation".

## Main Pages

| URL | Page |
|---|---|
| `/` | Home — Search Flights form (Spring-validated) + Login/Signup actions |
| `/signup`, `/login`, `/logout` | Authentication |
| `/dashboard` | My Dashboard — two links: My Bookings, Search Flights |
| `/flights?source=DEL&destination=BOM&travelDate=2026-10-01` | Flight search results |
| `/book/{flightId}` | Booking form (journey date + passenger count, max 10) |
| `/book/passengers` | Add passengers — one screen per passenger |
| `/book/confirmation?bookingId=…` | Booking confirmation, summary, next steps, print |
| `/my-bookings` | My bookings — "View Ticket" and "Cancel Ticket" per row (cancel disabled once cancelled) |
| `/bookings/{bookingId}/tickets` | View Tickets — one card per passenger (passenger info, travel info, booking details) |
| `/admin/dashboard` | Admin dashboard — "Add New Flight" and "View Flights" cards |
| `/admin/flights` | Admin — View Flights with "Upcoming Journeys" and "Completed Journey" tabs (only flights that have bookings; columns: flight number, journey date, total passengers, total bookings, total revenue, days until journey) |
| `/admin/flights/new` | Admin — add flight (flight number must be unique; capacity defaults to 20) |
