-- ------------------------------------------------------------------
-- Flight Reservation System - database schema
-- Tables: user, flight, booking, ticket
-- NOTE: `user` is a reserved word in MySQL 8, hence the backticks.
-- ------------------------------------------------------------------

CREATE TABLE IF NOT EXISTS `user` (
    user_id  BIGINT AUTO_INCREMENT PRIMARY KEY,
    email    VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    role     VARCHAR(30)  NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS flight (
    flight_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    flight_number  VARCHAR(30) NOT NULL,
    source         VARCHAR(50) NOT NULL,
    destination    VARCHAR(50) NOT NULL,
    departure_time VARCHAR(30),
    arrival_time   VARCHAR(30),
    capacity       INT         NOT NULL,
    price_per_seat DOUBLE      NOT NULL
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS booking (
    booking_id   BIGINT AUTO_INCREMENT PRIMARY KEY,
    booking_date DATE         NOT NULL,
    travel_date  DATE         NOT NULL,
    seats        INT          NOT NULL,
    total_price  DOUBLE       NOT NULL,
    status       VARCHAR(30)  NOT NULL,
    flight_id    BIGINT       NOT NULL,
    user_id      BIGINT       NOT NULL,
    CONSTRAINT fk_booking_flight FOREIGN KEY (flight_id) REFERENCES flight (flight_id),
    CONSTRAINT fk_booking_user  FOREIGN KEY (user_id)  REFERENCES `user` (user_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS ticket (
    ticket_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    passenger_name VARCHAR(50) NOT NULL,
    gender         VARCHAR(10),
    age            INT,
    journey_date   DATE        NOT NULL,
    seat_no        VARCHAR(20),
    booking_id     BIGINT      NOT NULL,
    status         VARCHAR(30) NOT NULL,
    CONSTRAINT fk_ticket_booking FOREIGN KEY (booking_id) REFERENCES booking (booking_id)
) ENGINE=InnoDB;
