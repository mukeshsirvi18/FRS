-- ------------------------------------------------------------------
-- Flight Reservation System - sample data (idempotent: safe to run on
-- every startup, rows are only inserted when they do not already exist)
-- ------------------------------------------------------------------

-- Sample flights (all flights run daily)
INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat)
SELECT 'AI-101', 'DEL', 'BOM', '08:00', '10:15', 20, 4500.0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM flight WHERE flight_number = 'AI-101');

INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat)
SELECT 'AI-102', 'BOM', 'DEL', '12:00', '14:15', 20, 4500.0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM flight WHERE flight_number = 'AI-102');

INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat)
SELECT 'SG-201', 'DEL', 'BLR', '09:30', '12:20', 20, 5200.0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM flight WHERE flight_number = 'SG-201');

INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat)
SELECT 'SG-202', 'BLR', 'DEL', '15:00', '17:50', 20, 5200.0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM flight WHERE flight_number = 'SG-202');

INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat)
SELECT 'UK-303', 'DEL', 'HYD', '18:00', '20:10', 20, 4800.0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM flight WHERE flight_number = 'UK-303');

INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat)
SELECT '6E-404', 'BOM', 'BLR', '07:00', '08:40', 20, 3900.0 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM flight WHERE flight_number = '6E-404');

-- Default admin user: admin@frs.com / admin123
-- (password is a real BCrypt hash of "admin123", generated with
-- spring-security-crypto's BCryptPasswordEncoder and verified with matches())
INSERT INTO `user` (email, password, role)
SELECT 'admin@frs.com', '$2a$10$Fm6z9f0nWbdpQCUAaBqm0Og.ylmCFsSNBgujk3sYoLPvjyIGDdCwS', 'Admin' FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `user` WHERE email = 'admin@frs.com');
