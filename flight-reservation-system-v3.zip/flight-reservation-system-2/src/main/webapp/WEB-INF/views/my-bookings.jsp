<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>My Bookings - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#127915;</span><div class="inner">
    <span class="crumb">&#128100; My account</span>
    <h2>My <span class="hl">Bookings</span></h2>
    <p>View your tickets and cancel bookings</p>
</div></div>

<div class="wrap">
    <c:if test="${not empty infoMessage}">
        <div class="alert alert-ok">${infoMessage}</div>
    </c:if>
    <c:if test="${not empty bookingError}">
        <div class="alert alert-err">${bookingError}</div>
    </c:if>

    <c:choose>
        <c:when test="${empty bookings}">
            <div class="card" style="text-align:center">
                <div style="font-size:44px">&#128546;</div>
                <h3 style="margin-top:10px">No bookings yet</h3>
                <p class="sub">You have no bookings yet.</p>
                <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Search Flights &rarr;</a>
            </div>
        </c:when>
        <c:otherwise>
            <div class="card">
                <h3>My Bookings</h3>
                <p class="sub">Ticket dekhne ke liye View Ticket, cancel ke liye Cancel Ticket</p>
                <div class="tbl-wrap">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>Booking ID</th>
                            <th>Flight</th>
                            <th>Journey Date</th>
                            <th>Seats</th>
                            <th>Total (&#8377;)</th>
                            <th>Status</th>
                            <th>Actions</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="b" items="${bookings}">
                            <tr>
                                <td><b>${b.bookingId}</b></td>
                                <td>${b.flight.flightNumber} (${b.flight.source} &rarr; ${b.flight.destination})</td>
                                <td>${b.travelDate}</td>
                                <td>${b.seats}</td>
                                <td><b>&#8377;<fmt:formatNumber value="${b.totalPrice}" type="number" maxFractionDigits="2"/></b></td>
                                <td>
                                    <c:choose>
                                        <c:when test="${b.status == 'BOOKED'}">
                                            <span class="status st-ok">${b.status}</span>
                                        </c:when>
                                        <c:otherwise>
                                            <span class="status st-no">${b.status}</span>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                                <td class="actions">
                                    <a href="${pageContext.request.contextPath}/bookings/${b.bookingId}/tickets"
                                       class="btn btn-sm btn-ghost">View Ticket</a>
                                    <c:choose>
                                        <c:when test="${b.status == 'BOOKED'}">
                                            <form method="post"
                                                  action="${pageContext.request.contextPath}/bookings/${b.bookingId}/cancel"
                                                  style="display:inline"
                                                  onsubmit="return confirm('Cancel this booking? All its tickets will be cancelled.')">
                                                <button type="submit" class="btn btn-sm btn-danger-ghost">Cancel Ticket</button>
                                            </form>
                                        </c:when>
                                        <c:otherwise>
                                            <button type="button" class="btn btn-sm btn-danger-ghost" disabled>Cancel Ticket</button>
                                        </c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </div>
        </c:otherwise>
    </c:choose>

    <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-ghost" style="margin-top:18px">&larr; Back to Dashboard</a>
</div>

<%@ include file="footer.jspf" %>
