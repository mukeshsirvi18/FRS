<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Passenger ${passengerNumber} - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#9992;</span><div class="inner">
    <span class="crumb">&#127915; Booking</span>
    <h2>Add <span class="hl">Passengers</span></h2>
    <p>${flight.flightNumber} (${flight.source} &rarr; ${flight.destination}) &nbsp;|&nbsp; Journey date: ${travelDate}</p>
</div></div>

<div class="wrap">
    <c:set var="step" value="2"/>
    <%@ include file="booking-steps.jspf" %>

    <div class="card" style="max-width:640px">
        <h3>Add Passenger ${passengerNumber} of ${passengerNumber + remaining - 1}</h3>
        <p class="sub">
            Flight: <strong>${flight.flightNumber} (${flight.source} &rarr; ${flight.destination})</strong>
            &nbsp;|&nbsp; Journey date: ${travelDate}
        </p>
        <div class="rem-badge">&#9203; Remaining passengers: ${remaining}</div>
        <form:form modelAttribute="passengerForm" method="post"
                   action="${pageContext.request.contextPath}/book/passengers">
            <div class="field">
                <form:label path="passengerName" cssClass="">Passenger Name</form:label>
                <form:input path="passengerName" cssClass="" placeholder="e.g. Mukesh"/>
                <form:errors path="passengerName" cssClass="err"/>
            </div>
            <div class="frow">
                <div class="field">
                    <form:label path="age" cssClass="">Age</form:label>
                    <form:input path="age" type="number" min="1" cssClass="" placeholder="e.g. 28"/>
                    <form:errors path="age" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="gender" cssClass="">Gender</form:label>
                    <form:select path="gender" cssClass="">
                        <form:option value="" label="-- Select --"/>
                        <form:option value="Male" label="Male"/>
                        <form:option value="Female" label="Female"/>
                        <form:option value="Other" label="Other"/>
                    </form:select>
                    <form:errors path="gender" cssClass="err"/>
                </div>
            </div>
            <div class="stack" style="margin-top:8px">
                <button type="submit" class="btn btn-primary">
                    <c:choose>
                        <c:when test="${remaining == 1}">Finish Booking &#10003;</c:when>
                        <c:otherwise>Add Passenger ${passengerNumber + 1} &rarr;</c:otherwise>
                    </c:choose>
                </button>
                <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-ghost">Cancel</a>
            </div>
        </form:form>
    </div>
</div>

<%@ include file="footer.jspf" %>
