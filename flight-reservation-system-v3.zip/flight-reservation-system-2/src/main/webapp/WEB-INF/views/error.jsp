<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Error - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="center-page" style="min-height:60vh">
    <div class="card" style="max-width:560px;text-align:center">
        <div style="font-size:52px">&#9888;&#65039;</div>
        <div class="alert alert-err" style="margin-top:14px;text-align:left">
            <h4 style="font-size:16px;margin-bottom:6px">${errorTitle}</h4>
            <p style="margin:0">${errorMessage}</p>
        </div>
        <div class="stack" style="justify-content:center">
            <a href="${pageContext.request.contextPath}/" class="btn btn-primary">Go to Home</a>
            <a href="javascript:history.back()" class="btn btn-ghost">Go Back</a>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
