<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Flight Reservation System - Home</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#9992;</span><div class="inner">
    <span class="crumb">&#9992; Flight Reservation System</span>
    <h2>Find your <span class="hl">flight</span></h2>
    <p>Search by route and travel date</p>
</div></div>

<div class="wrap">
    <c:if test="${not empty infoMessage}">
        <div class="alert alert-info">${infoMessage}</div>
    </c:if>

    <div class="home-grid">
        <!-- Search Flights -->
        <div class="card">
            <h3>&#128269; Search Flights</h3>
            <p class="sub">Enter source, destination and travel date</p>
            <form:form modelAttribute="searchForm" method="post"
                       action="${pageContext.request.contextPath}/search">
                <div class="field">
                    <form:label path="source" cssClass="">Source</form:label>
                    <form:input path="source" cssClass="" placeholder="e.g. DEL"/>
                    <form:errors path="source" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="destination" cssClass="">Destination</form:label>
                    <form:input path="destination" cssClass="" placeholder="e.g. BOM"/>
                    <form:errors path="destination" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="travelDate" cssClass="">Travel Date</form:label>
                    <form:input path="travelDate" type="date" cssClass=""/>
                    <form:errors path="travelDate" cssClass="err"/>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Search Flights &rarr;</button>
            </form:form>
        </div>

        <!-- User Actions -->
        <div class="card">
            <h3>&#128100; User Actions</h3>
            <c:choose>
                <c:when test="${not empty sessionScope.user}">
                    <p class="sub">Welcome, <strong>${sessionScope.user.email}</strong>!</p>
                    <c:choose>
                        <c:when test="${sessionScope.user.admin}">
                            <a href="${pageContext.request.contextPath}/admin/dashboard"
                               class="btn btn-accent btn-block">Admin Dashboard &rarr;</a>
                        </c:when>
                        <c:otherwise>
                            <a href="${pageContext.request.contextPath}/dashboard"
                               class="btn btn-primary btn-block">My Dashboard &rarr;</a>
                        </c:otherwise>
                    </c:choose>
                </c:when>
                <c:otherwise>
                    <p class="sub">Please login to book flights and access your account.</p>
                    <a href="${pageContext.request.contextPath}/login"
                       class="btn btn-primary btn-block" style="margin-bottom:10px">Login</a>
                    <a href="${pageContext.request.contextPath}/signup"
                       class="btn btn-ghost btn-block">Sign Up</a>
                    <div class="tip">&#128161; <span>Bina login ke <b>Book</b> dabao to login page khul kar wapas booking par le aayega.</span></div>
                </c:otherwise>
            </c:choose>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
