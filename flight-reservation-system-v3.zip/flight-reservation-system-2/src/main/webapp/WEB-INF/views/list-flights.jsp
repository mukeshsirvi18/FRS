<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Available Flights - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#9992;</span><div class="inner">
    <span class="crumb">&#128269; Search results</span>
    <h2>Available <span class="hl">Flights</span></h2>
    <p>${source} &rarr; ${destination} &nbsp;|&nbsp; Travel date: ${travelDate}</p>
</div></div>

<div class="wrap">
    <c:choose>
        <c:when test="${empty flights}">
            <div class="card" style="text-align:center">
                <div style="font-size:44px">&#128546;</div>
                <h3 style="margin-top:10px">No flights found</h3>
                <p class="sub">No flights found for ${source} to ${destination}. Please try another route.</p>
                <a href="${pageContext.request.contextPath}/" class="btn btn-ghost">&larr; Back to Search</a>
            </div>
        </c:when>
        <c:otherwise>
            <c:forEach var="f" items="${flights}">
                <div class="flight-card">
                    <div class="fc-main">
                        <div class="fc-air">
                            <span class="fnum">${f.flightNumber}</span>
                        </div>
                        <div class="fc-tl">
                            <div class="city"><b>${f.source}</b><span>Dep ${f.departureTime}</span></div>
                            <div class="fc-track"><span class="dot d1"></span><span class="plane">&#9992;</span><span class="dot d2"></span></div>
                            <div class="fc-dur" data-dep="${f.departureTime}" data-arr="${f.arrivalTime}">direct</div>
                            <div class="city" style="text-align:right"><b>${f.destination}</b><span>Arr ${f.arrivalTime}</span></div>
                        </div>
                    </div>
                    <div class="fc-side">
                        <div class="per">per seat</div>
                        <div class="amt">&#8377;<fmt:formatNumber value="${f.pricePerSeat}" type="number" maxFractionDigits="2"/></div>
                        <div class="seats">
                            <c:choose>
                                <c:when test="${f.availableSeats > 0}">
                                    <span class="seats-ok">${f.availableSeats} seats left</span>
                                </c:when>
                                <c:otherwise>
                                    <span class="seats-full">Full</span>
                                </c:otherwise>
                            </c:choose>
                        </div>
                        <c:if test="${f.availableSeats > 0}">
                            <a href="${pageContext.request.contextPath}/book/${f.flightId}"
                               class="btn btn-accent btn-sm" style="position:relative;z-index:1">Book Now &rarr;</a>
                        </c:if>
                    </div>
                </div>
            </c:forEach>
            <a href="${pageContext.request.contextPath}/" class="btn btn-ghost">&larr; Back to Search</a>
        </c:otherwise>
    </c:choose>
</div>

<script>
(function(){
  function mins(t){var p=t.split(':');return (+p[0])*60+(+p[1]);}
  document.querySelectorAll('.fc-dur[data-dep]').forEach(function(el){
    try{
      var m=mins(el.getAttribute('data-arr'))-mins(el.getAttribute('data-dep'));
      if(m<0)m+=1440;
      el.textContent=Math.floor(m/60)+'h '+(m%60)+'m \u00B7 direct';
    }catch(e){}
  });
})();
</script>

<%@ include file="footer.jspf" %>
