<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="../taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>View Flights - Flight Reservation System</title>
    <%@ include file="../styles.jspf" %>
</head>
<body>
<%@ include file="../header.jspf" %>

<div class="page-head"><span class="float-plane">&#128202;</span><div class="inner">
    <span class="crumb">&#128737; Admin panel</span>
    <h2>View <span class="hl">Flights</span></h2>
    <p>Only flights that have bookings are listed below.</p>
</div></div>

<div class="wrap">
    <div class="tabs">
        <button type="button" class="tab-btn on" id="jt-up" onclick="jtab('up')">&#128747; Upcoming Journeys</button>
        <button type="button" class="tab-btn" id="jt-done" onclick="jtab('done')">&#128748; Completed Journey</button>
    </div>

    <div class="card" id="jtab-up">
        <c:choose>
            <c:when test="${empty upcoming}">
                <div class="alert alert-info">No upcoming journeys with bookings.</div>
            </c:when>
            <c:otherwise>
                <div class="tbl-wrap">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>Flight Number</th>
                            <th>Journey Date</th>
                            <th>Total Passengers</th>
                            <th>Total Bookings</th>
                            <th>Total Revenue (&#8377;)</th>
                            <th>Days Until Journey</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="j" items="${upcoming}">
                            <tr>
                                <td><b>${j.flightNumber}</b></td>
                                <td>${j.journeyDate}</td>
                                <td>${j.totalPassengers}</td>
                                <td>${j.totalBookings}</td>
                                <td><b>&#8377;<fmt:formatNumber value="${j.totalRevenue}" type="number" maxFractionDigits="2"/></b></td>
                                <td><span class="status st-info">${j.daysUntilJourney} days</span></td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <div class="card" id="jtab-done" style="display:none">
        <c:choose>
            <c:when test="${empty completed}">
                <div class="alert alert-info">No completed journeys with bookings.</div>
            </c:when>
            <c:otherwise>
                <div class="tbl-wrap">
                    <table class="tbl">
                        <thead>
                        <tr>
                            <th>Flight Number</th>
                            <th>Journey Date</th>
                            <th>Total Passengers</th>
                            <th>Total Bookings</th>
                            <th>Total Revenue (&#8377;)</th>
                            <th>Journey Completed</th>
                        </tr>
                        </thead>
                        <tbody>
                        <c:forEach var="j" items="${completed}">
                            <tr>
                                <td><b>${j.flightNumber}</b></td>
                                <td>${j.journeyDate}</td>
                                <td>${j.totalPassengers}</td>
                                <td>${j.totalBookings}</td>
                                <td><b>&#8377;<fmt:formatNumber value="${j.totalRevenue}" type="number" maxFractionDigits="2"/></b></td>
                                <td><span class="status st-no">${j.daysUntilJourney} days ago</span></td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </c:otherwise>
        </c:choose>
    </div>

    <a href="${pageContext.request.contextPath}/admin/dashboard" class="btn btn-ghost" style="margin-top:18px">&larr; Back to Admin Dashboard</a>
</div>

<script>
function jtab(t){
  document.getElementById('jtab-up').style.display=(t==='up'?'block':'none');
  document.getElementById('jtab-done').style.display=(t==='done'?'block':'none');
  document.getElementById('jt-up').classList.toggle('on',t==='up');
  document.getElementById('jt-done').classList.toggle('on',t==='done');
}
</script>

<%@ include file="../footer.jspf" %>
