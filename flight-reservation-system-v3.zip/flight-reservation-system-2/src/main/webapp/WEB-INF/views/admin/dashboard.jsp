<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="../taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Admin Dashboard - Flight Reservation System</title>
    <%@ include file="../styles.jspf" %>
</head>
<body>
<%@ include file="../header.jspf" %>

<div class="page-head"><span class="float-plane">&#128737;</span><div class="inner">
    <span class="crumb">&#128737; Admin panel</span>
    <h2>Admin <span class="hl">Dashboard</span></h2>
    <p>Manage flights and monitor bookings.</p>
</div></div>

<div class="wrap">
    <div class="dash-cards">
        <div class="dash-card">
            <div class="ic">&#10133;</div>
            <h3>Add New Flight</h3>
            <p>Schedule a new flight with a unique flight number.</p>
            <a href="${pageContext.request.contextPath}/admin/flights/new" class="btn btn-primary btn-sm">Add New Flight &rarr;</a>
        </div>
        <div class="dash-card">
            <div class="ic">&#128202;</div>
            <h3>View Flights</h3>
            <p>Upcoming and completed journeys with booking stats.</p>
            <a href="${pageContext.request.contextPath}/admin/flights" class="btn btn-primary btn-sm">View Flights &rarr;</a>
        </div>
    </div>
</div>

<%@ include file="../footer.jspf" %>
