<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="../taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Add Flight - Flight Reservation System</title>
    <%@ include file="../styles.jspf" %>
</head>
<body>
<%@ include file="../header.jspf" %>

<div class="page-head"><span class="float-plane">&#10133;</span><div class="inner">
    <span class="crumb">&#128737; Admin panel</span>
    <h2>Add New <span class="hl">Flight</span></h2>
    <p>All flights run daily. Seat capacity defaults to 20.</p>
</div></div>

<div class="wrap">
    <div class="card" style="max-width:660px">
        <h3>&#10133; Add New Flight</h3>
        <p class="sub">Flight number unique hona chahiye</p>
        <form:form modelAttribute="flightForm" method="post"
                   action="${pageContext.request.contextPath}/admin/flights">
            <div class="frow">
                <div class="field">
                    <form:label path="flightNumber" cssClass="">Flight Number</form:label>
                    <form:input path="flightNumber" cssClass="" placeholder="e.g. AI-105"/>
                    <form:errors path="flightNumber" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="pricePerSeat" cssClass="">Price per Seat (&#8377;)</form:label>
                    <form:input path="pricePerSeat" type="number" step="0.01" min="0" cssClass=""/>
                    <form:errors path="pricePerSeat" cssClass="err"/>
                </div>
            </div>
            <div class="frow">
                <div class="field">
                    <form:label path="source" cssClass="">Source</form:label>
                    <form:input path="source" cssClass="" placeholder="e.g. DEL"/>
                    <form:errors path="source" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="destination" cssClass="">Destination</form:label>
                    <form:input path="destination" cssClass="" placeholder="e.g. BOM"/>
                    <form:errors path="destination" cssClass="err"/>
                </div>
            </div>
            <div class="frow">
                <div class="field">
                    <form:label path="departureTime" cssClass="">Departure Time</form:label>
                    <form:input path="departureTime" type="time" cssClass=""/>
                    <form:errors path="departureTime" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="arrivalTime" cssClass="">Arrival Time</form:label>
                    <form:input path="arrivalTime" type="time" cssClass=""/>
                    <form:errors path="arrivalTime" cssClass="err"/>
                </div>
            </div>
            <div class="field">
                <form:label path="capacity" cssClass="">Seat Capacity</form:label>
                <form:input path="capacity" type="number" min="1" cssClass=""/>
                <form:errors path="capacity" cssClass="err"/>
            </div>
            <div class="stack">
                <button type="submit" class="btn btn-primary">Add Flight &#10003;</button>
                <a href="${pageContext.request.contextPath}/admin/flights" class="btn btn-ghost">Cancel</a>
            </div>
        </form:form>
    </div>
</div>

<%@ include file="../footer.jspf" %>
