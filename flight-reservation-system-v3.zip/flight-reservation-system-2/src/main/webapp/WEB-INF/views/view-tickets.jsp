<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>View Tickets - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#127915;</span><div class="inner">
    <span class="crumb">&#127915; E-tickets</span>
    <h2>Tickets for <span class="hl">${booking.bookingId}</span></h2>
    <p>
        ${booking.flight.flightNumber} (${booking.flight.source} &rarr; ${booking.flight.destination})
        &nbsp;|&nbsp; Booking status:
        <c:choose>
            <c:when test="${booking.status == 'BOOKED'}">
                <span class="status st-ok">${booking.status}</span>
            </c:when>
            <c:otherwise>
                <span class="status st-no">${booking.status}</span>
            </c:otherwise>
        </c:choose>
    </p>
</div></div>

<div class="wrap">
    <c:if test="${not empty infoMessage}">
        <div class="alert alert-ok">${infoMessage}</div>
    </c:if>
    <c:if test="${not empty bookingError}">
        <div class="alert alert-err">${bookingError}</div>
    </c:if>

    <c:forEach var="t" items="${booking.tickets}">
        <div class="bp">
            <div class="bp-main">
                <div class="bp-top">
                    <span class="airline">&#9992; ${booking.flight.flightNumber}</span>
                    <c:choose>
                        <c:when test="${t.status == 'BOOKED'}">
                            <span class="status st-ok">${t.status}</span>
                        </c:when>
                        <c:otherwise>
                            <span class="status st-no">${t.status}</span>
                        </c:otherwise>
                    </c:choose>
                </div>
                <div class="bp-route">
                    <div class="c"><b>${booking.flight.source}</b><span>${booking.flight.departureTime}</span></div>
                    <div class="mid">
                        <div class="pl">&#9992;</div>
                        <div class="ln"></div>
                        <div class="du">direct</div>
                    </div>
                    <div class="c" style="text-align:right"><b>${booking.flight.destination}</b><span>${booking.flight.arrivalTime}</span></div>
                </div>
                <div class="bp-grid">
                    <div class="cell"><small>Passenger</small><b>${t.passengerName}</b></div>
                    <div class="cell"><small>Age / Gender</small><b>${t.age} / ${t.gender}</b></div>
                    <div class="cell"><small>Seat Number</small><b>${t.seatNo}</b></div>
                    <div class="cell"><small>Journey Date</small><b>${t.journeyDate}</b></div>
                    <div class="cell"><small>Booking ID</small><b>${t.bookingId}</b></div>
                    <div class="cell"><small>Ticket ID</small><b>${t.ticketId}</b></div>
                </div>
                <c:if test="${t.status == 'BOOKED'}">
                    <form method="post" class="bp-cancel"
                          action="${pageContext.request.contextPath}/tickets/${t.ticketId}/cancel"
                          onsubmit="return confirm('Cancel this ticket?')">
                        <button type="submit" class="btn btn-sm btn-danger-ghost">Cancel Ticket</button>
                    </form>
                </c:if>
            </div>
            <div class="bp-stub"><span class="notch"></span>
                <small>Boarding pass</small>
                <div class="pn">${t.passengerName}</div>
                <div class="bid2">${t.bookingId} &middot; ${t.seatNo}</div>
                <div class="barcode"></div>
                <small>${booking.flight.source} &rarr; ${booking.flight.destination}</small>
            </div>
        </div>
    </c:forEach>

    <a href="${pageContext.request.contextPath}/my-bookings" class="btn btn-ghost" style="margin-top:6px">&larr; Back to My Bookings</a>
</div>

<%@ include file="footer.jspf" %>
