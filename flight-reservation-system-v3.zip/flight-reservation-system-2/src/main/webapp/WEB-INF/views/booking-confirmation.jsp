<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Booking Confirmation - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#127881;</span><div class="inner">
    <span class="crumb">&#127915; Booking</span>
    <h2>Booking <span class="hl">Confirmed</span></h2>
    <p>${booking.flight.flightNumber} &middot; ${booking.flight.source} &rarr; ${booking.flight.destination}</p>
</div></div>

<div class="wrap">
    <c:set var="step" value="3"/>
    <%@ include file="booking-steps.jspf" %>

    <div class="card" style="max-width:640px">
        <div class="confirm-hero">
            <div class="tick">&#10003;</div>
            <h3 style="font-size:22px">Booking Confirmed!</h3>
            <p class="sub" style="margin-bottom:0">Your booking was successful. Your</p>
            <div class="bid">BOOKING ID: ${booking.bookingId}</div>
        </div>
        <dl class="kv">
            <dt>Booking ID</dt><dd>${booking.bookingId}</dd>
            <dt>Flight Number</dt><dd>${booking.flight.flightNumber}</dd>
            <dt>Route</dt><dd>${booking.flight.source} &rarr; ${booking.flight.destination}</dd>
            <dt>Journey Date</dt><dd>${booking.travelDate}</dd>
            <dt>Passengers</dt><dd>${booking.seats}</dd>
            <dt>Total Price</dt><dd>&#8377;<fmt:formatNumber value="${booking.totalPrice}" type="number" maxFractionDigits="2"/></dd>
            <dt>Status</dt><dd><span class="status st-ok">${booking.status}</span></dd>
        </dl>
        <div class="next-steps">
            <b class="h">&#128203; Next Steps</b>
            <ul>
                <li>Arrive at the airport at least <b>2 hours</b> before departure.</li>
                <li>Carry a <b>valid photo ID</b> for every passenger.</li>
                <li>Check in online to get your boarding pass.</li>
                <li>You can view or cancel your tickets any time from <b>My Bookings</b>.</li>
            </ul>
        </div>
        <div class="stack" style="margin-top:20px">
            <a href="${pageContext.request.contextPath}/dashboard" class="btn btn-primary">Go to Dashboard &rarr;</a>
            <button type="button" class="btn btn-ghost" onclick="window.print()">&#128438; Print Confirmation</button>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
