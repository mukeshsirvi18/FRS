<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="center-page">
    <div class="card auth-card">
        <div class="auth-side">
            <h2>Ready for<br>takeoff? &#9992;</h2>
            <p>Login karke flights search karo, tickets book karo aur apni saari bookings ek jagah manage karo.</p>
            <div class="pts">
                <div><span>&#128269;</span> Search flights by route &amp; date</div>
                <div><span>&#127915;</span> Book up to 10 passengers at once</div>
                <div><span>&#128203;</span> View &amp; cancel tickets anytime</div>
            </div>
        </div>
        <div class="auth-form">
            <h3>Welcome back</h3>
            <p class="sub">Login to continue booking</p>
            <c:if test="${not empty infoMessage}">
                <div class="alert alert-info">${infoMessage}</div>
            </c:if>
            <c:if test="${not empty loginError}">
                <div class="alert alert-err">${loginError}</div>
            </c:if>
            <form:form modelAttribute="loginForm" method="post"
                       action="${pageContext.request.contextPath}/login">
                <div class="field">
                    <form:label path="email" cssClass="">Email</form:label>
                    <form:input path="email" type="email" cssClass="" placeholder="you@example.com"/>
                    <form:errors path="email" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="password" cssClass="">Password</form:label>
                    <form:password path="password" cssClass="" placeholder="&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;&#8226;"/>
                    <form:errors path="password" cssClass="err"/>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Login &rarr;</button>
            </form:form>
            <p class="alt-link">
                New user?
                <a href="${pageContext.request.contextPath}/signup">Sign up here</a>
            </p>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
