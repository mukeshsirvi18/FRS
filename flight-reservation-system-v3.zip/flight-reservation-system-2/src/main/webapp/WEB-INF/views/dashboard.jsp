<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>My Dashboard - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="page-head"><span class="float-plane">&#127915;</span><div class="inner">
    <span class="crumb">&#128100; My account</span>
    <h2>My <span class="hl">Dashboard</span></h2>
    <p>Welcome, ${sessionScope.user.email}.</p>
</div></div>

<div class="wrap">
    <div class="dash-cards">
        <div class="dash-card">
            <div class="ic">&#127915;</div>
            <h3>My Bookings</h3>
            <p>View your tickets and cancel bookings.</p>
            <a href="${pageContext.request.contextPath}/my-bookings" class="btn btn-primary btn-sm">My Bookings &rarr;</a>
        </div>
        <div class="dash-card">
            <div class="ic">&#128269;</div>
            <h3>Search Flights</h3>
            <p>Find flights and book your next trip.</p>
            <a href="${pageContext.request.contextPath}/" class="btn btn-primary btn-sm">Search Flights &rarr;</a>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
