<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%@ include file="taglibs.jspf" %>
<!DOCTYPE html>
<html>
<head>
    <title>Sign Up - Flight Reservation System</title>
    <%@ include file="styles.jspf" %>
</head>
<body>
<%@ include file="header.jspf" %>

<div class="center-page">
    <div class="card auth-card">
        <div class="auth-side">
            <h2>Create your<br>account &#9992;</h2>
            <p>Ek account banao aur flight booking shuru karo — sirf email, password aur role chahiye.</p>
            <div class="pts">
                <div><span>&#128269;</span> Search flights by route &amp; date</div>
                <div><span>&#127915;</span> Book up to 10 passengers at once</div>
                <div><span>&#128203;</span> View &amp; cancel tickets anytime</div>
            </div>
        </div>
        <div class="auth-form">
            <h3>Sign Up</h3>
            <p class="sub">Create a new account</p>
            <form:form modelAttribute="signupForm" method="post"
                       action="${pageContext.request.contextPath}/signup">
                <div class="field">
                    <form:label path="email" cssClass="">Email</form:label>
                    <form:input path="email" type="email" cssClass="" placeholder="you@example.com"/>
                    <form:errors path="email" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="password" cssClass="">Password</form:label>
                    <form:password path="password" cssClass="" placeholder="Choose a strong password"/>
                    <form:errors path="password" cssClass="err"/>
                </div>
                <div class="field">
                    <form:label path="role" cssClass="">Role</form:label>
                    <form:select path="role" cssClass="">
                        <form:option value="User" label="User"/>
                        <form:option value="Admin" label="Admin"/>
                    </form:select>
                    <form:errors path="role" cssClass="err"/>
                </div>
                <button type="submit" class="btn btn-primary btn-block">Sign Up &rarr;</button>
            </form:form>
            <p class="alt-link">
                Already registered?
                <a href="${pageContext.request.contextPath}/login">Login here</a>
            </p>
        </div>
    </div>
</div>

<%@ include file="footer.jspf" %>
