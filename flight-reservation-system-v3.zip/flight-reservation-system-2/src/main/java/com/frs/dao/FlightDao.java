package com.frs.dao;

import com.frs.model.Flight;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class FlightDao {

    private final JdbcTemplate jdbcTemplate;

    public FlightDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Flight> ROW_MAPPER = (rs, rowNum) -> {
        Flight flight = new Flight();
        flight.setFlightId(rs.getLong("flight_id"));
        flight.setFlightNumber(rs.getString("flight_number"));
        flight.setSource(rs.getString("source"));
        flight.setDestination(rs.getString("destination"));
        flight.setDepartureTime(rs.getString("departure_time"));
        flight.setArrivalTime(rs.getString("arrival_time"));
        flight.setCapacity(rs.getInt("capacity"));
        flight.setPricePerSeat(rs.getDouble("price_per_seat"));
        return flight;
    };

    public List<Flight> findAll() {
        return jdbcTemplate.query(
                "SELECT flight_id, flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat " +
                "FROM flight ORDER BY flight_number",
                ROW_MAPPER);
    }

    public Optional<Flight> findById(Long flightId) {
        try {
            Flight flight = jdbcTemplate.queryForObject(
                    "SELECT flight_id, flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat " +
                    "FROM flight WHERE flight_id = ?",
                    ROW_MAPPER, flightId);
            return Optional.ofNullable(flight);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public List<Flight> search(String source, String destination) {
        return jdbcTemplate.query(
                "SELECT flight_id, flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat " +
                "FROM flight WHERE source = ? AND destination = ? ORDER BY departure_time",
                ROW_MAPPER, source, destination);
    }

    public Long save(Flight flight) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO flight (flight_number, source, destination, departure_time, arrival_time, capacity, price_per_seat) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, flight.getFlightNumber());
            ps.setString(2, flight.getSource());
            ps.setString(3, flight.getDestination());
            ps.setString(4, flight.getDepartureTime());
            ps.setString(5, flight.getArrivalTime());
            ps.setInt(6, flight.getCapacity());
            ps.setDouble(7, flight.getPricePerSeat());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    /** Used by the service to enforce the unique-flight-number rule. */
    public boolean existsByFlightNumber(String flightNumber) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM flight WHERE flight_number = ?", Integer.class, flightNumber);
        return count != null && count > 0;
    }
}
