package com.frs.dao;

import com.frs.model.Booking;
import com.frs.model.dto.FlightJourneyStats;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class BookingDao {

    private final JdbcTemplate jdbcTemplate;

    public BookingDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Booking> ROW_MAPPER = (rs, rowNum) -> {
        Booking booking = new Booking();
        booking.setBookingId(rs.getLong("booking_id"));
        Date bookingDate = rs.getDate("booking_date");
        booking.setBookingDate(bookingDate != null ? bookingDate.toLocalDate() : null);
        Date travelDate = rs.getDate("travel_date");
        booking.setTravelDate(travelDate != null ? travelDate.toLocalDate() : null);
        booking.setSeats(rs.getInt("seats"));
        booking.setTotalPrice(rs.getDouble("total_price"));
        booking.setStatus(rs.getString("status"));
        booking.setFlightId(rs.getLong("flight_id"));
        booking.setUserId(rs.getLong("user_id"));
        return booking;
    };

    public Long save(Booking booking) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO booking (booking_date, travel_date, seats, total_price, status, flight_id, user_id) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setDate(1, Date.valueOf(booking.getBookingDate()));
            ps.setDate(2, Date.valueOf(booking.getTravelDate()));
            ps.setInt(3, booking.getSeats());
            ps.setDouble(4, booking.getTotalPrice());
            ps.setString(5, booking.getStatus());
            ps.setLong(6, booking.getFlightId());
            ps.setLong(7, booking.getUserId());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public Optional<Booking> findById(Long bookingId) {
        try {
            Booking booking = jdbcTemplate.queryForObject(
                    "SELECT booking_id, booking_date, travel_date, seats, total_price, status, flight_id, user_id " +
                    "FROM booking WHERE booking_id = ?",
                    ROW_MAPPER, bookingId);
            return Optional.ofNullable(booking);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public List<Booking> findByUserId(Long userId) {
        return jdbcTemplate.query(
                "SELECT booking_id, booking_date, travel_date, seats, total_price, status, flight_id, user_id " +
                "FROM booking WHERE user_id = ? ORDER BY booking_id DESC",
                ROW_MAPPER, userId);
    }

    public int updateStatus(Long bookingId, String status) {
        return jdbcTemplate.update(
                "UPDATE booking SET status = ? WHERE booking_id = ?", status, bookingId);
    }

    /**
     * Per-flight, per-journey-date aggregates for the admin "View Flights" page.
     * Only flights that have at least one active (BOOKED) booking are returned.
     */
    public List<FlightJourneyStats> findJourneyStats() {
        RowMapper<FlightJourneyStats> statsMapper = (rs, rowNum) -> {
            FlightJourneyStats stats = new FlightJourneyStats();
            stats.setFlightId(rs.getLong("flight_id"));
            stats.setFlightNumber(rs.getString("flight_number"));
            stats.setSource(rs.getString("source"));
            stats.setDestination(rs.getString("destination"));
            Date journeyDate = rs.getDate("journey_date");
            stats.setJourneyDate(journeyDate != null ? journeyDate.toLocalDate() : null);
            stats.setTotalBookings(rs.getInt("total_bookings"));
            stats.setTotalPassengers(rs.getInt("total_passengers"));
            stats.setTotalRevenue(rs.getDouble("total_revenue"));
            return stats;
        };
        return jdbcTemplate.query(
                "SELECT f.flight_id, f.flight_number, f.source, f.destination, b.travel_date AS journey_date, " +
                "COUNT(DISTINCT b.booking_id) AS total_bookings, " +
                "COUNT(t.ticket_id) AS total_passengers, " +
                "COALESCE(SUM(b.total_price), 0) AS total_revenue " +
                "FROM booking b JOIN flight f ON b.flight_id = f.flight_id " +
                "LEFT JOIN ticket t ON t.booking_id = b.booking_id AND t.status = 'BOOKED' " +
                "WHERE b.status = 'BOOKED' " +
                "GROUP BY f.flight_id, f.flight_number, f.source, f.destination, b.travel_date " +
                "ORDER BY b.travel_date",
                statsMapper);
    }
}
