package com.frs.dao;

import com.frs.model.Ticket;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

@Repository
public class TicketDao {

    private final JdbcTemplate jdbcTemplate;

    public TicketDao(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    private static final RowMapper<Ticket> ROW_MAPPER = (rs, rowNum) -> {
        Ticket ticket = new Ticket();
        ticket.setTicketId(rs.getLong("ticket_id"));
        ticket.setPassengerName(rs.getString("passenger_name"));
        ticket.setGender(rs.getString("gender"));
        int age = rs.getInt("age");
        ticket.setAge(rs.wasNull() ? null : age);
        Date journeyDate = rs.getDate("journey_date");
        ticket.setJourneyDate(journeyDate != null ? journeyDate.toLocalDate() : null);
        ticket.setSeatNo(rs.getString("seat_no"));
        ticket.setBookingId(rs.getLong("booking_id"));
        ticket.setStatus(rs.getString("status"));
        return ticket;
    };

    public Long save(Ticket ticket) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO ticket (passenger_name, gender, age, journey_date, seat_no, booking_id, status) " +
                    "VALUES (?, ?, ?, ?, ?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, ticket.getPassengerName());
            ps.setString(2, ticket.getGender());
            if (ticket.getAge() != null) {
                ps.setInt(3, ticket.getAge());
            } else {
                ps.setNull(3, java.sql.Types.INTEGER);
            }
            ps.setDate(4, Date.valueOf(ticket.getJourneyDate()));
            ps.setString(5, ticket.getSeatNo());
            ps.setLong(6, ticket.getBookingId());
            ps.setString(7, ticket.getStatus());
            return ps;
        }, keyHolder);
        Number key = keyHolder.getKey();
        return key != null ? key.longValue() : null;
    }

    public Optional<Ticket> findById(Long ticketId) {
        try {
            Ticket ticket = jdbcTemplate.queryForObject(
                    "SELECT ticket_id, passenger_name, gender, age, journey_date, seat_no, booking_id, status " +
                    "FROM ticket WHERE ticket_id = ?",
                    ROW_MAPPER, ticketId);
            return Optional.ofNullable(ticket);
        } catch (EmptyResultDataAccessException e) {
            return Optional.empty();
        }
    }

    public List<Ticket> findByBookingId(Long bookingId) {
        return jdbcTemplate.query(
                "SELECT ticket_id, passenger_name, gender, age, journey_date, seat_no, booking_id, status " +
                "FROM ticket WHERE booking_id = ? ORDER BY ticket_id",
                ROW_MAPPER, bookingId);
    }

    /** Number of active (BOOKED) tickets on a flight - drives seat availability. */
    public int countActiveByFlightId(Long flightId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ticket t JOIN booking b ON t.booking_id = b.booking_id " +
                "WHERE b.flight_id = ? AND t.status = 'BOOKED'",
                Integer.class, flightId);
        return count != null ? count : 0;
    }

    /** Seat numbers currently occupied (BOOKED) on a flight. */
    public List<String> findActiveSeatNosByFlightId(Long flightId) {
        return jdbcTemplate.queryForList(
                "SELECT t.seat_no FROM ticket t JOIN booking b ON t.booking_id = b.booking_id " +
                "WHERE b.flight_id = ? AND t.status = 'BOOKED'",
                String.class, flightId);
    }

    public int countActiveByBookingId(Long bookingId) {
        Integer count = jdbcTemplate.queryForObject(
                "SELECT COUNT(*) FROM ticket WHERE booking_id = ? AND status = 'BOOKED'",
                Integer.class, bookingId);
        return count != null ? count : 0;
    }

    public int updateStatus(Long ticketId, String status) {
        return jdbcTemplate.update(
                "UPDATE ticket SET status = ? WHERE ticket_id = ?", status, ticketId);
    }

    public int updateStatusByBookingId(Long bookingId, String status) {
        return jdbcTemplate.update(
                "UPDATE ticket SET status = ? WHERE booking_id = ? AND status = 'BOOKED'",
                status, bookingId);
    }
}
