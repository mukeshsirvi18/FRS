package com.frs.controller;

import com.frs.config.LoginInterceptor;
import com.frs.model.User;
import com.frs.model.dto.FlightSearchForm;
import com.frs.model.dto.LoginForm;
import com.frs.model.dto.SignupForm;
import com.frs.service.UserService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class AuthController {

    private static final Logger log = LoggerFactory.getLogger(AuthController.class);

    private final UserService userService;

    public AuthController(UserService userService) {
        this.userService = userService;
    }

    @GetMapping("/signup")
    public String signupPage(Model model) {
        if (!model.containsAttribute("signupForm")) {
            model.addAttribute("signupForm", new SignupForm());
        }
        return "signup";
    }

    @PostMapping("/signup")
    public String signup(@Valid @ModelAttribute("signupForm") SignupForm form,
                         BindingResult result,
                         RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "signup";
        }
        try {
            userService.register(form);
        } catch (IllegalArgumentException e) {
            result.rejectValue("email", "duplicate", e.getMessage());
            return "signup";
        }
        redirectAttributes.addFlashAttribute("infoMessage",
                "Registration successful. Please login with your new account.");
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginPage(Model model) {
        if (!model.containsAttribute("loginForm")) {
            model.addAttribute("loginForm", new LoginForm());
        }
        return "login";
    }

    @PostMapping("/login")
    public String login(@Valid @ModelAttribute("loginForm") LoginForm form,
                        BindingResult result,
                        HttpSession session,
                        RedirectAttributes redirectAttributes,
                        Model model) {
        if (result.hasErrors()) {
            return "login";
        }
        final User user;
        try {
            user = userService.authenticate(form.getEmail(), form.getPassword());
        } catch (IllegalArgumentException e) {
            model.addAttribute("loginError", e.getMessage());
            return "login";
        }
        session.setAttribute("user", user);

        // 1. Resume a flight search that was interrupted by the login wall.
        FlightSearchForm pending = (FlightSearchForm) session.getAttribute("pendingSearch");
        if (pending != null) {
            session.removeAttribute("pendingSearch");
            redirectAttributes.addAttribute("source", pending.getSource().trim());
            redirectAttributes.addAttribute("destination", pending.getDestination().trim());
            redirectAttributes.addAttribute("travelDate", pending.getTravelDate().toString());
            log.info("User {} resumed interrupted search after login", user.getEmail());
            return "redirect:/flights";
        }

        // 2. Resume the page the user was heading to when the login wall
        //    stopped them (e.g. clicking "Book" on a flight -> Booking Form
        //    for that flight). The saved value must be a local path.
        String resume = (String) session.getAttribute(LoginInterceptor.POST_LOGIN_REDIRECT);
        if (resume != null) {
            session.removeAttribute(LoginInterceptor.POST_LOGIN_REDIRECT);
            if (resume.startsWith("/") && !resume.startsWith("//")) {
                log.info("User {} resumed {} after login", user.getEmail(), resume);
                return "redirect:" + resume;
            }
            log.warn("Ignored unsafe post-login redirect target: {}", resume);
        }

        // 3. Default landing pages by role.
        if (user.isAdmin()) {
            return "redirect:/admin/dashboard";
        }
        return "redirect:/dashboard";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        User user = (User) session.getAttribute("user");
        if (user != null) {
            log.info("User logged out: {}", user.getEmail());
        }
        session.invalidate();
        return "redirect:/";
    }
}
