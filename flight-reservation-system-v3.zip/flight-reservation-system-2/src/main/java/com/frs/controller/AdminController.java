package com.frs.controller;

import com.frs.model.Flight;
import com.frs.model.dto.FlightForm;
import com.frs.model.dto.FlightJourneyStats;
import com.frs.service.FlightService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    private static final Logger log = LoggerFactory.getLogger(AdminController.class);

    private final FlightService flightService;

    public AdminController(FlightService flightService) {
        this.flightService = flightService;
    }

    /** Admin dashboard: two cards - "Add New Flight" and "View Flights". */
    @GetMapping("/dashboard")
    public String dashboard() {
        return "admin/dashboard";
    }

    /**
     * View Flights page with two tabs: "Upcoming Journeys" and
     * "Completed Journey". Only flights that have bookings are shown.
     */
    @GetMapping("/flights")
    public String viewFlights(Model model) {
        List<FlightJourneyStats> upcoming = flightService.getUpcomingJourneys();
        List<FlightJourneyStats> completed = flightService.getCompletedJourneys();
        model.addAttribute("upcoming", upcoming);
        model.addAttribute("completed", completed);
        log.debug("Admin viewed flights: {} upcoming, {} completed journey rows",
                upcoming.size(), completed.size());
        return "admin/view-flights";
    }

    @GetMapping("/flights/new")
    public String addFlightPage(Model model) {
        if (!model.containsAttribute("flightForm")) {
            model.addAttribute("flightForm", new FlightForm()); // capacity defaults to 20
        }
        return "admin/add-flight";
    }

    /**
     * Adds a flight. All fields are validated with Spring Forms; a
     * duplicate flight number is rejected with a validation error on
     * the same screen.
     */
    @PostMapping("/flights")
    public String addFlight(@Valid @ModelAttribute("flightForm") FlightForm form,
                            BindingResult result) {
        if (result.hasErrors()) {
            return "admin/add-flight";
        }
        try {
            Flight saved = flightService.addFlight(form);
            log.info("Admin added flight {} (id {})", saved.getFlightNumber(), saved.getFlightId());
        } catch (IllegalArgumentException e) {
            result.rejectValue("flightNumber", "duplicate", e.getMessage());
            return "admin/add-flight";
        }
        return "redirect:/admin/flights";
    }
}
