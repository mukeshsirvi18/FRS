package com.frs.controller;

import com.frs.model.Flight;
import com.frs.service.FlightService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
public class FlightController {

    private static final Logger log = LoggerFactory.getLogger(FlightController.class);

    private final FlightService flightService;

    public FlightController(FlightService flightService) {
        this.flightService = flightService;
    }

    /** Lists flights matching the search; requires login (LoginInterceptor). */
    @GetMapping("/flights")
    public String listFlights(@RequestParam String source,
                              @RequestParam String destination,
                              @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate travelDate,
                              Model model) {
        List<Flight> flights = flightService.searchFlights(source, destination);
        model.addAttribute("flights", flights);
        model.addAttribute("source", source);
        model.addAttribute("destination", destination);
        model.addAttribute("travelDate", travelDate);
        log.debug("Rendered {} flight(s) for {} -> {} on {}", flights.size(), source, destination, travelDate);
        return "list-flights";
    }
}
