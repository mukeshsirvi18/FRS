package com.frs.controller;

import com.frs.model.User;
import com.frs.model.dto.FlightSearchForm;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
public class HomeController {

    private static final Logger log = LoggerFactory.getLogger(HomeController.class);

    /** Landing page: search-flights form + login/signup user actions. */
    @GetMapping("/")
    public String home(Model model) {
        if (!model.containsAttribute("searchForm")) {
            model.addAttribute("searchForm", new FlightSearchForm());
        }
        return "home";
    }

    /**
     * Handles the home-page search form. The form is validated with
     * Spring Forms (@Valid + BindingResult). Logged-out users are sent
     * to the login page first (the "Is logged in?" decision in the
     * flow diagram); their search is resumed right after login.
     */
    @PostMapping("/search")
    public String search(@Valid @ModelAttribute("searchForm") FlightSearchForm form,
                         BindingResult result,
                         HttpSession session,
                         RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            return "home";
        }
        User user = (User) session.getAttribute("user");
        if (user == null) {
            session.setAttribute("pendingSearch", form);
            redirectAttributes.addFlashAttribute("infoMessage", "Please login to search flights.");
            log.debug("Search held behind login wall for {} -> {}", form.getSource(), form.getDestination());
            return "redirect:/login";
        }
        redirectAttributes.addAttribute("source", form.getSource().trim());
        redirectAttributes.addAttribute("destination", form.getDestination().trim());
        redirectAttributes.addAttribute("travelDate", form.getTravelDate().toString());
        return "redirect:/flights";
    }
}
