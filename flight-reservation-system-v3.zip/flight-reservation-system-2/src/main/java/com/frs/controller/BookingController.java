package com.frs.controller;

import com.frs.model.Booking;
import com.frs.model.Flight;
import com.frs.model.Ticket;
import com.frs.model.User;
import com.frs.model.dto.BookingContext;
import com.frs.model.dto.BookingForm;
import com.frs.model.dto.PassengerForm;
import com.frs.service.BookingService;
import com.frs.service.FlightService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.List;

@Controller
public class BookingController {

    private static final Logger log = LoggerFactory.getLogger(BookingController.class);

    /** Session attribute holding the in-progress booking. */
    private static final String BOOKING_CONTEXT = "bookingContext";

    private final FlightService flightService;
    private final BookingService bookingService;

    public BookingController(FlightService flightService, BookingService bookingService) {
        this.flightService = flightService;
        this.bookingService = bookingService;
    }

    // ------------------------------------------------------------------
    // User dashboard: "My Dashboard" with exactly two links.
    // ------------------------------------------------------------------

    @GetMapping("/dashboard")
    public String dashboard() {
        return "dashboard";
    }

    // ------------------------------------------------------------------
    // Booking Form page: flight number, journey date, passenger count.
    // ------------------------------------------------------------------

    /** Step 1: shows the Booking Form for a flight. */
    @GetMapping("/book/{flightId}")
    public String bookingForm(@PathVariable Long flightId, Model model) {
        Flight flight = flightService.getFlight(flightId);
        BookingForm form = new BookingForm();
        form.setFlightId(flightId);
        model.addAttribute("flight", flight);
        model.addAttribute("bookingForm", form);
        model.addAttribute("availableSeats", flight.getAvailableSeats());
        return "booking-form";
    }

    /**
     * Step 1 submit: validates the form with Spring Forms (@Valid +
     * BindingResult) and checks seat availability. If fewer seats are
     * available than requested, an error is shown on the same screen
     * and the flow does NOT proceed. Otherwise the user moves on to
     * the sequential add-passenger flow.
     */
    @PostMapping("/book/{flightId}")
    public String startBooking(@PathVariable Long flightId,
                               @Valid @ModelAttribute("bookingForm") BookingForm form,
                               BindingResult result,
                               HttpSession session,
                               Model model) {
        Flight flight = flightService.getFlight(flightId);
        model.addAttribute("flight", flight);
        if (!result.hasErrors()) {
            int available = flightService.getAvailableSeats(flightId);
            model.addAttribute("availableSeats", available);
            if (form.getPassengers() > available) {
                result.rejectValue("passengers", "seats.unavailable",
                        "Only " + available + " seat(s) available on flight "
                                + flight.getFlightNumber() + ".");
            }
        }
        if (result.hasErrors()) {
            return "booking-form";
        }
        session.setAttribute(BOOKING_CONTEXT,
                new BookingContext(flightId, form.getJourneyDate(), form.getPassengers()));
        log.info("Booking started for flight {}: {} passenger(s) on {}",
                flight.getFlightNumber(), form.getPassengers(), form.getJourneyDate());
        return "redirect:/book/passengers";
    }

    // ------------------------------------------------------------------
    // Sequential add-passenger flow: one screen per passenger.
    // ------------------------------------------------------------------

    /** Shows "Add Passenger N" with the remaining-passenger count. */
    @GetMapping("/book/passengers")
    public String addPassengerPage(HttpSession session, Model model) {
        BookingContext ctx = bookingContext(session);
        if (ctx == null) {
            return "redirect:/";
        }
        model.addAttribute("passengerNumber", ctx.getCurrentIndex() + 1);
        model.addAttribute("remaining", ctx.getRemaining());
        model.addAttribute("flight", flightService.getFlight(ctx.getFlightId()));
        model.addAttribute("travelDate", ctx.getTravelDate());
        if (!model.containsAttribute("passengerForm")) {
            model.addAttribute("passengerForm", new PassengerForm());
        }
        return "add-passenger";
    }

    /**
     * Saves one passenger (validated with Spring Forms) and either
     * shows the next passenger screen or, after the last passenger,
     * creates the booking and goes to the confirmation page.
     */
    @PostMapping("/book/passengers")
    public String addPassenger(@Valid @ModelAttribute("passengerForm") PassengerForm form,
                               BindingResult result,
                               HttpSession session,
                               Model model,
                               RedirectAttributes redirectAttributes) {
        BookingContext ctx = bookingContext(session);
        if (ctx == null) {
            return "redirect:/";
        }
        if (result.hasErrors()) {
            model.addAttribute("passengerNumber", ctx.getCurrentIndex() + 1);
            model.addAttribute("remaining", ctx.getRemaining());
            model.addAttribute("flight", flightService.getFlight(ctx.getFlightId()));
            model.addAttribute("travelDate", ctx.getTravelDate());
            return "add-passenger";
        }
        ctx.getPassengers().add(form);
        log.debug("Collected passenger {}/{} for in-progress booking",
                ctx.getPassengers().size(), ctx.getTotalPassengers());
        if (!ctx.isComplete()) {
            return "redirect:/book/passengers";
        }
        // Last passenger done -> create the booking transactionally.
        User user = currentUser(session);
        Booking booking;
        try {
            booking = bookingService.createBooking(
                    user.getUserId(), ctx.getFlightId(), ctx.getTravelDate(), ctx.getPassengers());
        } catch (IllegalStateException e) {
            // Seats ran out while entering passengers.
            session.removeAttribute(BOOKING_CONTEXT);
            redirectAttributes.addFlashAttribute("bookingError", e.getMessage());
            return "redirect:/my-bookings";
        }
        session.removeAttribute(BOOKING_CONTEXT);
        return "redirect:/book/confirmation?bookingId=" + booking.getBookingId();
    }

    // ------------------------------------------------------------------
    // Booking Confirmation page: booking id, summary, next steps.
    // ------------------------------------------------------------------

    @GetMapping("/book/confirmation")
    public String confirmation(@RequestParam Long bookingId,
                               HttpSession session,
                               Model model) {
        User user = currentUser(session);
        Booking booking = bookingService.getBookingDetails(bookingId, user.getUserId());
        model.addAttribute("booking", booking);
        return "booking-confirmation";
    }

    // ------------------------------------------------------------------
    // My Bookings: only the logged-in user's bookings, with
    // "View Ticket" and "Cancel Ticket" actions per row.
    // ------------------------------------------------------------------

    @GetMapping("/my-bookings")
    public String myBookings(HttpSession session, Model model) {
        User user = currentUser(session);
        List<Booking> bookings = bookingService.getMyBookings(user.getUserId());
        model.addAttribute("bookings", bookings);
        return "my-bookings";
    }

    /** Cancels a whole booking (all its tickets); seats are released. */
    @PostMapping("/bookings/{bookingId}/cancel")
    public String cancelBooking(@PathVariable Long bookingId,
                                HttpSession session,
                                RedirectAttributes redirectAttributes) {
        User user = currentUser(session);
        try {
            bookingService.cancelBooking(bookingId, user.getUserId());
            redirectAttributes.addFlashAttribute("infoMessage",
                    "Booking " + bookingId + " cancelled. The seats are now available again.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("bookingError", e.getMessage());
        }
        return "redirect:/my-bookings";
    }

    // ------------------------------------------------------------------
    // View Tickets: one card per passenger in the booking.
    // ------------------------------------------------------------------

    @GetMapping("/bookings/{bookingId}/tickets")
    public String viewTickets(@PathVariable Long bookingId,
                              HttpSession session,
                              Model model) {
        User user = currentUser(session);
        Booking booking = bookingService.getBookingDetails(bookingId, user.getUserId());
        model.addAttribute("booking", booking);
        return "view-tickets";
    }

    /** Cancels a single ticket (owner only). */
    @PostMapping("/tickets/{ticketId}/cancel")
    public String cancelTicket(@PathVariable Long ticketId,
                               HttpSession session,
                               RedirectAttributes redirectAttributes) {
        User user = currentUser(session);
        try {
            bookingService.cancelTicket(ticketId, user.getUserId());
            redirectAttributes.addFlashAttribute("infoMessage", "Ticket cancelled.");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("bookingError", e.getMessage());
        }
        Ticket ticket = bookingService.getTicketDetails(ticketId, user.getUserId());
        return "redirect:/bookings/" + ticket.getBookingId() + "/tickets";
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private User currentUser(HttpSession session) {
        return (User) session.getAttribute("user");
    }

    private BookingContext bookingContext(HttpSession session) {
        return (BookingContext) session.getAttribute(BOOKING_CONTEXT);
    }
}
