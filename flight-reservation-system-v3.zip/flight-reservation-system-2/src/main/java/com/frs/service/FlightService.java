package com.frs.service;

import com.frs.dao.BookingDao;
import com.frs.dao.FlightDao;
import com.frs.dao.TicketDao;
import com.frs.model.Flight;
import com.frs.model.dto.FlightForm;
import com.frs.model.dto.FlightJourneyStats;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class FlightService {

    private static final Logger log = LoggerFactory.getLogger(FlightService.class);

    private final FlightDao flightDao;
    private final TicketDao ticketDao;
    private final BookingDao bookingDao;

    public FlightService(FlightDao flightDao, TicketDao ticketDao, BookingDao bookingDao) {
        this.flightDao = flightDao;
        this.ticketDao = ticketDao;
        this.bookingDao = bookingDao;
    }

    /** All flights with live availability and trip status attached. */
    public List<Flight> getAllFlights() {
        List<Flight> flights = flightDao.findAll();
        flights.forEach(this::enrich);
        return flights;
    }

    /** Flights matching source/destination with live availability attached. */
    public List<Flight> searchFlights(String source, String destination) {
        List<Flight> flights = flightDao.search(source.trim(), destination.trim());
        flights.forEach(this::enrich);
        log.info("Flight search {} -> {} returned {} result(s)", source, destination, flights.size());
        return flights;
    }

    public Flight getFlight(Long flightId) {
        Flight flight = flightDao.findById(flightId)
                .orElseThrow(() -> new IllegalArgumentException("Flight not found."));
        enrich(flight);
        return flight;
    }

    /**
     * Adds a new flight. Flight numbers must be unique; a duplicate is
     * rejected with a validation error on the form.
     */
    public Flight addFlight(FlightForm form) {
        String flightNumber = form.getFlightNumber().trim();
        if (flightDao.existsByFlightNumber(flightNumber)) {
            log.warn("Duplicate flight number rejected: {}", flightNumber);
            throw new IllegalArgumentException(
                    "Flight number " + flightNumber + " already exists. Please use a unique flight number.");
        }
        Flight flight = new Flight();
        flight.setFlightNumber(flightNumber);
        flight.setSource(form.getSource().trim());
        flight.setDestination(form.getDestination().trim());
        flight.setDepartureTime(normalizeTime(form.getDepartureTime()));
        flight.setArrivalTime(normalizeTime(form.getArrivalTime()));
        flight.setCapacity(form.getCapacity());
        flight.setPricePerSeat(form.getPricePerSeat());
        Long id = flightDao.save(flight);
        flight.setFlightId(id);
        log.info("Added new flight {} ({} -> {})", flightNumber, flight.getSource(), flight.getDestination());
        enrich(flight);
        return flight;
    }

    /** Available seats = capacity - active (BOOKED) tickets. */
    public int getAvailableSeats(Long flightId) {
        Flight flight = flightDao.findById(flightId)
                .orElseThrow(() -> new IllegalArgumentException("Flight not found."));
        return Math.max(0, flight.getCapacity() - ticketDao.countActiveByFlightId(flightId));
    }

    /**
     * Per-flight, per-journey-date aggregates (only flights that have
     * bookings), split into upcoming and completed journeys for the
     * admin "View Flights" tabs.
     */
    public List<FlightJourneyStats> getUpcomingJourneys() {
        LocalDate today = LocalDate.now();
        return loadJourneyStats().stream()
                .filter(s -> !s.getJourneyDate().isBefore(today))
                .collect(Collectors.toList());
    }

    public List<FlightJourneyStats> getCompletedJourneys() {
        LocalDate today = LocalDate.now();
        return loadJourneyStats().stream()
                .filter(s -> s.getJourneyDate().isBefore(today))
                .collect(Collectors.toList());
    }

    private List<FlightJourneyStats> loadJourneyStats() {
        LocalDate today = LocalDate.now();
        List<FlightJourneyStats> stats = bookingDao.findJourneyStats();
        stats.forEach(s -> s.setDaysUntilJourney(ChronoUnit.DAYS.between(today, s.getJourneyDate())));
        return stats;
    }

    private void enrich(Flight flight) {
        int booked = ticketDao.countActiveByFlightId(flight.getFlightId());
        flight.setAvailableSeats(Math.max(0, flight.getCapacity() - booked));
        flight.setTripStatus(deriveTripStatus(flight.getDepartureTime()));
    }

    /**
     * All flights run daily, so a flight is "Completed" once today's
     * departure time has passed, otherwise "Upcoming".
     */
    private String deriveTripStatus(String departureTime) {
        if (departureTime == null || departureTime.isBlank()) {
            return "Upcoming";
        }
        try {
            LocalTime dep = LocalTime.parse(departureTime.trim());
            return dep.isBefore(LocalTime.now()) ? "Completed" : "Upcoming";
        } catch (Exception e) {
            return "Upcoming";
        }
    }

    private String normalizeTime(String value) {
        if (value == null || value.isBlank()) {
            return null;
        }
        try {
            return LocalTime.parse(value.trim()).toString();
        } catch (Exception e) {
            return value.trim();
        }
    }
}
