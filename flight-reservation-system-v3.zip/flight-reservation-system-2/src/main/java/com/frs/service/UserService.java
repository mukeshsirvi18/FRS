package com.frs.service;

import com.frs.dao.UserDao;
import com.frs.model.User;
import com.frs.model.dto.SignupForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private static final Logger log = LoggerFactory.getLogger(UserService.class);

    private final UserDao userDao;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserDao userDao, PasswordEncoder passwordEncoder) {
        this.userDao = userDao;
        this.passwordEncoder = passwordEncoder;
    }

    /**
     * Registers a new user. Throws IllegalArgumentException when the
     * email is already taken.
     */
    public User register(SignupForm form) {
        String email = form.getEmail().trim().toLowerCase();
        if (userDao.existsByEmail(email)) {
            log.warn("Signup rejected: email {} already registered", email);
            throw new IllegalArgumentException("Email is already registered. Please login.");
        }
        User user = new User();
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(form.getPassword()));
        user.setRole(form.getRole());
        Long id = userDao.save(user);
        user.setUserId(id);
        log.info("New user registered: {} (role {})", email, user.getRole());
        return user;
    }

    /**
     * Authenticates a user. Throws IllegalArgumentException on
     * unknown email or wrong password.
     */
    public User authenticate(String email, String rawPassword) {
        String normalized = email.trim().toLowerCase();
        User user = userDao.findByEmail(normalized)
                .orElseThrow(() -> {
                    log.warn("Login failed: unknown email {}", normalized);
                    return new IllegalArgumentException("Invalid email or password.");
                });
        if (!passwordEncoder.matches(rawPassword, user.getPassword())) {
            log.warn("Login failed: wrong password for {}", normalized);
            throw new IllegalArgumentException("Invalid email or password.");
        }
        log.info("User logged in: {}", normalized);
        return user;
    }
}
