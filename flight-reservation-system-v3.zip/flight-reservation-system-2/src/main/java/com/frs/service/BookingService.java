package com.frs.service;

import com.frs.dao.BookingDao;
import com.frs.dao.FlightDao;
import com.frs.dao.TicketDao;
import com.frs.model.Booking;
import com.frs.model.Flight;
import com.frs.model.Ticket;
import com.frs.model.dto.PassengerForm;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class BookingService {

    private static final Logger log = LoggerFactory.getLogger(BookingService.class);

    private final BookingDao bookingDao;
    private final TicketDao ticketDao;
    private final FlightDao flightDao;

    public BookingService(BookingDao bookingDao, TicketDao ticketDao, FlightDao flightDao) {
        this.bookingDao = bookingDao;
        this.ticketDao = ticketDao;
        this.flightDao = flightDao;
    }

    /**
     * Creates a booking plus one ticket per passenger in a single
     * transaction. Re-checks seat availability inside the transaction
     * so two concurrent bookings cannot overbook.
     */
    @Transactional
    public Booking createBooking(Long userId, Long flightId, LocalDate travelDate,
                                 List<PassengerForm> passengers) {
        if (passengers == null || passengers.isEmpty()) {
            throw new IllegalArgumentException("At least one passenger is required.");
        }
        Flight flight = flightDao.findById(flightId)
                .orElseThrow(() -> new IllegalArgumentException("Flight not found."));

        int available = flight.getCapacity() - ticketDao.countActiveByFlightId(flightId);
        if (passengers.size() > available) {
            throw new IllegalStateException(
                    "Only " + available + " seat(s) available on flight " + flight.getFlightNumber() + ".");
        }

        Booking booking = new Booking();
        booking.setBookingDate(LocalDate.now());
        booking.setTravelDate(travelDate);
        booking.setSeats(passengers.size());
        booking.setTotalPrice(passengers.size() * flight.getPricePerSeat());
        booking.setStatus(Booking.STATUS_BOOKED);
        booking.setFlightId(flightId);
        booking.setUserId(userId);
        Long bookingId = bookingDao.save(booking);
        booking.setBookingId(bookingId);

        Set<Integer> occupied = parseSeatNumbers(ticketDao.findActiveSeatNosByFlightId(flightId));
        int nextSeat = 1;
        for (PassengerForm p : passengers) {
            while (occupied.contains(nextSeat)) {
                nextSeat++;
            }
            Ticket ticket = new Ticket();
            ticket.setPassengerName(p.getPassengerName().trim());
            ticket.setGender(p.getGender());
            ticket.setAge(p.getAge());
            ticket.setJourneyDate(travelDate);
            ticket.setSeatNo(String.valueOf(nextSeat));
            ticket.setBookingId(bookingId);
            ticket.setStatus(Ticket.STATUS_BOOKED);
            ticketDao.save(ticket);
            occupied.add(nextSeat);
            nextSeat++;
        }
        log.info("Booking {} created: user {}, flight {}, {} passenger(s), date {}",
                bookingId, userId, flight.getFlightNumber(), passengers.size(), travelDate);
        return getBookingDetails(bookingId, userId);
    }

    /** Cancels a whole booking and all its active tickets (owner only). */
    @Transactional
    public void cancelBooking(Long bookingId, Long userId) {
        Booking booking = getOwnedBooking(bookingId, userId);
        if (Booking.STATUS_CANCELLED.equals(booking.getStatus())) {
            throw new IllegalStateException("Booking is already cancelled.");
        }
        ticketDao.updateStatusByBookingId(bookingId, Ticket.STATUS_CANCELLED);
        bookingDao.updateStatus(bookingId, Booking.STATUS_CANCELLED);
        log.info("Booking {} cancelled by user {}", bookingId, userId);
    }

    /**
     * Cancels one ticket (owner only). When the last active ticket of a
     * booking is cancelled, the booking itself becomes CANCELLED.
     */
    @Transactional
    public void cancelTicket(Long ticketId, Long userId) {
        Ticket ticket = ticketDao.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found."));
        Booking booking = getOwnedBooking(ticket.getBookingId(), userId);
        if (Ticket.STATUS_CANCELLED.equals(ticket.getStatus())) {
            throw new IllegalStateException("Ticket is already cancelled.");
        }
        ticketDao.updateStatus(ticketId, Ticket.STATUS_CANCELLED);
        if (ticketDao.countActiveByBookingId(booking.getBookingId()) == 0) {
            bookingDao.updateStatus(booking.getBookingId(), Booking.STATUS_CANCELLED);
        }
        log.info("Ticket {} (booking {}) cancelled by user {}", ticketId, booking.getBookingId(), userId);
    }

    /** All bookings of a user, each with its flight and tickets. */
    public List<Booking> getMyBookings(Long userId) {
        List<Booking> bookings = bookingDao.findByUserId(userId);
        for (Booking b : bookings) {
            flightDao.findById(b.getFlightId()).ifPresent(b::setFlight);
            b.setTickets(ticketDao.findByBookingId(b.getBookingId()));
        }
        return bookings;
    }

    /** Booking + flight + tickets, verifying the booking belongs to the user. */
    public Booking getBookingDetails(Long bookingId, Long userId) {
        Booking booking = getOwnedBooking(bookingId, userId);
        flightDao.findById(booking.getFlightId()).ifPresent(booking::setFlight);
        booking.setTickets(ticketDao.findByBookingId(bookingId));
        return booking;
    }

    /** Ticket details, verifying the ticket belongs to the user. */
    public Ticket getTicketDetails(Long ticketId, Long userId) {
        Ticket ticket = ticketDao.findById(ticketId)
                .orElseThrow(() -> new IllegalArgumentException("Ticket not found."));
        getOwnedBooking(ticket.getBookingId(), userId); // ownership check
        return ticket;
    }

    private Booking getOwnedBooking(Long bookingId, Long userId) {
        Booking booking = bookingDao.findById(bookingId)
                .orElseThrow(() -> new IllegalArgumentException("Booking not found."));
        if (!booking.getUserId().equals(userId)) {
            throw new SecurityException("You are not allowed to access this booking.");
        }
        return booking;
    }

    private Set<Integer> parseSeatNumbers(List<String> seatNos) {
        Set<Integer> result = new HashSet<>();
        for (String s : seatNos) {
            try {
                result.add(Integer.parseInt(s.trim()));
            } catch (Exception ignored) {
                // ignore non-numeric seat labels
            }
        }
        return result;
    }
}
