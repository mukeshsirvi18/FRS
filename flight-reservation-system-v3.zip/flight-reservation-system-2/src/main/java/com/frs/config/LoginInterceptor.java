package com.frs.config;

import com.frs.model.User;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;
import org.springframework.web.servlet.HandlerInterceptor;

/**
 * Blocks unauthenticated access to user pages. Before redirecting to
 * /login, the requested page is saved in the session so that after a
 * successful login the user lands exactly where they wanted to go
 * (e.g. clicking "Book" on a flight takes them to the Booking Form
 * for that flight after logging in).
 */
@Component
public class LoginInterceptor implements HandlerInterceptor {

    private static final Logger log = LoggerFactory.getLogger(LoginInterceptor.class);

    /** Session attribute holding the URL to resume after login. */
    public static final String POST_LOGIN_REDIRECT = "postLoginRedirect";

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
            throws Exception {
        HttpSession session = request.getSession(false);
        User user = (session != null) ? (User) session.getAttribute("user") : null;
        if (user == null) {
            String target = request.getRequestURI();
            String query = request.getQueryString();
            if (query != null && !query.isBlank()) {
                target += "?" + query;
            }
            HttpSession newSession = request.getSession(true);
            newSession.setAttribute(POST_LOGIN_REDIRECT, target);
            log.debug("Unauthenticated request to {}; saved for post-login resume", target);
            response.sendRedirect(request.getContextPath() + "/login");
            return false;
        }
        return true;
    }
}
