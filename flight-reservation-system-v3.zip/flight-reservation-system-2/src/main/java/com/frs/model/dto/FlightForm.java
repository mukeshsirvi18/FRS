package com.frs.model.dto;

import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

/**
 * Backing form for the admin "Add Flight" page.
 * All fields are required; flight number must be unique (checked in service).
 */
public class FlightForm {

    @NotBlank(message = "Flight number is required")
    @Size(max = 30, message = "Flight number must be at most 30 characters")
    private String flightNumber;

    @NotBlank(message = "Source is required")
    @Size(max = 50, message = "Source must be at most 50 characters")
    private String source;

    @NotBlank(message = "Destination is required")
    @Size(max = 50, message = "Destination must be at most 50 characters")
    private String destination;

    /** Time of day as "HH:mm" (from an HTML time input). */
    @NotBlank(message = "Departure time is required")
    private String departureTime;

    /** Time of day as "HH:mm" (from an HTML time input). */
    @NotBlank(message = "Arrival time is required")
    private String arrivalTime;

    @NotNull(message = "Capacity is required")
    @Min(value = 1, message = "Capacity must be at least 1")
    private Integer capacity = 20; // default: all flights run with 20 seats

    @NotNull(message = "Price per seat is required")
    @Positive(message = "Price must be positive")
    private Double pricePerSeat;

    public FlightForm() {
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public String getDepartureTime() {
        return departureTime;
    }

    public void setDepartureTime(String departureTime) {
        this.departureTime = departureTime;
    }

    public String getArrivalTime() {
        return arrivalTime;
    }

    public void setArrivalTime(String arrivalTime) {
        this.arrivalTime = arrivalTime;
    }

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

    public Double getPricePerSeat() {
        return pricePerSeat;
    }

    public void setPricePerSeat(Double pricePerSeat) {
        this.pricePerSeat = pricePerSeat;
    }
}
