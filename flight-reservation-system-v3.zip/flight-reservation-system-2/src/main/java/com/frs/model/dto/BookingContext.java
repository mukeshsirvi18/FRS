package com.frs.model.dto;

import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Holds the in-progress booking while the user moves through the
 * sequential add-passenger flow (one screen per passenger).
 */
public class BookingContext implements Serializable {

    private Long flightId;
    private LocalDate travelDate;
    private int totalPassengers;
    private List<PassengerForm> passengers = new ArrayList<>();

    public BookingContext() {
    }

    public BookingContext(Long flightId, LocalDate travelDate, int totalPassengers) {
        this.flightId = flightId;
        this.travelDate = travelDate;
        this.totalPassengers = totalPassengers;
    }

    /** Index (0-based) of the passenger currently being entered. */
    public int getCurrentIndex() {
        return passengers.size();
    }

    /** How many passenger screens are still left (including the current one). */
    public int getRemaining() {
        return Math.max(0, totalPassengers - passengers.size());
    }

    public boolean isComplete() {
        return passengers.size() >= totalPassengers;
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public LocalDate getTravelDate() {
        return travelDate;
    }

    public void setTravelDate(LocalDate travelDate) {
        this.travelDate = travelDate;
    }

    public int getTotalPassengers() {
        return totalPassengers;
    }

    public void setTotalPassengers(int totalPassengers) {
        this.totalPassengers = totalPassengers;
    }

    public List<PassengerForm> getPassengers() {
        return passengers;
    }

    public void setPassengers(List<PassengerForm> passengers) {
        this.passengers = passengers;
    }
}
