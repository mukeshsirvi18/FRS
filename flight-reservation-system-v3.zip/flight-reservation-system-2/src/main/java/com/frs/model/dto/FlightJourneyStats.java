package com.frs.model.dto;

import java.time.LocalDate;

/**
 * Aggregated per-flight, per-journey-date statistics for the admin
 * "View Flights" page. Only flights that have bookings appear here.
 */
public class FlightJourneyStats {

    private Long flightId;
    private String flightNumber;
    private String source;
    private String destination;
    private LocalDate journeyDate;
    private int totalBookings;
    private int totalPassengers;
    private double totalRevenue;
    /** journeyDate minus today; negative for completed journeys. */
    private long daysUntilJourney;

    public FlightJourneyStats() {
    }

    public Long getFlightId() {
        return flightId;
    }

    public void setFlightId(Long flightId) {
        this.flightId = flightId;
    }

    public String getFlightNumber() {
        return flightNumber;
    }

    public void setFlightNumber(String flightNumber) {
        this.flightNumber = flightNumber;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getDestination() {
        return destination;
    }

    public void setDestination(String destination) {
        this.destination = destination;
    }

    public LocalDate getJourneyDate() {
        return journeyDate;
    }

    public void setJourneyDate(LocalDate journeyDate) {
        this.journeyDate = journeyDate;
    }

    public int getTotalBookings() {
        return totalBookings;
    }

    public void setTotalBookings(int totalBookings) {
        this.totalBookings = totalBookings;
    }

    public int getTotalPassengers() {
        return totalPassengers;
    }

    public void setTotalPassengers(int totalPassengers) {
        this.totalPassengers = totalPassengers;
    }

    public double getTotalRevenue() {
        return totalRevenue;
    }

    public void setTotalRevenue(double totalRevenue) {
        this.totalRevenue = totalRevenue;
    }

    public long getDaysUntilJourney() {
        return daysUntilJourney;
    }

    public void setDaysUntilJourney(long daysUntilJourney) {
        this.daysUntilJourney = daysUntilJourney;
    }
}
