package com.frs.exception;

import jakarta.servlet.http.HttpServletRequest;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.server.ResponseStatusException;

/**
 * Centralized exception handling (@ControllerAdvice) - renders a
 * friendly error page instead of a stack trace.
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(ResponseStatusException.class)
    public String handleResponseStatus(ResponseStatusException ex, Model model) {
        log.warn("Request rejected with {}: {}", ex.getStatusCode(), ex.getReason());
        model.addAttribute("errorTitle", ex.getStatusCode().value() + " - " + ex.getStatusCode());
        model.addAttribute("errorMessage", ex.getReason() != null ? ex.getReason()
                : "You are not allowed to access this page.");
        return "error";
    }

    @ExceptionHandler({IllegalArgumentException.class, IllegalStateException.class, SecurityException.class})
    public String handleAppExceptions(RuntimeException ex, Model model) {
        log.warn("Application error: {}", ex.getMessage());
        model.addAttribute("errorTitle", "Something went wrong");
        model.addAttribute("errorMessage", ex.getMessage());
        return "error";
    }

    @ExceptionHandler(Exception.class)
    public String handleGeneric(Exception ex, HttpServletRequest request, Model model) {
        log.error("Unexpected error while handling {}", request.getRequestURI(), ex);
        model.addAttribute("errorTitle", "Unexpected error");
        model.addAttribute("errorMessage",
                "An unexpected error occurred while processing your request. Please try again.");
        return "error";
    }
}
