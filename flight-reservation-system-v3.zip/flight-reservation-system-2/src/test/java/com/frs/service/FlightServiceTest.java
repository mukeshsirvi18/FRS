package com.frs.service;

import com.frs.dao.BookingDao;
import com.frs.dao.FlightDao;
import com.frs.dao.TicketDao;
import com.frs.model.Flight;
import com.frs.model.dto.FlightForm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class FlightServiceTest {

    @Mock
    private FlightDao flightDao;

    @Mock
    private TicketDao ticketDao;

    @Mock
    private BookingDao bookingDao;

    private FlightService flightService;

    @BeforeEach
    void setUp() {
        flightService = new FlightService(flightDao, ticketDao, bookingDao);
    }

    private FlightForm form(String flightNumber) {
        FlightForm f = new FlightForm();
        f.setFlightNumber(flightNumber);
        f.setSource("DEL");
        f.setDestination("BOM");
        f.setDepartureTime("08:00");
        f.setArrivalTime("10:15");
        f.setCapacity(20);
        f.setPricePerSeat(4500.0);
        return f;
    }

    @Test
    void addFlight_uniqueNumber_savesFlight() {
        when(flightDao.existsByFlightNumber("AI-304")).thenReturn(false);
        when(flightDao.save(any(Flight.class))).thenReturn(7L);
        when(ticketDao.countActiveByFlightId(7L)).thenReturn(0);

        Flight saved = flightService.addFlight(form("AI-304"));

        assertEquals(7L, saved.getFlightId());
        assertEquals("AI-304", saved.getFlightNumber());
        verify(flightDao).save(any(Flight.class));
    }

    @Test
    void addFlight_duplicateNumber_throwsAndSavesNothing() {
        when(flightDao.existsByFlightNumber("AI-304")).thenReturn(true);

        assertThrows(IllegalArgumentException.class,
                () -> flightService.addFlight(form("AI-304")));

        verify(flightDao, never()).save(any(Flight.class));
    }

    @Test
    void getAvailableSeats_subtractsActiveTicketsFromCapacity() {
        Flight flight = new Flight();
        flight.setFlightId(1L);
        flight.setCapacity(20);
        when(flightDao.findById(1L)).thenReturn(java.util.Optional.of(flight));
        when(ticketDao.countActiveByFlightId(1L)).thenReturn(6);

        assertEquals(14, flightService.getAvailableSeats(1L));
    }
}
