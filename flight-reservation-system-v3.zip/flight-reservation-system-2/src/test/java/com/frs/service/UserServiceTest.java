package com.frs.service;

import com.frs.dao.UserDao;
import com.frs.model.User;
import com.frs.model.dto.SignupForm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.security.crypto.password.PasswordEncoder;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class UserServiceTest {

    @Mock
    private UserDao userDao;

    @Mock
    private PasswordEncoder passwordEncoder;

    private UserService userService;

    @BeforeEach
    void setUp() {
        userService = new UserService(userDao, passwordEncoder);
    }

    private SignupForm signupForm(String email) {
        SignupForm form = new SignupForm();
        form.setEmail(email);
        form.setPassword("secret123");
        form.setRole("User");
        return form;
    }

    @Test
    void register_encodesPasswordAndSavesUser() {
        when(userDao.existsByEmail("a@b.com")).thenReturn(false);
        when(passwordEncoder.encode("secret123")).thenReturn("HASHED");
        when(userDao.save(any(User.class))).thenReturn(7L);

        User user = userService.register(signupForm("a@b.com"));

        assertEquals(7L, user.getUserId());
        assertEquals("a@b.com", user.getEmail());
        assertEquals("HASHED", user.getPassword());
        assertEquals("User", user.getRole());

        ArgumentCaptor<User> captor = ArgumentCaptor.forClass(User.class);
        verify(userDao).save(captor.capture());
        assertEquals("HASHED", captor.getValue().getPassword());
    }

    @Test
    void register_duplicateEmail_throws() {
        when(userDao.existsByEmail("a@b.com")).thenReturn(true);

        IllegalArgumentException ex = assertThrows(IllegalArgumentException.class,
                () -> userService.register(signupForm("a@b.com")));
        assertTrue(ex.getMessage().toLowerCase().contains("already registered"));
    }

    @Test
    void authenticate_validCredentials_returnsUser() {
        User stored = new User(1L, "a@b.com", "HASHED", "User");
        when(userDao.findByEmail("a@b.com")).thenReturn(Optional.of(stored));
        when(passwordEncoder.matches("secret123", "HASHED")).thenReturn(true);

        User user = userService.authenticate("a@b.com", "secret123");

        assertEquals(1L, user.getUserId());
    }

    @Test
    void authenticate_unknownEmail_throws() {
        when(userDao.findByEmail(anyString())).thenReturn(Optional.empty());

        assertThrows(IllegalArgumentException.class,
                () -> userService.authenticate("no@b.com", "secret123"));
    }

    @Test
    void authenticate_wrongPassword_throws() {
        User stored = new User(1L, "a@b.com", "HASHED", "User");
        when(userDao.findByEmail("a@b.com")).thenReturn(Optional.of(stored));
        when(passwordEncoder.matches("wrong", "HASHED")).thenReturn(false);

        assertThrows(IllegalArgumentException.class,
                () -> userService.authenticate("a@b.com", "wrong"));
    }
}
