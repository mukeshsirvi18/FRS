package com.frs.service;

import com.frs.dao.BookingDao;
import com.frs.dao.FlightDao;
import com.frs.dao.TicketDao;
import com.frs.model.Booking;
import com.frs.model.Flight;
import com.frs.model.Ticket;
import com.frs.model.dto.PassengerForm;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.ArgumentCaptor;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class BookingServiceTest {

    @Mock
    private BookingDao bookingDao;

    @Mock
    private TicketDao ticketDao;

    @Mock
    private FlightDao flightDao;

    private BookingService bookingService;

    @BeforeEach
    void setUp() {
        bookingService = new BookingService(bookingDao, ticketDao, flightDao);
    }

    private Flight flight(int capacity) {
        Flight f = new Flight();
        f.setFlightId(1L);
        f.setFlightNumber("AI-101");
        f.setCapacity(capacity);
        f.setPricePerSeat(4500.0);
        return f;
    }

    private PassengerForm passenger(String name) {
        PassengerForm p = new PassengerForm();
        p.setPassengerName(name);
        p.setGender("Male");
        p.setAge(30);
        return p;
    }

    @Test
    void createBooking_createsBookingAndOneTicketPerPassenger() {
        when(flightDao.findById(1L)).thenReturn(Optional.of(flight(20)));
        when(ticketDao.countActiveByFlightId(1L)).thenReturn(0);
        when(ticketDao.findActiveSeatNosByFlightId(1L)).thenReturn(Collections.emptyList());
        when(bookingDao.save(any(Booking.class))).thenReturn(10L);

        Booking saved = new Booking();
        saved.setBookingId(10L);
        saved.setSeats(2);
        saved.setTotalPrice(9000.0);
        saved.setStatus(Booking.STATUS_BOOKED);
        saved.setFlightId(1L);
        saved.setUserId(5L);
        when(bookingDao.findById(10L)).thenReturn(Optional.of(saved));
        when(ticketDao.findByBookingId(10L)).thenReturn(new ArrayList<>());

        Booking result = bookingService.createBooking(5L, 1L,
                LocalDate.of(2026, 10, 1), List.of(passenger("Amit"), passenger("Neha")));

        assertEquals(10L, result.getBookingId());

        ArgumentCaptor<Booking> bookingCaptor = ArgumentCaptor.forClass(Booking.class);
        verify(bookingDao).save(bookingCaptor.capture());
        Booking toSave = bookingCaptor.getValue();
        assertEquals(2, toSave.getSeats());
        assertEquals(9000.0, toSave.getTotalPrice());
        assertEquals(Booking.STATUS_BOOKED, toSave.getStatus());
        assertEquals(LocalDate.of(2026, 10, 1), toSave.getTravelDate());

        ArgumentCaptor<Ticket> ticketCaptor = ArgumentCaptor.forClass(Ticket.class);
        verify(ticketDao, times(2)).save(ticketCaptor.capture());
        List<Ticket> tickets = ticketCaptor.getAllValues();
        assertEquals("Amit", tickets.get(0).getPassengerName());
        assertEquals("Neha", tickets.get(1).getPassengerName());
        assertEquals("1", tickets.get(0).getSeatNo());
        assertEquals("2", tickets.get(1).getSeatNo());
        assertEquals(Ticket.STATUS_BOOKED, tickets.get(0).getStatus());
        assertEquals(LocalDate.of(2026, 10, 1), tickets.get(0).getJourneyDate());
    }

    @Test
    void createBooking_notEnoughSeats_throwsAndSavesNothing() {
        when(flightDao.findById(1L)).thenReturn(Optional.of(flight(20)));
        when(ticketDao.countActiveByFlightId(1L)).thenReturn(19); // only 1 left

        List<PassengerForm> passengers = List.of(passenger("Amit"), passenger("Neha"));
        assertThrows(IllegalStateException.class,
                () -> bookingService.createBooking(5L, 1L, LocalDate.of(2026, 10, 1), passengers));

        verify(bookingDao, never()).save(any(Booking.class));
        verify(ticketDao, never()).save(any(Ticket.class));
    }

    @Test
    void cancelBooking_cancelsBookingAndTickets() {
        Booking booking = new Booking();
        booking.setBookingId(10L);
        booking.setUserId(5L);
        booking.setStatus(Booking.STATUS_BOOKED);
        when(bookingDao.findById(10L)).thenReturn(Optional.of(booking));

        bookingService.cancelBooking(10L, 5L);

        verify(ticketDao).updateStatusByBookingId(10L, Ticket.STATUS_CANCELLED);
        verify(bookingDao).updateStatus(10L, Booking.STATUS_CANCELLED);
    }

    @Test
    void cancelBooking_wrongUser_throwsSecurityException() {
        Booking booking = new Booking();
        booking.setBookingId(10L);
        booking.setUserId(5L);
        booking.setStatus(Booking.STATUS_BOOKED);
        when(bookingDao.findById(10L)).thenReturn(Optional.of(booking));

        assertThrows(SecurityException.class, () -> bookingService.cancelBooking(10L, 999L));

        verify(bookingDao, never()).updateStatus(any(), any());
    }

    @Test
    void cancelTicket_lastActiveTicket_cancelsBookingToo() {
        Ticket ticket = new Ticket();
        ticket.setTicketId(100L);
        ticket.setBookingId(10L);
        ticket.setStatus(Ticket.STATUS_BOOKED);
        Booking booking = new Booking();
        booking.setBookingId(10L);
        booking.setUserId(5L);
        booking.setStatus(Booking.STATUS_BOOKED);
        when(ticketDao.findById(100L)).thenReturn(Optional.of(ticket));
        when(bookingDao.findById(10L)).thenReturn(Optional.of(booking));
        when(ticketDao.countActiveByBookingId(10L)).thenReturn(0);

        bookingService.cancelTicket(100L, 5L);

        verify(ticketDao).updateStatus(100L, Ticket.STATUS_CANCELLED);
        verify(bookingDao).updateStatus(10L, Booking.STATUS_CANCELLED);
    }

    @Test
    void cancelTicket_otherTicketsRemain_bookingStaysBooked() {
        Ticket ticket = new Ticket();
        ticket.setTicketId(100L);
        ticket.setBookingId(10L);
        ticket.setStatus(Ticket.STATUS_BOOKED);
        Booking booking = new Booking();
        booking.setBookingId(10L);
        booking.setUserId(5L);
        booking.setStatus(Booking.STATUS_BOOKED);
        when(ticketDao.findById(100L)).thenReturn(Optional.of(ticket));
        when(bookingDao.findById(10L)).thenReturn(Optional.of(booking));
        when(ticketDao.countActiveByBookingId(10L)).thenReturn(2);

        bookingService.cancelTicket(100L, 5L);

        verify(ticketDao).updateStatus(100L, Ticket.STATUS_CANCELLED);
        verify(bookingDao, never()).updateStatus(any(), any());
    }
}
