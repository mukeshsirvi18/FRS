-- CreateTable: User
CREATE TABLE "User" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "plan" TEXT NOT NULL DEFAULT 'free',
    "paddleCustomerId" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "User_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "User_email_key" ON "User"("email");

-- CreateTable: LoginToken
CREATE TABLE "LoginToken" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "usedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "LoginToken_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "LoginToken_tokenHash_key" ON "LoginToken"("tokenHash");

-- CreateTable: Monitor
CREATE TABLE "Monitor" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "uuid" TEXT NOT NULL DEFAULT gen_random_uuid(),
    "scheduleKind" TEXT NOT NULL,
    "intervalSeconds" INTEGER,
    "cronExpr" TEXT,
    "timezone" TEXT NOT NULL DEFAULT 'UTC',
    "graceSeconds" INTEGER NOT NULL DEFAULT 300,
    "status" TEXT NOT NULL DEFAULT 'up',
    "lastPingAt" TIMESTAMP(3),
    "nextExpectedAt" TIMESTAMP(3),
    "pendingStartAt" TIMESTAMP(3),
    "lastDurationMs" INTEGER,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Monitor_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "Monitor_uuid_key" ON "Monitor"("uuid");
CREATE INDEX "Monitor_status_nextExpectedAt_idx" ON "Monitor"("status", "nextExpectedAt");

-- CreateTable: Ping
CREATE TABLE "Ping" (
    "id" TEXT NOT NULL,
    "monitorId" TEXT NOT NULL,
    "kind" TEXT NOT NULL,
    "receivedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "durationMs" INTEGER,
    "meta" JSONB,
    CONSTRAINT "Ping_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "Ping_monitorId_receivedAt_idx" ON "Ping"("monitorId", "receivedAt");

-- CreateTable: Alert
CREATE TABLE "Alert" (
    "id" TEXT NOT NULL,
    "monitorId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "channel" TEXT NOT NULL,
    "sentAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "ok" BOOLEAN NOT NULL DEFAULT true,
    CONSTRAINT "Alert_pkey" PRIMARY KEY ("id")
);

-- CreateTable: Integration
CREATE TABLE "Integration" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "name" TEXT,
    "config" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "Integration_pkey" PRIMARY KEY ("id")
);

-- CreateTable: DailyStat
CREATE TABLE "DailyStat" (
    "id" TEXT NOT NULL,
    "monitorId" TEXT NOT NULL,
    "date" DATE NOT NULL,
    "upCount" INTEGER NOT NULL DEFAULT 0,
    "downCount" INTEGER NOT NULL DEFAULT 0,
    "avgDurationMs" INTEGER,
    CONSTRAINT "DailyStat_pkey" PRIMARY KEY ("id")
);
CREATE UNIQUE INDEX "DailyStat_monitorId_date_key" ON "DailyStat"("monitorId", "date");

-- Foreign keys
ALTER TABLE "LoginToken" ADD CONSTRAINT "LoginToken_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Monitor" ADD CONSTRAINT "Monitor_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Ping" ADD CONSTRAINT "Ping_monitorId_fkey"
    FOREIGN KEY ("monitorId") REFERENCES "Monitor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Alert" ADD CONSTRAINT "Alert_monitorId_fkey"
    FOREIGN KEY ("monitorId") REFERENCES "Monitor"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "Integration" ADD CONSTRAINT "Integration_userId_fkey"
    FOREIGN KEY ("userId") REFERENCES "User"("id") ON DELETE CASCADE ON UPDATE CASCADE;
