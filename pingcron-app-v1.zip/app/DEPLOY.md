# Pingcron deploy

## Rasta 1 (filhaal): AWS Free Tier — 12 mahine ₹0

**Kya milega free:** EC2 `t3.micro` (2 vCPU, 1GB RAM) 750 hrs/month + 30GB disk + ~100GB/month data transfer. Ek instance mahine bhar chalega = poora free.

**Pehle ye samajh lo (kadvi baatein):**
- Card lagega account banane me (verification ke liye ~₹2 ka temp charge, wapas ho jata hai).
- Free sirf **12 mahine**. 13th month se ~$15-18/mo. Isliye **billing alarm pehle din lagana** — neeche step hai.
- Elastic IP free hai **jab tak running instance se attached hai**. Instance delete karke IP chhod diya toh ~$3.65/mo katne lagega.

### Tumhare steps (AWS console me, ~15 min)

1. AWS account banao (card verification ke saath), region **ap-south-1 (Mumbai)** select karo.
2. EC2 → Launch instance:
   - Name: `pingcron`, AMI: **Ubuntu 24.04**, Instance type: **t3.micro**
   - Key pair: naya banao (`.pem` download karke sambhal ke rakho)
   - Security group: naya — `22` (SSH, Source: My IP), `80` aur `443` (Source: Anywhere)
   - Storage: 30GB gp3 (default)
3. Elastic IP allocate karke instance se associate karo.
4. **Billing alarm (sabse zaroori):** region switch karke **us-east-1** jao → CloudWatch → Billing alarms → naya alarm: threshold **$1**, apne email pe notification.

### VPS pe (SSH ke baad, single copy-paste block)

```bash
# 1. Swap (1GB RAM pe Docker ke liye zaroori) + Docker + Caddy
sudo fallocate -l 2G /swapfile && sudo chmod 600 /swapfile && sudo mkswap /swapfile && sudo swapon /swapfile
echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
sudo apt-get update && sudo apt-get install -y docker.io docker-compose-plugin caddy

# 2. Code lao
mkdir -p ~/pingcron && cd ~/pingcron
git clone <tumhara-repo-url> app   # ya zip upload karke unzip karo
cd app

# 3. Env banao (.env.example se copy karke secrets bharo)
cp .env.example .env
nano .env   # SESSION_SECRET, CRON_SECRET, APP_URL=https://pingcron.com, POSTGRES_PASSWORD bharo

# 4. Chalao (pehli baar image build hogi, 3-4 min lagega)
docker compose up -d --build

# 5. Caddy (auto HTTPS) — /etc/caddy/Caddyfile me:
#    pingcron.com {
#        reverse_proxy localhost:3000
#    }
sudo systemctl reload caddy
```

> 1GB RAM pe Postgres halka rakhne ke liye `docker-compose.yml` ke `db` service me ye line jod do:
> `command: postgres -c shared_buffers=128MB -c effective_cache_size=512MB -c max_connections=50`

## Rasta 2 (12 mahine baad, ya jab mann kare): Hetzner CX22 — ~€5/mo hamesha

Wahi steps, bas Hetzner Cloud me CX22 VPS (Ubuntu 24.04) banao. Swap ki zaroorat nahi (2GB RAM hai), baaki sab same.

## Baaki accounts (ek-ek karke, jab time mile)

- **Domain** (jaise pingcron.com) → DNS me A record VPS ke Elastic IP pe. Bina domain ke Caddy HTTPS nahi dega.
- **Resend** — magic-link emails ke liye; domain verify karni hogi. Jab tak nahi hai, login link server ke console me print hoga (testing ke liye kaafi).
- **Paddle** — billing ke liye, Week 3 me lagega. Pehle se bana lo toh achha, approval me time lagta hai.

## Minute-checker (missed-ping detection)

VPS ke system cron me ek line — yeh har minute `/api/internal/check` hit karega:

```bash
crontab -e
# phir yeh line jodo (CRON_SECRET wahi jo .env me hai):
* * * * * curl -sf -X POST -H "Authorization: Bearer CHANGE-ME-CRON-SECRET" https://pingcron.com/api/internal/check
```

## Backup (roz raat ko)

```bash
crontab -e
# roz 3 baje DB dump → /var/backups (wahan se Backblaze B2 / Hetzner Storage Box pe sync karo)
0 3 * * * docker exec pingcron-app-db-1 pg_dump -U pingcron pingcron | gzip > /var/backups/pingcron-$(date +\%F).sql.gz
```

Restore test har mahine ek baar zaroor karna — bina test ke backup bekaar hai.

## Deploy (code update)

```bash
cd ~/pingcron/app && git pull && docker compose up -d --build
```

## Khud ki nigrani (dogfooding)

UptimeRobot (free) me do checks lagao:
1. `https://pingcron.com/p/<tumhara-self-monitor-uuid>` — humein khud monitor karo
2. `https://pingcron.com/api/me` — app zinda hai ya nahi
