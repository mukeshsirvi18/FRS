import { Resend } from "resend";
import type { Monitor, User } from "@prisma/client";

/**
 * All outbound notifications. Email goes via Resend when configured;
 * otherwise everything is logged to console (dev mode).
 */

let resend: Resend | null = null;
function getResend(): Resend | null {
  const key = process.env.RESEND_API_KEY;
  if (!key) return null;
  if (!resend) resend = new Resend(key);
  return resend;
}

export async function sendLoginEmail(to: string, link: string): Promise<void> {
  const client = getResend();
  if (!client) {
    console.log(`[dev] magic login link for ${to}: ${link}`);
    return;
  }
  await client.emails.send({
    from: process.env.EMAIL_FROM ?? "Pingcron <login@pingcron.com>",
    to,
    subject: "Your Pingcron login link",
    html: `<p>Click to log in to Pingcron (expires in 15 minutes):</p><p><a href="${link}">${link}</a></p>`,
  });
}

function downEmailHtml(monitor: Monitor, appUrl: string): string {
  return `<p><strong>${escapeHtml(monitor.name)}</strong> missed its expected ping and is <strong>DOWN</strong>.</p>
<p>Last ping: ${monitor.lastPingAt ? monitor.lastPingAt.toISOString() : "never"}</p>
<p><a href="${appUrl}">Open Pingcron dashboard</a></p>`;
}

function escapeHtml(s: string): string {
  return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]!));
}

async function sendEmailAlert(user: User, subject: string, html: string): Promise<boolean> {
  const client = getResend();
  if (!client) {
    console.log(`[dev] email alert to ${user.email}: ${subject}`);
    return true;
  }
  try {
    await client.emails.send({
      from: process.env.EMAIL_FROM ?? "Pingcron <alerts@pingcron.com>",
      to: user.email,
      subject,
      html,
    });
    return true;
  } catch (err) {
    console.error("email alert failed", err);
    return false;
  }
}

async function postWebhook(url: string, text: string): Promise<boolean> {
  try {
    const res = await fetch(url, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text }),
      signal: AbortSignal.timeout(8000),
    });
    return res.ok;
  } catch (err) {
    console.error("webhook alert failed", err);
    return false;
  }
}

export type AlertChannel = "email" | "slack" | "discord";

/** Send a DOWN alert on all of the user's channels. Returns per-channel success. */
export async function dispatchDownAlert(
  user: User,
  monitor: Monitor,
  integrations: { type: string; config: unknown }[]
): Promise<{ channel: AlertChannel; ok: boolean }[]> {
  const appUrl = process.env.APP_URL ?? "";
  const text = `🔴 DOWN: ${monitor.name} missed its expected ping.`;
  const results: { channel: AlertChannel; ok: boolean }[] = [];

  results.push({
    channel: "email",
    ok: await sendEmailAlert(user, `🔴 ${monitor.name} is DOWN`, downEmailHtml(monitor, appUrl)),
  });

  for (const integ of integrations) {
    const url = (integ.config as { webhookUrl?: string } | null)?.webhookUrl;
    if (!url) continue;
    if (integ.type === "slack" || integ.type === "discord") {
      results.push({ channel: integ.type, ok: await postWebhook(url, text) });
    }
  }
  return results;
}

/** Send a RECOVERED notice on all of the user's channels. */
export async function dispatchRecoveredAlert(
  user: User,
  monitor: Monitor,
  integrations: { type: string; config: unknown }[]
): Promise<{ channel: AlertChannel; ok: boolean }[]> {
  const text = `🟢 RECOVERED: ${monitor.name} is pinging again.`;
  const results: { channel: AlertChannel; ok: boolean }[] = [];

  results.push({
    channel: "email",
    ok: await sendEmailAlert(
      user,
      `🟢 ${monitor.name} recovered`,
      `<p><strong>${escapeHtml(monitor.name)}</strong> is pinging again.</p>`
    ),
  });

  for (const integ of integrations) {
    const url = (integ.config as { webhookUrl?: string } | null)?.webhookUrl;
    if (!url) continue;
    if (integ.type === "slack" || integ.type === "discord") {
      results.push({ channel: integ.type, ok: await postWebhook(url, text) });
    }
  }
  return results;
}
