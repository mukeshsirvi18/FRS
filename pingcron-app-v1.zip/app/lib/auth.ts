import { createHash, randomBytes } from "crypto";
import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";
import { db } from "./db";
import { sendLoginEmail } from "./alerts";

const SESSION_COOKIE = "pc_session";
const SESSION_DAYS = 30;

function sessionSecret(): Uint8Array {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 32) {
    throw new Error("SESSION_SECRET must be set (>= 32 chars)");
  }
  return new TextEncoder().encode(s);
}

function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/** Step 1: user submits email → we create a one-time login token. */
export async function requestMagicLink(email: string): Promise<void> {
  const normalized = email.trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(normalized)) {
    throw new Error("Invalid email address");
  }

  const user = await db.user.upsert({
    where: { email: normalized },
    update: {},
    create: { email: normalized },
  });

  const token = randomBytes(32).toString("hex");
  await db.loginToken.create({
    data: {
      userId: user.id,
      tokenHash: hashToken(token),
      expiresAt: new Date(Date.now() + 15 * 60 * 1000), // 15 min
    },
  });

  const link = `${process.env.APP_URL}/api/auth/verify?token=${token}`;
  await sendLoginEmail(normalized, link);
}

/** Step 2: user clicks link → verify token, return user id. One-time use. */
export async function verifyMagicLink(token: string): Promise<string> {
  const record = await db.loginToken.findUnique({
    where: { tokenHash: hashToken(token) },
  });
  if (!record || record.usedAt || record.expiresAt < new Date()) {
    throw new Error("This login link is invalid or expired");
  }
  await db.loginToken.update({
    where: { id: record.id },
    data: { usedAt: new Date() },
  });
  return record.userId;
}

export async function createSession(userId: string): Promise<string> {
  return new SignJWT({ sub: userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(`${SESSION_DAYS}d`)
    .sign(sessionSecret());
}

export async function setSessionCookie(jwt: string): Promise<void> {
  const store = await cookies();
  store.set(SESSION_COOKIE, jwt, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    path: "/",
    maxAge: SESSION_DAYS * 24 * 3600,
  });
}

export async function clearSessionCookie(): Promise<void> {
  const store = await cookies();
  store.delete(SESSION_COOKIE);
}

/** Returns the logged-in user, or null. */
export async function getSessionUser() {
  const store = await cookies();
  const raw = store.get(SESSION_COOKIE)?.value;
  if (!raw) return null;
  try {
    const { payload } = await jwtVerify(raw, sessionSecret());
    const userId = payload.sub;
    if (typeof userId !== "string") return null;
    return db.user.findUnique({ where: { id: userId } });
  } catch {
    return null;
  }
}
