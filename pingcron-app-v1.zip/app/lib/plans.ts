export const PLAN_LIMITS: Record<string, number> = {
  free: 5,
  pro: 50,
  team: 200,
};

export function monitorLimitForPlan(plan: string): number {
  return PLAN_LIMITS[plan] ?? PLAN_LIMITS.free;
}
