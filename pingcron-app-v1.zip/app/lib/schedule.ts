import { CronExpressionParser } from "cron-parser";

/**
 * Pure scheduling logic — no DB, no I/O. Unit-testable.
 */

export type ScheduleOpts =
  | { kind: "interval"; intervalSeconds: number }
  | { kind: "cron"; cronExpr: string; timezone?: string };

/** Next time a ping is expected, given a reference point. */
export function nextExpectedAfter(opts: ScheduleOpts, from: Date): Date {
  if (opts.kind === "interval") {
    if (!Number.isFinite(opts.intervalSeconds) || opts.intervalSeconds < 60) {
      throw new Error("intervalSeconds must be >= 60");
    }
    return new Date(from.getTime() + opts.intervalSeconds * 1000);
  }
  const parsed = CronExpressionParser.parse(opts.cronExpr, {
    currentDate: from,
    tz: opts.timezone ?? "UTC",
  });
  return parsed.next().toDate();
}

/** True when a monitor has missed its expected ping (grace period elapsed). */
export function isOverdue(
  nextExpectedAt: Date | null,
  graceSeconds: number,
  now: Date = new Date()
): boolean {
  if (!nextExpectedAt) return false; // never pinged yet — not overdue
  return now.getTime() > nextExpectedAt.getTime() + graceSeconds * 1000;
}

/** Validate a cron expression without throwing to callers. */
export function isValidCron(expr: string): boolean {
  try {
    CronExpressionParser.parse(expr);
    return true;
  } catch {
    return false;
  }
}

/** Human summary, e.g. "every 5m" / "cron 0 * * * *". */
export function describeSchedule(opts: ScheduleOpts): string {
  if (opts.kind === "interval") {
    const s = opts.intervalSeconds;
    if (s % 3600 === 0) return `every ${s / 3600}h`;
    if (s % 60 === 0) return `every ${s / 60}m`;
    return `every ${s}s`;
  }
  return `cron ${opts.cronExpr}`;
}
