// Unit tests for lib/schedule.ts (pure functions, no DB).
// Run: node --experimental-strip-types --test lib/schedule.test.ts  (after npm install)
import { describe, it } from "node:test";
import assert from "node:assert/strict";
import { nextExpectedAfter, isOverdue, isValidCron, describeSchedule } from "./schedule.ts";

describe("nextExpectedAfter", () => {
  it("interval: adds seconds", () => {
    const from = new Date("2026-10-01T00:00:00Z");
    const next = nextExpectedAfter({ kind: "interval", intervalSeconds: 300 }, from);
    assert.equal(next.toISOString(), "2026-10-01T00:05:00.000Z");
  });

  it("interval: rejects < 60s", () => {
    assert.throws(() => nextExpectedAfter({ kind: "interval", intervalSeconds: 30 }, new Date()));
  });

  it("cron: next occurrence", () => {
    const from = new Date("2026-10-01T00:00:00Z");
    const next = nextExpectedAfter({ kind: "cron", cronExpr: "0 * * * *" }, from);
    assert.equal(next.toISOString(), "2026-10-01T01:00:00.000Z");
  });
});

describe("isOverdue", () => {
  it("false when never pinged", () => {
    assert.equal(isOverdue(null, 300, new Date()), false);
  });

  it("false inside grace", () => {
    const expected = new Date("2026-10-01T00:00:00Z");
    const now = new Date("2026-10-01T00:04:00Z"); // grace 300s, 4 min elapsed
    assert.equal(isOverdue(expected, 300, now), false);
  });

  it("true past grace", () => {
    const expected = new Date("2026-10-01T00:00:00Z");
    const now = new Date("2026-10-01T00:06:00Z");
    assert.equal(isOverdue(expected, 300, now), true);
  });
});

describe("isValidCron", () => {
  it("accepts valid, rejects junk", () => {
    assert.equal(isValidCron("*/5 * * * *"), true);
    assert.equal(isValidCron("not a cron"), false);
  });
});

describe("describeSchedule", () => {
  it("formats intervals", () => {
    assert.equal(describeSchedule({ kind: "interval", intervalSeconds: 3600 }), "every 1h");
    assert.equal(describeSchedule({ kind: "interval", intervalSeconds: 300 }), "every 5m");
  });
});
