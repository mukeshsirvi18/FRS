import { db } from "./db";
import { isOverdue } from "./schedule";
import { dispatchDownAlert } from "./alerts";

/**
 * Minute-checker: find monitors that missed their expected ping and mark them DOWN.
 * Triggered by system cron hitting POST /api/internal/check (Bearer CRON_SECRET).
 * Dedupe: only monitors currently "up" are flipped, so one outage = one alert.
 */
export async function runDownCheck(now: Date = new Date()): Promise<{ checked: number; downed: number }> {
  const candidates = await db.monitor.findMany({
    where: { status: "up", nextExpectedAt: { not: null } },
    include: { user: { include: { integrations: true } } },
  });

  let downed = 0;
  for (const m of candidates) {
    if (!isOverdue(m.nextExpectedAt, m.graceSeconds, now)) continue;
    await db.monitor.update({ where: { id: m.id }, data: { status: "down" } });
    const results = await dispatchDownAlert(m.user, m, m.user.integrations);
    await db.alert.createMany({
      data: results.map((r) => ({ monitorId: m.id, type: "down", channel: r.channel, ok: r.ok })),
    });
    downed++;
  }
  return { checked: candidates.length, downed };
}
