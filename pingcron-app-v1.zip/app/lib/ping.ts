import { db } from "./db";
import { nextExpectedAfter, type ScheduleOpts } from "./schedule";
import { dispatchDownAlert, dispatchRecoveredAlert } from "./alerts";

export type PingKind = "success" | "fail" | "start";

function scheduleOptsOf(m: {
  scheduleKind: string;
  intervalSeconds: number | null;
  cronExpr: string | null;
  timezone: string;
}): ScheduleOpts {
  if (m.scheduleKind === "cron") {
    if (!m.cronExpr) throw new Error("cron monitor missing expression");
    return { kind: "cron", cronExpr: m.cronExpr, timezone: m.timezone };
  }
  if (!m.intervalSeconds) throw new Error("interval monitor missing seconds");
  return { kind: "interval", intervalSeconds: m.intervalSeconds };
}

/**
 * Handle an incoming ping. Returns a short status string for the response.
 * - success: record ping, update nextExpectedAt; if monitor was down → recovered alert
 * - fail:    record ping, mark down immediately + down alert
 * - start:   remember start time so the next success ping gets a duration
 */
export async function handlePing(uuid: string, kind: PingKind): Promise<string> {
  const now = new Date();
  const monitor = await db.monitor.findUnique({
    where: { uuid },
    include: { user: { include: { integrations: true } } },
  });
  if (!monitor) return "unknown-monitor";
  if (monitor.status === "paused") return "paused";

  if (kind === "start") {
    await db.monitor.update({
      where: { id: monitor.id },
      data: { pendingStartAt: now },
    });
    await db.ping.create({ data: { monitorId: monitor.id, kind } });
    return "ok";
  }

  const durationMs =
    kind === "success" && monitor.pendingStartAt
      ? Math.max(0, now.getTime() - monitor.pendingStartAt.getTime())
      : null;

  const nextExpected = nextExpectedAfter(scheduleOptsOf(monitor), now);
  const wasDown = monitor.status === "down";

  await db.$transaction([
    db.ping.create({
      data: { monitorId: monitor.id, kind, durationMs },
    }),
    db.monitor.update({
      where: { id: monitor.id },
      data: {
        lastPingAt: now,
        nextExpectedAt: nextExpected,
        pendingStartAt: null,
        lastDurationMs: durationMs,
        status: "up",
      },
    }),
  ]);

  if (kind === "fail" || wasDown) {
    const fresh = await db.monitor.findUnique({ where: { id: monitor.id } });
    if (kind === "fail") {
      await db.monitor.update({ where: { id: monitor.id }, data: { status: "down" } });
      if (!wasDown) {
        // dedup: only alert on the up -> down transition
        const results = await dispatchDownAlert(monitor.user, fresh ?? monitor, monitor.user.integrations);
        await db.alert.createMany({
          data: results.map((r) => ({ monitorId: monitor.id, type: "down", channel: r.channel, ok: r.ok })),
        });
      }
      return "fail-recorded";
    }
    // was down, now recovered
    const results = await dispatchRecoveredAlert(monitor.user, fresh ?? monitor, monitor.user.integrations);
    await db.alert.createMany({
      data: results.map((r) => ({ monitorId: monitor.id, type: "recovered", channel: r.channel, ok: r.ok })),
    });
    return "recovered";
  }

  return "ok";
}
