"use client";

import { useCallback, useEffect, useState } from "react";

type Monitor = {
  id: string;
  name: string;
  uuid: string;
  schedule: string;
  scheduleKind: string;
  graceSeconds: number;
  status: "up" | "down" | "paused";
  lastPingAt: string | null;
  nextExpectedAt: string | null;
  lastDurationMs: number | null;
  pingUrl: string;
};

function StatusDot({ status }: { status: Monitor["status"] }) {
  const color =
    status === "up" ? "bg-green-500" : status === "down" ? "bg-red-500" : "bg-gray-400";
  return <span className={`inline-block h-3 w-3 rounded-full ${color}`} title={status} />;
}

function timeAgo(iso: string | null): string {
  if (!iso) return "never";
  const s = Math.floor((Date.now() - new Date(iso).getTime()) / 1000);
  if (s < 60) return `${s}s ago`;
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}

export default function Home() {
  const [me, setMe] = useState<{ email: string; plan: string } | null | undefined>(undefined);
  const [email, setEmail] = useState("");
  const [loginSent, setLoginSent] = useState(false);
  const [loginError, setLoginError] = useState("");
  const [monitors, setMonitors] = useState<Monitor[]>([]);
  const [limit, setLimit] = useState(5);
  const [error, setError] = useState("");

  // create form
  const [name, setName] = useState("");
  const [kind, setKind] = useState<"interval" | "cron">("interval");
  const [intervalMin, setIntervalMin] = useState("60");
  const [cronExpr, setCronExpr] = useState("0 * * * *");

  const load = useCallback(async () => {
    const meRes = await fetch("/api/me");
    if (!meRes.ok) {
      setMe(null);
      return;
    }
    const { user } = await meRes.json();
    setMe(user);
    const mRes = await fetch("/api/monitors");
    if (mRes.ok) {
      const data = await mRes.json();
      setMonitors(data.monitors);
      setLimit(data.limit);
    }
  }, []);

  useEffect(() => {
    load();
    const t = setInterval(load, 30000);
    return () => clearInterval(t);
  }, [load]);

  async function doLogin(e: React.FormEvent) {
    e.preventDefault();
    setLoginError("");
    const res = await fetch("/api/auth/request", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email }),
    });
    if (res.ok) setLoginSent(true);
    else setLoginError((await res.json()).error ?? "Something went wrong");
  }

  async function createMonitor(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    const res = await fetch("/api/monitors", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        name,
        scheduleKind: kind,
        intervalSeconds: kind === "interval" ? Number(intervalMin) * 60 : undefined,
        cronExpr: kind === "cron" ? cronExpr : undefined,
      }),
    });
    if (res.ok) {
      setName("");
      load();
    } else {
      setError((await res.json()).error ?? "Failed to create monitor");
    }
  }

  async function togglePause(m: Monitor) {
    await fetch(`/api/monitors/${m.id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ paused: m.status !== "paused" }),
    });
    load();
  }

  async function removeMonitor(m: Monitor) {
    if (!confirm(`Delete monitor "${m.name}"?`)) return;
    await fetch(`/api/monitors/${m.id}`, { method: "DELETE" });
    load();
  }

  async function logout() {
    await fetch("/api/auth/logout", { method: "POST" });
    setMe(null);
  }

  function copy(text: string) {
    navigator.clipboard.writeText(text);
  }

  if (me === undefined) {
    return <main className="mx-auto max-w-2xl p-8"><p>Loading…</p></main>;
  }

  if (me === null) {
    return (
      <main className="mx-auto max-w-md p-8">
        <h1 className="text-3xl font-bold">Pingcron</h1>
        <p className="mt-2 text-gray-600">Cron monitoring for developers who hate surprises.</p>
        {loginSent ? (
          <p className="mt-6 rounded bg-green-50 p-4 text-green-800">
            Check your email for a login link (expires in 15 min).
          </p>
        ) : (
          <form onSubmit={doLogin} className="mt-6 space-y-3">
            <input
              type="email" required value={email} onChange={(e) => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded border px-3 py-2"
            />
            {loginError && <p className="text-sm text-red-600">{loginError}</p>}
            <button className="w-full rounded bg-black px-4 py-2 text-white">Send login link</button>
          </form>
        )}
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-4xl p-8">
      <header className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Pingcron</h1>
        <div className="flex items-center gap-3 text-sm text-gray-600">
          <span>{me.email} · {me.plan}</span>
          <button onClick={logout} className="underline">logout</button>
        </div>
      </header>

      <section className="mt-8 rounded border p-4">
        <h2 className="font-semibold">New monitor ({monitors.length}/{limit})</h2>
        <form onSubmit={createMonitor} className="mt-3 flex flex-wrap items-end gap-3">
          <input
            value={name} onChange={(e) => setName(e.target.value)} required maxLength={120}
            placeholder="nightly-backup" className="rounded border px-3 py-2"
          />
          <select value={kind} onChange={(e) => setKind(e.target.value as "interval" | "cron")}
            className="rounded border px-3 py-2">
            <option value="interval">every X min</option>
            <option value="cron">cron expr</option>
          </select>
          {kind === "interval" ? (
            <input value={intervalMin} onChange={(e) => setIntervalMin(e.target.value)}
              type="number" min={1} className="w-24 rounded border px-3 py-2" placeholder="60" />
          ) : (
            <input value={cronExpr} onChange={(e) => setCronExpr(e.target.value)}
              className="rounded border px-3 py-2 font-mono" placeholder="0 * * * *" />
          )}
          <button className="rounded bg-black px-4 py-2 text-white">Create</button>
        </form>
        {error && <p className="mt-2 text-sm text-red-600">{error}</p>}
      </section>

      <section className="mt-6 space-y-3">
        {monitors.length === 0 && <p className="text-gray-500">No monitors yet. Create one above.</p>}
        {monitors.map((m) => (
          <div key={m.id} className="rounded border p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <StatusDot status={m.status} />
                <span className="font-semibold">{m.name}</span>
                <span className="text-sm text-gray-500">{m.schedule} · {m.status}</span>
              </div>
              <div className="flex gap-2 text-sm">
                <button onClick={() => togglePause(m)} className="underline">
                  {m.status === "paused" ? "resume" : "pause"}
                </button>
                <button onClick={() => removeMonitor(m)} className="text-red-600 underline">delete</button>
              </div>
            </div>
            <div className="mt-2 flex items-center gap-2">
              <code className="flex-1 truncate rounded bg-gray-100 px-2 py-1 font-mono text-xs">{m.pingUrl}</code>
              <button onClick={() => copy(m.pingUrl)} className="rounded border px-2 py-1 text-xs">copy</button>
            </div>
            <p className="mt-1 text-xs text-gray-500">
              last ping {timeAgo(m.lastPingAt)}
              {m.lastDurationMs != null && ` · took ${(m.lastDurationMs / 1000).toFixed(1)}s`}
            </p>
            <details className="mt-2 text-xs">
              <summary className="cursor-pointer text-gray-600">how to use</summary>
              <pre className="mt-1 overflow-x-auto rounded bg-gray-900 p-2 text-gray-100">{`# at the end of your cron job:
curl -m 10 ${m.pingUrl}

# on failure, ping:
${m.pingUrl}/fail

# to track duration, ping at job start:
${m.pingUrl}/start`}</pre>
            </details>
          </div>
        ))}
      </section>
    </main>
  );
}
