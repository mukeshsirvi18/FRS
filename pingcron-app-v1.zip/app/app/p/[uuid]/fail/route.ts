import { handlePing } from "@/lib/ping";

// GET /p/<uuid>/fail — job failed. Marks monitor DOWN immediately.
export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ uuid: string }> }
) {
  const { uuid } = await params;
  const status = await handlePing(uuid, "fail");
  if (status === "unknown-monitor") {
    return new Response("unknown monitor", { status: 404 });
  }
  return new Response(status, { status: 200 });
}
