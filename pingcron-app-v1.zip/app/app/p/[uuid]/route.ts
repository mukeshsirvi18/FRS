import { handlePing } from "@/lib/ping";

// GET /p/<uuid> — job succeeded. Also accepts HEAD for cheap checks.
export const dynamic = "force-dynamic";

export async function GET(
  _request: Request,
  { params }: { params: Promise<{ uuid: string }> }
) {
  const { uuid } = await params;
  const status = await handlePing(uuid, "success");
  if (status === "unknown-monitor") {
    return new Response("unknown monitor", { status: 404 });
  }
  return new Response(status, { status: 200 });
}

export async function HEAD(
  _request: Request,
  { params }: { params: Promise<{ uuid: string }> }
) {
  const { uuid } = await params;
  const status = await handlePing(uuid, "success");
  return new Response(null, { status: status === "unknown-monitor" ? 404 : 200 });
}
