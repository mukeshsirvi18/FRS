import { NextRequest } from "next/server";
import { verifyMagicLink, createSession, setSessionCookie } from "@/lib/auth";

export async function GET(request: NextRequest) {
  const token = request.nextUrl.searchParams.get("token");
  const appUrl = process.env.APP_URL ?? "/";
  if (!token) return Response.redirect(`${appUrl}/?error=missing-token`);
  try {
    const userId = await verifyMagicLink(token);
    await setSessionCookie(await createSession(userId));
    return Response.redirect(`${appUrl}/`);
  } catch {
    return Response.redirect(`${appUrl}/?error=bad-token`);
  }
}
