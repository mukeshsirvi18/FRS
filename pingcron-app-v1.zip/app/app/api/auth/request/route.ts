import { requestMagicLink } from "@/lib/auth";

export async function POST(request: Request) {
  try {
    const { email } = (await request.json()) as { email?: string };
    if (!email) return Response.json({ error: "Email required" }, { status: 400 });
    await requestMagicLink(email);
    // Always say "sent" — don't leak which emails exist.
    return Response.json({ ok: true });
  } catch (err) {
    return Response.json({ error: (err as Error).message }, { status: 400 });
  }
}
