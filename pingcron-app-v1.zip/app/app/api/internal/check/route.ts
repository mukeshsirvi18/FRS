import { runDownCheck } from "@/lib/checker";

/**
 * Minute-checker entrypoint. Called by system cron on the VPS:
 *   * * * * * curl -sf -X POST -H "Authorization: Bearer $CRON_SECRET" https://APP_URL/api/internal/check
 */
export async function POST(request: Request) {
  const auth = request.headers.get("authorization") ?? "";
  if (auth !== `Bearer ${process.env.CRON_SECRET}`) {
    return Response.json({ error: "Forbidden" }, { status: 403 });
  }
  const result = await runDownCheck();
  return Response.json({ ok: true, ...result });
}
