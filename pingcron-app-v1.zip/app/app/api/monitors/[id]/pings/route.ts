import { NextRequest } from "next/server";
import { getSessionUser } from "@/lib/auth";
import { db } from "@/lib/db";

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;

  const monitor = await db.monitor.findFirst({ where: { id, userId: user.id } });
  if (!monitor) return Response.json({ error: "Not found" }, { status: 404 });

  const limit = Math.min(100, Math.max(1, Number(request.nextUrl.searchParams.get("limit")) || 20));
  const pings = await db.ping.findMany({
    where: { monitorId: id },
    orderBy: { receivedAt: "desc" },
    take: limit,
    select: { id: true, kind: true, receivedAt: true, durationMs: true },
  });
  return Response.json({ pings });
}
