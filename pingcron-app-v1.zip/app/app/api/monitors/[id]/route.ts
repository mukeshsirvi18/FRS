import { getSessionUser } from "@/lib/auth";
import { db } from "@/lib/db";

async function owned(id: string, userId: string) {
  return db.monitor.findFirst({ where: { id, userId } });
}

export async function PATCH(
  request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;

  const monitor = await owned(id, user.id);
  if (!monitor) return Response.json({ error: "Not found" }, { status: 404 });

  const body = (await request.json()) as { name?: string; paused?: boolean };
  const data: { name?: string; status?: string } = {};
  if (typeof body.name === "string" && body.name.trim()) {
    data.name = body.name.trim().slice(0, 120);
  }
  if (typeof body.paused === "boolean") {
    data.status = body.paused ? "paused" : "up";
  }
  const updated = await db.monitor.update({ where: { id }, data });
  return Response.json({ monitor: updated });
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });
  const { id } = await params;

  const monitor = await owned(id, user.id);
  if (!monitor) return Response.json({ error: "Not found" }, { status: 404 });

  await db.monitor.delete({ where: { id } });
  return Response.json({ ok: true });
}
