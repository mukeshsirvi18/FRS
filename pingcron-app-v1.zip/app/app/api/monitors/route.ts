import { getSessionUser } from "@/lib/auth";
import { db } from "@/lib/db";
import { monitorLimitForPlan } from "@/lib/plans";
import { isValidCron, describeSchedule } from "@/lib/schedule";

export async function GET() {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const monitors = await db.monitor.findMany({
    where: { userId: user.id },
    orderBy: { createdAt: "desc" },
    select: {
      id: true, name: true, uuid: true, scheduleKind: true,
      intervalSeconds: true, cronExpr: true, graceSeconds: true,
      status: true, lastPingAt: true, nextExpectedAt: true,
      lastDurationMs: true, createdAt: true,
    },
  });
  const appUrl = process.env.APP_URL ?? "";
  type MonitorRow = {
    id: string;
    name: string;
    uuid: string;
    scheduleKind: string;
    intervalSeconds: number | null;
    cronExpr: string | null;
    graceSeconds: number;
    status: string;
    lastPingAt: Date | null;
    nextExpectedAt: Date | null;
    lastDurationMs: number | null;
    createdAt: Date;
  };
  return Response.json({
    monitors: (monitors as MonitorRow[]).map((m) => ({
      ...m,
      schedule: describeSchedule(
        m.scheduleKind === "cron"
          ? { kind: "cron", cronExpr: m.cronExpr ?? "" }
          : { kind: "interval", intervalSeconds: m.intervalSeconds ?? 0 }
      ),
      pingUrl: `${appUrl}/p/${m.uuid}`,
    })),
    limit: monitorLimitForPlan(user.plan),
  });
}

export async function POST(request: Request) {
  const user = await getSessionUser();
  if (!user) return Response.json({ error: "Unauthorized" }, { status: 401 });

  const body = (await request.json()) as {
    name?: string;
    scheduleKind?: string;
    intervalSeconds?: number;
    cronExpr?: string;
    timezone?: string;
    graceSeconds?: number;
  };

  const name = (body.name ?? "").trim().slice(0, 120);
  if (!name) return Response.json({ error: "Name required" }, { status: 400 });

  let scheduleKind: "interval" | "cron";
  let intervalSeconds: number | null = null;
  let cronExpr: string | null = null;

  if (body.scheduleKind === "cron") {
    const expr = (body.cronExpr ?? "").trim();
    if (!expr || !isValidCron(expr)) {
      return Response.json({ error: "Invalid cron expression" }, { status: 400 });
    }
    scheduleKind = "cron";
    cronExpr = expr;
  } else {
    const secs = Number(body.intervalSeconds);
    if (!Number.isFinite(secs) || secs < 60) {
      return Response.json({ error: "intervalSeconds must be >= 60" }, { status: 400 });
    }
    scheduleKind = "interval";
    intervalSeconds = Math.floor(secs);
  }

  const graceSeconds = Math.min(86400, Math.max(0, Math.floor(Number(body.graceSeconds) || 300)));

  const count = await db.monitor.count({ where: { userId: user.id } });
  if (count >= monitorLimitForPlan(user.plan)) {
    return Response.json(
      { error: `Plan limit reached (${monitorLimitForPlan(user.plan)} monitors). Upgrade to add more.` },
      { status: 402 }
    );
  }

  const monitor = await db.monitor.create({
    data: {
      userId: user.id,
      name,
      scheduleKind,
      intervalSeconds,
      cronExpr,
      timezone: (body.timezone ?? "UTC").slice(0, 60),
      graceSeconds,
    },
  });
  return Response.json({ monitor }, { status: 201 });
}
