import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Pingcron — Cron monitoring for developers who hate surprises",
  description:
    "Get alerted the moment a cron job misses its schedule. Flat $12/mo, unlimited peace of mind.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full flex flex-col">{children}</body>
    </html>
  );
}
